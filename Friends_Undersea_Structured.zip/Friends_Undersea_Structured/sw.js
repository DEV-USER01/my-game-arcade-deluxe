const CACHE_NAME = "friends-undersea-app-v4";
const APP_SHELL = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./assets/css/base.css",
  "./assets/css/start-screen.css",
  "./assets/css/overlays.css",
  "./assets/js/01-config.js",
  "./assets/js/02-core.js",
  "./assets/js/03-audio.js",
  "./assets/js/04-events.js",
  "./assets/js/05-save-entities.js",
  "./assets/js/06-shop.js",
  "./assets/js/07-update.js",
  "./assets/js/08-render-world.js",
  "./assets/js/09-render-actors.js",
  "./assets/js/10-render-enemies-helpers.js",
  "./assets/js/11-loop-input.js",
  "./assets/js/12-ui-pwa.js",
  "./assets/images/icon-192.png",
  "./assets/images/icon-512.png",
  "./assets/images/start-cover.jpg"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;

  event.respondWith(
    fetch(event.request)
      .then(response => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
        return response;
      })
      .catch(() =>
        caches.match(event.request).then(cached =>
          cached || caches.match("./index.html")
        )
      )
  );
});
