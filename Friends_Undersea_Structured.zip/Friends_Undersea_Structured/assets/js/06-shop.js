/* ร้านค้า การซื้อขาย อัปเกรด รักษา กู้ตู้ และอัปเดต HUD */
"use strict";

function upgradeTank(){
  const cost = pearlCost();
  if(state.coins<cost){ toast("เหรียญไม่พอ"); return; }
  state.coins-=cost; state.pearlLevel++;
  state.fish.forEach(f=>{
    f.maxHealth = (f.typeData && f.typeData.maxHealth) || f.maxHealth || 100;
    f.health = f.maxHealth;
    f.hunger = Math.min(f.hunger,30);
    f.growth += 7;
    f.size = Math.min(1.85, f.baseSize + f.growth/140);
  });
  if(tankHasSpace()){
    spawnFish(W*.5, tankTop+100+Math.random()*Math.max(80,tankBottom-tankTop-200), randomType());
  }
  dropCoin(W*.5,tankTop+110,25+state.pearlLevel*10,"gem");
  toast(`ตู้เลเวล ${tankLevel()} แล้ว! ความจุเพิ่มเป็น ${fishCapacity()} ตัว`);
  sfx("upgrade");
  updateUI(); renderShop(); renderSpeciesStrip(); saveProgress();
}

function buyFish(typeKey){
  const type = FISH_TYPES[typeKey];
  if(!type) return;
  if(state.coins < type.price){ toast("เหรียญไม่พอ"); sfx("error"); return; }
  if(!tankHasSpace()){
    toast(`ตู้เลเวล ${tankLevel()} เต็มแล้ว (${state.fish.length}/${fishCapacity()} ตัว) • อัปตู้เพื่อเพิ่มอีก 2 ช่อง`);
    return;
  }
  state.coins -= type.price;
  spawnFish(W*.5, tankTop+100+Math.random()*Math.max(80,tankBottom-tankTop-200), type.key);
  state.selectedType = type.key;
  toast(`ซื้อ${type.name}แล้ว`);
  sfx("buy");
  updateUI(); renderShop(); renderSpeciesStrip(); saveProgress();
}

function fishSellValue(f){
  const type=f.typeData||FISH_TYPES[f.type]||FISH_TYPES.goldfish;
  const maturity=Math.max(0,Math.min(1,(f.size-.8)/1.05));
  const healthFactor=.72+.28*fishHealthRatio(f);
  const hungerFactor=1-Math.min(.18,Math.max(0,f.hunger)/550);
  const tankBonus=1+Math.min(.35,state.pearlLevel*.025);
  const saleBase=type.sellBase||type.price;
  const buffMultiplier=permanentBuffSaleMultiplier(f);
  const electricMultiplier=electricScarSaleMultiplier(f);
  const raw=saleBase*(.60+maturity*1.60)*healthFactor*hungerFactor*tankBonus
    *buffMultiplier*electricMultiplier;
  return Math.max(25,Math.round(raw));
}

function sellBestFish(typeKey){
  const candidates=state.fish
    .filter(f=>f.type===typeKey)
    .sort((a,b)=>fishSellValue(b)-fishSellValue(a));

  if(candidates.length===0){ toast("ไม่มีปลาสายพันธุ์นี้ให้ขาย"); return; }
  if(state.fish.length<=1){ toast("ต้องเหลือปลาอย่างน้อย 1 ตัวในตู้"); return; }

  const fish=candidates[0];
  const type=FISH_TYPES[typeKey];
  const value=fishSellValue(fish);
  const maturity=fish.size>=1.55?"โตเต็มวัย":fish.size>=1.25?"กำลังโต":"วัยเล็ก";

  const buffCount=fishPermanentBuffKeys(fish).length;
  const buffBonus=Math.round((permanentBuffSaleMultiplier(fish)-1)*100);
  const buffText=buffCount
    ? `\nบัฟถาวร ${permanentBuffIcons(fish)} ${buffCount} ชนิด • โบนัสขาย +${buffBonus}%`
    : "";
  const electricText=fish.electricScar
    ? "\n⚡ ตราไฟฟ้า: ราคาขายเหลือ 50%"
    : "";
  const ok=window.confirm(`ขาย${type.name} (${maturity}) ราคา ${value.toLocaleString("th-TH")} เหรียญใช่ไหม?${buffText}${electricText}`);
  if(!ok) return;

  const index=state.fish.indexOf(fish);
  if(index<0) return;

  state.fish.splice(index,1);
  state.coins+=value;
  state.soldCount++;
  state.salesCoins+=value;

  dropCoin(
    Math.max(40,Math.min(W-40,fish.x)),
    Math.max(tankTop+45,Math.min(tankBottom-45,fish.y)),
    Math.max(5,Math.round(value*.18)),
    "gem"
  );

  toast(`ขาย${type.name}แล้ว +${value.toLocaleString("th-TH")} เหรียญ`);
  sfx("sell");
  updateUI();
  renderShop();
  renderSpeciesStrip();
  saveProgress();
}

function renderFishMarket(){
  ui.fishMarket.innerHTML="";
  ui.marketSummary.innerHTML=`ขายแล้ว <b>${state.soldCount.toLocaleString("th-TH")}</b> ตัว • รายได้สะสม <span class="saleValue">${Math.floor(state.salesCoins).toLocaleString("th-TH")} 🪙</span><br>ราคาขายขึ้นตามขนาด สุขภาพ ระดับตู้ และบัฟถาวร • ⚡ ตราไฟฟ้าทำให้ราคาขายเหลือครึ่งหนึ่ง`;

  Object.values(FISH_TYPES).forEach(type=>{
    const owned=state.fish.filter(f=>f.type===type.key);
    const best=owned.slice().sort((a,b)=>fishSellValue(b)-fishSellValue(a))[0]||null;
    const count=owned.length;
    const value=best?fishSellValue(best):0;
    const stage=!best?"ไม่มีปลา":best.size>=1.55?"โตเต็มวัย":best.size>=1.25?"กำลังโต":"วัยเล็ก";

    const row=document.createElement("div");
    row.className="shopItem";
    row.innerHTML=`<div class="shopEmoji">${type.emoji}</div>
    <div class="shopMeta"><b>${type.name} • มี ${count} ตัว</b>
    <small>${best
      ? `ตัวที่ราคาดีที่สุด: ${stage} • เลือด ${Math.round(best.health)}/${best.maxHealth||best.typeData?.maxHealth||100}`
        + (fishPermanentBuffKeys(best).length
          ? `<br>บัฟถาวร ${permanentBuffIcons(best)} • โบนัสขาย +${Math.round((permanentBuffSaleMultiplier(best)-1)*100)}%`
          : "")
        + (best.electricScar
          ? `<br>⚡ ตราไฟฟ้า • ราคาขายเหลือ 50%`
          : "")
      : "ซื้อหรือเลี้ยงปลาชนิดนี้ก่อน"}</small></div>`;

    const btn=document.createElement("button");
    btn.className="sellBtn";
    btn.type="button";
    btn.textContent=best?`ขาย ${value.toLocaleString("th-TH")} 🪙`:"ไม่มีปลา";
    btn.disabled=!best||state.fish.length<=1;
    btn.onclick=()=>sellBestFish(type.key);

    row.appendChild(btn);
    ui.fishMarket.appendChild(row);
  });
}

function buyGuardian(typeKey){
  const type=GUARDIAN_TYPES[typeKey];
  if(!type) return;
  const owned=guardianCountByType(type.key);
  if(owned>=MAX_GUARDIANS_PER_TYPE){
    toast(`${type.name} มีครบ ${MAX_GUARDIANS_PER_TYPE} ตัวแล้ว`);
    return;
  }
  if(state.guardians.length>=MAX_GUARDIANS){
    toast(`มีปลาองครักษ์รวมครบ ${MAX_GUARDIANS} ตัวแล้ว`);
    return;
  }
  if(state.coins<type.price){
    toast("เหรียญไม่พอ");
    sfx("error");
    return;
  }
  state.coins-=type.price;
  spawnGuardian(W*.5,Math.min(tankBottom-120, tankTop + Math.max(150,(tankBottom-tankTop)*0.55)),type.key);
  toast(`${type.name} เข้าประจำการแล้ว 🛡️`);
  sfx("buy");
  updateUI();renderShop();saveProgress();
}

function buy(kind){
  const prices={food:foodUpgradeCost(),snail:snailCost(),catfish:catfishHelperCost()};
  const price=prices[kind];
  if(state.coins<price){toast("เหรียญไม่พอ");sfx("error");return}
  if(kind==="snail"&&state.snail){toast("มีหอยผู้ช่วยแล้ว");return}
  if(kind==="catfish"&&state.catfishHelper){toast("มีปลาดุกผู้ช่วยแล้ว");return}
  if(kind==="food"&&state.foodLevel>=5){toast("อาหารระดับสูงสุดแล้ว");return}
  state.coins-=price;
  if(kind==="food"){state.foodLevel++;toast("อาหารดีขึ้น ปลาโตไวขึ้น")}
  if(kind==="snail"){state.snail={x:W*.2,y:tankBottom-12,vx:24,dir:1};toast("หอยจะเก็บเหรียญใกล้พื้น")}
  if(kind==="catfish"){
    state.catfishHelper={
      x:W*.72,y:tankBottom-28,vx:0,vy:0,dir:-1,wobble:Math.random()*8,refunds:0
    };
    toast("ปลาดุกผู้ช่วยจะเก็บอาหารที่ตกพื้น แล้วคืนเงิน 1 เหรียญต่อเม็ด");
  }
  sfx("buy");updateUI();renderShop();saveProgress();
}

function healAllFish(){
  if(state.fish.length===0){
    toast("ยังไม่มีปลาให้รักษา");
    return;
  }

  const injured=state.fish.filter(f=>{
    const maxHealth=f.maxHealth||f.typeData?.maxHealth||100;
    return f.health<maxHealth-.5;
  });

  if(injured.length===0){
    toast("ปลาทุกตัวเลือดเต็มแล้ว ❤️");
    return;
  }

  const cost=healFishCost();
  if(state.coins<cost){
    toast(`เหรียญไม่พอ • ค่ารักษา ${cost.toLocaleString("th-TH")} เหรียญ`);
    sfx("error");
    return;
  }

  state.coins-=cost;
  let totalHealed=0;
  for(const f of injured){
    const maxHealth=f.maxHealth||f.typeData?.maxHealth||100;
    const before=f.health;
    const amount=Math.max(24,maxHealth*.45);
    f.health=Math.min(maxHealth,f.health+amount);
    f.hunger=Math.max(0,f.hunger-12);
    totalHealed+=f.health-before;
  }

  toast(`💚 รักษาปลา ${injured.length} ตัวแล้ว
ฟื้นเลือดรวม ${Math.round(totalHealed)} • -${cost.toLocaleString("th-TH")} เหรียญ`);
  sfx("heal");
  updateUI();
  saveProgress();
}

function rescueTank(force=false){
  if(state.rescueCooldown>0 && !force){ toast("หน่วยกู้ภัยกำลังพัก"); return; }
  const fee = force ? 0 : rescueCost();
  if(!force && state.coins < fee){ toast("เหรียญไม่พอสำหรับกู้ตู้ปลา"); return; }
  state.coins -= fee;
  state.enemies.length = 0;
  state.foods.length = 0;
  state.rescues++;
  state.rescueCooldown = 18;
  const toSpawn = Math.max(2,1+Math.min(4,state.pearlLevel));
  for(let i=0;i<toSpawn;i++) setTimeout(()=>{
    spawnFish(W*.5 + (Math.random()-.5)*90, tankTop+120+Math.random()*80, randomType());
    if(i===toSpawn-1){ updateUI(); renderSpeciesStrip(); saveProgress(); }
  }, i*260);
  toast(fee>0 ? `กู้ตู้ปลาแล้ว -${fee} เหรียญ` : "กู้ตู้ปลาอัตโนมัติ");
  sfx("rescue");
  updateUI(); saveProgress();
}

function updateUI(){
  ui.coins.textContent=Math.floor(state.coins);
  ui.goal.textContent=`${state.pearlLevel} • ถัดไป ${pearlCost().toLocaleString("th-TH")}`;
  const eventLabel=state.activeEvent?` • ${state.activeEvent.type.icon}`:"";
  ui.wave.textContent=`🌊 คลื่น ${Math.max(1,state.wave-1)} • ∞${eventLabel}`;
  const helperText=state.catfishHelper
    ? ` • ↩️ ${state.catfishHelper.refunds||0}`
    : "";
  ui.tankStats.textContent=
    `🐟 ${state.fish.length}/${fishCapacity()}`
    + ` • 🛡️ ${state.guardians.length}/${MAX_GUARDIANS}`
    + ` • ขาย ${state.soldCount}${helperText}`
    + ` • 🛟 ${state.rescues}`;
  const healBtn=$("healBtn");
  if(healBtn){
    const cost=healFishCost();
    healBtn.innerHTML=`💚 รักษา<br><small>${cost.toLocaleString("th-TH")} 🪙</small>`;
    healBtn.style.opacity=state.fish.length===0?".55":"1";
  }
}

function nearest(arr,x,y,max=1e9){
  let best=null,bd=max*max;
  for(const o of arr){const dx=o.x-x,dy=o.y-y,d=dx*dx+dy*dy;if(d<bd){bd=d;best=o}}
  return best;
}

function collectCoin(c){
  const idx=state.coinsDrop.indexOf(c); if(idx<0) return;
  const bonus = Math.round(c.value*(1+state.pearlLevel*.15));
  state.coins += bonus; state.coinsDrop.splice(idx,1); state.combo++;
  sfx("coin",state.combo); updateUI();
}

function renderSpeciesStrip(){
  // นำแถบเลือกชนิดปลาออกแล้ว เลือกและซื้อปลาได้จากร้านค้า
}

function renderShop(){
  ui.fishShop.innerHTML="";
  Object.values(FISH_TYPES).forEach(type=>{
    const row=document.createElement("div");
    row.className="shopItem";
    row.innerHTML=`<div class="shopEmoji">${type.emoji}</div>
    <div class="shopMeta"><b>${type.name}</b><small>${type.desc}<br>ราคา ${type.price.toLocaleString("th-TH")} • เลือด ${type.maxHealth} • เหรียญพื้นฐาน ${type.coinBase}</small></div>`;
    const btn=document.createElement("button");
    btn.className="buyBtn"; btn.textContent=`${type.price.toLocaleString("th-TH")} 🪙`; btn.disabled=state.coins<type.price||!tankHasSpace();
    btn.onclick=()=>buyFish(type.key);
    row.appendChild(btn); ui.fishShop.appendChild(row);
  });

  ui.upgradeShop.innerHTML="";
  const guardianUpgrades=Object.values(GUARDIAN_TYPES).map(type=>{
    const owned=guardianCountByType(type.key);
    return {
      emoji:type.emoji,
      name:type.name,
      desc:`${type.desc} • พลัง ${type.damage.toFixed(1)} • ระยะ ${type.range} • มี ${owned}/${MAX_GUARDIANS_PER_TYPE} ตัว`,
      price:owned>=MAX_GUARDIANS_PER_TYPE?null:type.price,
      action:()=>buyGuardian(type.key)
    };
  });
  const upgrades = [
    {emoji:"🍤", name:"อัปอาหาร", desc:`ระดับ ${state.foodLevel}/5 • โตไวและฟื้นเลือดมากขึ้นเมื่อกิน`, price:state.foodLevel>=5?null:foodUpgradeCost(), action:()=>buy("food")},
    {emoji:"🐌", name:"หอยเก็บเหรียญ", desc:state.snail?"มีหอยผู้ช่วยแล้ว":"ช่วยเก็บเหรียญแถวพื้นตู้", price:state.snail?null:snailCost(), action:()=>buy("snail")},
    {
      emoji:"🐟", name:"ปลาดุกคืนอาหาร",
      desc:state.catfishHelper
        ? `มีปลาดุกผู้ช่วยแล้ว • คืนเงินสะสม ${state.catfishHelper.refunds||0} เหรียญ`
        : "มีได้ 1 ตัว • เก็บอาหารที่ตกพื้นและคืนเงิน 1 เหรียญต่อเม็ด",
      price:state.catfishHelper?null:catfishHelperCost(),
      action:()=>buy("catfish")
    },
    ...guardianUpgrades,
    {emoji:"🦪", name:`อัปตู้เป็น Lv.${tankLevel()+1}`, desc:`เพิ่มความจุจาก ${fishCapacity()} เป็น ${fishCapacity()+2} ตัว • ราคาเพิ่มประมาณ 2.25 เท่าทุกเลเวล`, price:pearlCost(), action:upgradeTank},
    {emoji:"🛟", name:"หน่วยกู้ภัย", desc:`คืนชีวิตให้ตู้ปลา • ค่าใช้จ่าย ${rescueCost()} เหรียญ`, price:rescueCost(), action:()=>rescueTank(false)},
  ];
  upgrades.forEach(u=>{
    const row=document.createElement("div");
    row.className="shopItem";
    row.innerHTML=`<div class="shopEmoji">${u.emoji}</div><div class="shopMeta"><b>${u.name}</b><small>${u.desc}</small></div>`;
    const btn=document.createElement("button");
    btn.className="buyBtn";
    if(u.price==null){
      btn.textContent=GUARDIAN_TYPES && Object.values(GUARDIAN_TYPES).some(g=>g.name===u.name)?"เต็ม":"MAX";
      btn.disabled=true;
    }
    else { btn.textContent=`${u.price.toLocaleString("th-TH")} 🪙`; btn.disabled=state.coins<u.price; }
    if(u.name==="หอยเก็บเหรียญ" && state.snail) btn.disabled=true;
    if(u.name==="ปลาดุกคืนอาหาร" && state.catfishHelper) btn.disabled=true;
    btn.onclick=u.action; row.appendChild(btn); ui.upgradeShop.appendChild(row);
  });

  renderFishMarket();
}
