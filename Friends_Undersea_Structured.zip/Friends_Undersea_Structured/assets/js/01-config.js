/* ข้อมูลปลา ศัตรู ผู้พิทักษ์ อีเวนต์ และสไปรต์ */
"use strict";

const SAVE_KEY = "aqua-pocket-deluxe-v2";
const AUDIO_SETTINGS_KEY = "aqua-pocket-audio-settings-v1";
const FISH_TYPES = {
  goldfish: {
    key:"goldfish", name:"ปลาทอง", emoji:"🐠", price:300, sellBase:100, desc:"ปลาเริ่มต้น เลี้ยงง่าย เลือด 100",
    hue:[26,54], body:"gold", growthMul:1.0, hungerMul:1.0, hpMul:1.0, maxHealth:100, coinBase:2, coinRate:1.0, speed:1.0, rarity:1
  },
  clownfish: {
    key:"clownfish", name:"ปลาการ์ตูน", emoji:"🐟", price:750, sellBase:250, desc:"คล่องตัวและโตไว เลือด 115",
    hue:[14,28], body:"clown", growthMul:1.2, hungerMul:1.08, hpMul:1.04, maxHealth:115, coinBase:2, coinRate:1.05, speed:1.15, rarity:1
  },
  betta: {
    key:"betta", name:"ปลากัดแฟนซี", emoji:"🪭", price:1500, sellBase:500, desc:"ครีบสวย ว่ายไว เลือด 135",
    hue:[300,340], body:"betta", growthMul:1.08, hungerMul:0.98, hpMul:1.12, maxHealth:135, coinBase:3, coinRate:1.10, speed:1.12, rarity:1
  },
  angelfish: {
    key:"angelfish", name:"ปลาเทพา", emoji:"✨", price:2700, sellBase:900, desc:"หาเหรียญดี สมดุล เลือด 150",
    hue:[186,220], body:"angel", growthMul:0.95, hungerMul:0.92, hpMul:1.20, maxHealth:150, coinBase:4, coinRate:1.18, speed:0.92, rarity:1
  },
  puffer: {
    key:"puffer", name:"ปลาพองตัว", emoji:"🐡", price:5400, sellBase:1800, desc:"ถึกและทนมาก เลือด 190",
    hue:[40,58], body:"puffer", growthMul:0.88, hungerMul:0.82, hpMul:1.34, maxHealth:190, coinBase:5, coinRate:1.15, speed:0.8, rarity:1
  },
  blueTang: {
    key:"blueTang", name:"ปลาบลูแทง", emoji:"🔵", price:10500, sellBase:3500, desc:"ตัวแบนว่ายไว ค่าตัวกลางสูง เลือด 230",
    hue:[205,225], body:"tang", growthMul:1.02, hungerMul:0.94, hpMul:1.42, maxHealth:230, coinBase:6, coinRate:1.22, speed:1.08, rarity:1
  },
  shark: {
    key:"shark", name:"ฉลามจิ๋ว", emoji:"🦈", price:21000, sellBase:7000, desc:"นักล่าตัวเล็ก แข็งแรง เลือด 280",
    hue:[195,215], body:"shark", growthMul:1.05, hungerMul:1.02, hpMul:1.48, maxHealth:280, coinBase:8, coinRate:1.35, speed:1.18, rarity:1
  },
  koi: {
    key:"koi", name:"ปลาโค่ย", emoji:"🎏", price:45000, sellBase:15000, desc:"หรูหรา มูลค่าสูง เลือด 340",
    hue:[18,34], body:"koi", growthMul:0.96, hungerMul:0.88, hpMul:1.56, maxHealth:340, coinBase:10, coinRate:1.46, speed:0.98, rarity:1
  },
  lionfish: {
    key:"lionfish", name:"ปลาสิงโต", emoji:"🦁", price:90000, sellBase:30000, desc:"แพงสุดในร้าน ครีบสวยและถึกมาก เลือด 420",
    hue:[8,28], body:"lion", growthMul:0.92, hungerMul:0.84, hpMul:1.70, maxHealth:420, coinBase:12, coinRate:1.60, speed:0.9, rarity:1
  }
};

const ENEMY_TYPES = [
  {key:"shadow", name:"ปลานักล่า", emoji:"🐟", hpMul:1.0, speedMul:1.02, damageMul:1.0, rewardMul:1.0, tint:"#ff6f96", minWave:1, weight:4, scale:1.0},
  {key:"jelly", name:"แมงกะพรุนไฟ", emoji:"🪼", hpMul:.88, speedMul:1.18, damageMul:.92, rewardMul:1.08, tint:"#a58cff", minWave:2, weight:3, scale:.96},
  {key:"crab", name:"ปูจู่โจม", emoji:"🦀", hpMul:1.32, speedMul:.88, damageMul:1.24, rewardMul:1.18, tint:"#ff9078", minWave:3, weight:3, scale:1.02},
  {key:"squid", name:"หมึกจู่โจม", emoji:"🦑", hpMul:1.18, speedMul:1.08, damageMul:1.22, rewardMul:1.28, tint:"#a97dff", minWave:4, weight:2, scale:1.08},
  {key:"sharkEnemy", name:"ฉลามล่าเหยื่อ", emoji:"🦈", hpMul:1.55, speedMul:1.12, damageMul:.68, rewardMul:1.45, tint:"#8fdcff", minWave:6, weight:1, scale:1.16},
];

const GUARDIAN_TYPES = {
  sword: {
    key:"sword", name:"ปลาหางดาบองครักษ์", emoji:"🐟", body:"sword",
    price:7500, damage:3.6, cooldown:.88, speed:1.10, range:205,
    color:"#48c8ee", desc:"รุ่นเริ่มต้น คล่องตัวและยิงต่อเนื่อง"
  },
  pufferGuard: {
    key:"pufferGuard", name:"ปักเป้าป้อมปืน", emoji:"🐡", body:"puffer",
    price:22500, damage:5.8, cooldown:1.02, speed:.84, range:230,
    color:"#ffd76a", desc:"เคลื่อนที่ช้า แต่กระสุนหนักและยิงไกล"
  },
  ray: {
    key:"ray", name:"กระเบนสายฟ้า", emoji:"⚡", body:"ray",
    price:60000, damage:8.6, cooldown:.70, speed:1.18, range:255,
    color:"#a88cff", desc:"รวดเร็ว ยิงสายฟ้าแรงและถี่"
  },
  royalShark: {
    key:"royalShark", name:"ฉลามราชองครักษ์", emoji:"🦈", body:"royalShark",
    price:150000, damage:13.5, cooldown:.58, speed:1.26, range:285,
    color:"#7ee8ff", desc:"รุ่นสูงสุด ยิงแรงที่สุดและไล่ล่าเร็ว"
  }
};
const EVENT_TYPES = {
  rainbow:{key:"rainbow",name:"อีเวนต์สายรุ้ง",icon:"🌈",className:"rainbow",duration:48,desc:"โตไว x2.2 • ฟื้นเลือด x4 • หิวช้าลง",fishBuff:"พรสายรุ้ง",growthMul:2.2,healMul:4,hungerMul:.65,speedMul:1.12,coinRateMul:1.25,coinValueMul:1.25,damageTakenMul:.8,enemySpeedMul:1,enemyRewardMul:1.25,guardianDamageMul:1.15},
  storm:{key:"storm",name:"อีเวนต์พายุ",icon:"⛈️",className:"storm",duration:38,desc:"ปลาเร็ว x1.4 • เกราะ 35% • ศัตรูเร็ว • รางวัล x2",fishBuff:"พลังพายุ",growthMul:1.15,healMul:1.25,hungerMul:.92,speedMul:1.4,coinRateMul:1.35,coinValueMul:1.35,damageTakenMul:.65,enemySpeedMul:1.35,enemyRewardMul:2,guardianDamageMul:1.45},
  gold:{key:"gold",name:"อีเวนต์ทอง",icon:"🪙",className:"gold",duration:45,desc:"ออกเหรียญ x2.6 • มูลค่าเหรียญ x3",fishBuff:"เกล็ดทอง",growthMul:1.2,healMul:1.35,hungerMul:.82,speedMul:1.08,coinRateMul:2.6,coinValueMul:3,damageTakenMul:.88,enemySpeedMul:1,enemyRewardMul:2.2,guardianDamageMul:1.1},
  blessing:{key:"blessing",name:"อีเวนต์พรแห่งทะเล",icon:"✨",className:"blessing",duration:50,desc:"หิวช้าลง 55% • ฟื้นเลือด x3 • เกราะ 50%",fishBuff:"พรแห่งทะเล",growthMul:1.55,healMul:3,hungerMul:.45,speedMul:1.2,coinRateMul:1.45,coinValueMul:1.45,damageTakenMul:.5,enemySpeedMul:.92,enemyRewardMul:1.35,guardianDamageMul:1.25}
};
const NO_EVENT_EFFECTS={growthMul:1,healMul:1,hungerMul:1,speedMul:1,coinRateMul:1,coinValueMul:1,damageTakenMul:1,enemySpeedMul:1,enemyRewardMul:1,guardianDamageMul:1};

const SPRITE_CACHE={};
function svgToDataUri(svg){
  return "data:image/svg+xml;charset=utf-8,"+encodeURIComponent(svg.replace(/>\s+</g,"><").trim());
}
function getSprite(key,svg){
  if(SPRITE_CACHE[key]) return SPRITE_CACHE[key];
  const img=new Image();
  img.decoding="async";
  img.src=svgToDataUri(svg);
  SPRITE_CACHE[key]=img;
  return img;
}
function getGoldfishSprite(){
  return getSprite("goldfish-chibi",`
    <svg xmlns="http://www.w3.org/2000/svg" width="220" height="180" viewBox="0 0 220 180">
      <defs>
        <linearGradient id="tail" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#fff1a8"/>
          <stop offset="58%" stop-color="#ffd25f"/>
          <stop offset="100%" stop-color="#f6a23b"/>
        </linearGradient>
        <radialGradient id="body" cx="35%" cy="30%" r="75%">
          <stop offset="0%" stop-color="#fff6bd"/>
          <stop offset="35%" stop-color="#ffd667"/>
          <stop offset="72%" stop-color="#ffb53f"/>
          <stop offset="100%" stop-color="#ec8f25"/>
        </radialGradient>
        <radialGradient id="fin" cx="40%" cy="25%" r="80%">
          <stop offset="0%" stop-color="#fff5ae"/>
          <stop offset="100%" stop-color="#f5bb43"/>
        </radialGradient>
      </defs>

      <g transform="translate(10 8)">
        <path d="M58 86 C25 68 10 45 15 24 C40 30 67 49 82 72 C77 80 69 86 58 86 Z" fill="url(#tail)" stroke="#c87b25" stroke-width="6" stroke-linejoin="round"/>
        <path d="M62 93 C24 98 10 122 17 145 C45 140 71 124 84 103 C78 97 71 94 62 93 Z" fill="url(#tail)" stroke="#c87b25" stroke-width="6" stroke-linejoin="round"/>
        <path d="M89 82 C76 55 92 25 137 18 C184 10 208 37 203 78 C198 122 161 144 112 139 C76 135 58 111 60 90 C62 81 77 78 89 82 Z" fill="url(#body)" stroke="#c87b25" stroke-width="7" stroke-linejoin="round"/>
        <path d="M106 25 C118 6 142 2 160 16 C148 28 128 38 111 41 C105 36 103 31 106 25 Z" fill="url(#fin)" stroke="#c87b25" stroke-width="6" stroke-linejoin="round"/>
        <path d="M96 112 C111 116 118 131 111 146 C91 144 75 133 69 118 C76 113 86 110 96 112 Z" fill="url(#fin)" stroke="#c87b25" stroke-width="6" stroke-linejoin="round"/>
        <path d="M92 92 C107 90 117 100 113 113 C96 116 82 109 79 97 C82 93 87 92 92 92 Z" fill="url(#fin)" stroke="#c87b25" stroke-width="5" stroke-linejoin="round"/>
        <ellipse cx="126" cy="77" rx="42" ry="36" fill="#ffe88d" opacity=".52"/>
        <ellipse cx="112" cy="59" rx="18" ry="9" fill="#fff8d7" opacity=".85" transform="rotate(-18 112 59)"/>
        <circle cx="162" cy="74" r="19" fill="#fff" stroke="#d9ecff" stroke-width="3"/>
        <circle cx="168" cy="76" r="9" fill="#23345b"/>
        <circle cx="171" cy="72" r="3.5" fill="#fff"/>
        <ellipse cx="150" cy="102" rx="8" ry="5" fill="#ff9d96" opacity=".72"/>
        <path d="M180 97 Q192 104 181 111" fill="none" stroke="#6e4126" stroke-width="6" stroke-linecap="round"/>
        <path d="M134 86 Q128 91 129 99" fill="none" stroke="#c88745" stroke-width="4" stroke-linecap="round"/>
        <circle cx="187" cy="62" r="3" fill="#ffcc7b" opacity=".75"/>
      </g>
    </svg>
  `);
}
function tryDrawGoldfishSprite(){
  const img=getGoldfishSprite();
  if(!img || !img.complete || !img.naturalWidth) return false;
  ctx.drawImage(img,-47,-39,98,78);
  return true;
}

const MAX_GUARDIANS_PER_TYPE = 3;
const MAX_GUARDIANS = Object.keys(GUARDIAN_TYPES).length * MAX_GUARDIANS_PER_TYPE;
