/* วาดปลา บัฟ ปลาไหล ผู้พิทักษ์ และกระสุน */
"use strict";

function drawFish(f){
  const t=f.typeData;
  const hue=f.hueBase+f.hueShift;
  const tailSwing=Math.sin(f.wobble*1.6)*.22;
  const finSwing=Math.sin(f.wobble*1.2)*.12;

  ctx.save();
  ctx.translate(f.x,f.y);
  ctx.scale(f.dir*f.size,f.size);
  ctx.rotate(Math.sin(f.wobble)*.035);

  ctx.save();
  ctx.globalAlpha=.22;
  ctx.fillStyle="#001f2d";
  ctx.beginPath();
  ctx.ellipse(-1,16,29,8,0,0,Math.PI*2);
  ctx.fill();
  ctx.restore();

  ctx.shadowColor="rgba(0,20,30,.30)";
  ctx.shadowBlur=MOBILE_MODE?0:5;
  ctx.shadowOffsetY=MOBILE_MODE?0:3;

  if(t.body==="gold"){
    // ใช้สไปรต์ปลาทองสไตล์ชิบิให้หน้าตาใกล้ภาพตัวอย่างมากขึ้น
    if(tryDrawGoldfishSprite()){
      if(!MOBILE_MODE){
        ctx.fillStyle="rgba(255,244,170,.78)";
        [[-28,-16,1.25],[-22,15,1],[30,-15,.95]].forEach(([x,y,r])=>{
          ctx.beginPath();
          ctx.arc(x,y,r,0,Math.PI*2);
          ctx.fill();
        });
      }
    }else{
      // fallback เดิมกรณีสไปรต์ยังโหลดไม่เสร็จ
      ctx.save();
      ctx.translate(-20,0);
      ctx.rotate(tailSwing);

      const tail=ctx.createLinearGradient(-39,-22,2,19);
      tail.addColorStop(0,`hsla(${hue+34},100%,88%,.82)`);
      tail.addColorStop(.42,`hsla(${hue+20},98%,72%,.92)`);
      tail.addColorStop(1,`hsl(${hue+5},92%,55%)`);
      ctx.fillStyle=tail;
      ctx.strokeStyle=`hsl(${hue-7},72%,39%)`;
      ctx.lineWidth=1.7;
      ctx.beginPath();
      ctx.moveTo(2,0);
      ctx.bezierCurveTo(-10,-8,-16,-28,-36,-27);
      ctx.bezierCurveTo(-41,-18,-36,-8,-26,-1);
      ctx.bezierCurveTo(-38,7,-42,19,-34,27);
      ctx.bezierCurveTo(-15,27,-8,10,2,0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();

      ctx.save();
      ctx.rotate(finSwing*.7);
      const topFin=ctx.createLinearGradient(-7,-25,13,-7);
      topFin.addColorStop(0,`hsla(${hue+35},100%,91%,.88)`);
      topFin.addColorStop(1,`hsla(${hue+9},96%,60%,.94)`);
      ctx.fillStyle=topFin;
      ctx.strokeStyle=`hsl(${hue-7},72%,39%)`;
      ctx.lineWidth=1.4;
      ctx.beginPath();
      ctx.moveTo(-10,-13);
      ctx.bezierCurveTo(-5,-28,6,-31,16,-19);
      ctx.quadraticCurveTo(8,-11,1,-7);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();

      const body=ctx.createRadialGradient(12,-11,2,3,1,36);
      body.addColorStop(0,`hsl(${hue+31},100%,90%)`);
      body.addColorStop(.25,`hsl(${hue+18},100%,73%)`);
      body.addColorStop(.62,`hsl(${hue+5},96%,58%)`);
      body.addColorStop(1,`hsl(${hue-8},82%,42%)`);
      ctx.fillStyle=body;
      ctx.strokeStyle=`hsl(${hue-12},70%,31%)`;
      ctx.lineWidth=2.1;
      ctx.beginPath();
      ctx.ellipse(3,0,31,25,-.02,0,Math.PI*2);
      ctx.fill();
      ctx.stroke();

      const face=ctx.createRadialGradient(25,-7,2,23,0,19);
      face.addColorStop(0,"rgba(255,252,226,.98)");
      face.addColorStop(1,"rgba(255,224,154,.62)");
      ctx.fillStyle=face;
      ctx.beginPath();
      ctx.ellipse(20,0,15,19,-.08,0,Math.PI*2);
      ctx.fill();

      ctx.save();
      ctx.translate(-3,8);
      ctx.rotate(finSwing+.15);
      const sideFin=ctx.createLinearGradient(-2,-2,16,14);
      sideFin.addColorStop(0,`hsla(${hue+30},100%,88%,.92)`);
      sideFin.addColorStop(1,`hsla(${hue+5},94%,57%,.92)`);
      ctx.fillStyle=sideFin;
      ctx.strokeStyle=`hsl(${hue-8},70%,38%)`;
      ctx.lineWidth=1.3;
      ctx.beginPath();
      ctx.moveTo(0,0);
      ctx.bezierCurveTo(7,0,15,8,12,15);
      ctx.bezierCurveTo(4,15,-2,9,0,0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();

      ctx.fillStyle=`hsla(${hue+16},96%,67%,.88)`;
      ctx.strokeStyle=`hsl(${hue-8},70%,38%)`;
      ctx.lineWidth=1.2;
      ctx.beginPath();
      ctx.moveTo(1,20);
      ctx.quadraticCurveTo(8,30,16,20);
      ctx.quadraticCurveTo(9,18,1,20);
      ctx.fill();
      ctx.stroke();

      drawScaleSparkles([
        [-13,-7,3.5],[-5,-12,3.2],[4,-13,2.8],
        [-11,2,3],[-2,5,3],[7,2,2.5]
      ],"rgba(255,248,212,.38)");

      ctx.fillStyle="rgba(255,255,255,.56)";
      ctx.beginPath();
      ctx.ellipse(-3,-16,10,4,-.18,0,Math.PI*2);
      ctx.fill();
      ctx.fillStyle="rgba(255,255,255,.36)";
      ctx.beginPath();
      ctx.arc(-15,-9,3,0,Math.PI*2);
      ctx.fill();

      drawFishEye(18,-6,7.4,.42);
      ctx.strokeStyle="rgba(65,30,18,.66)";
      ctx.lineWidth=1.25;
      ctx.lineCap="round";
      ctx.beginPath();
      ctx.moveTo(13,-13);
      ctx.quadraticCurveTo(18,-16,23,-13);
      ctx.stroke();

      ctx.fillStyle="rgba(255,112,116,.52)";
      ctx.beginPath();
      ctx.ellipse(19,5,4.4,2.7,-.12,0,Math.PI*2);
      ctx.fill();

      ctx.fillStyle="rgba(92,34,29,.90)";
      ctx.beginPath();
      ctx.ellipse(28,4,4.3,3.2,.10,0,Math.PI*2);
      ctx.fill();
      ctx.fillStyle="#ff8f82";
      ctx.beginPath();
      ctx.ellipse(29,5.2,2.2,1.2,.06,0,Math.PI*2);
      ctx.fill();

      ctx.strokeStyle="rgba(112,54,20,.34)";
      ctx.lineWidth=1.1;
      ctx.beginPath();
      ctx.arc(10,1,8,-1.05,1.08);
      ctx.stroke();
    }

  }else if(t.body==="clown"){
    ctx.save();
    ctx.translate(-20,0);
    ctx.rotate(tailSwing);
    ctx.fillStyle="#ff7f32";
    ctx.strokeStyle="#582816";
    ctx.lineWidth=2;
    ctx.beginPath();
    ctx.moveTo(0,0);
    ctx.quadraticCurveTo(-20,-18,-35,-12);
    ctx.quadraticCurveTo(-28,0,-35,13);
    ctx.quadraticCurveTo(-18,18,0,0);
    ctx.closePath();
    ctx.fill();ctx.stroke();
    ctx.restore();

    const body=ctx.createRadialGradient(12,-8,2,1,1,31);
    body.addColorStop(0,"#ffc27a");
    body.addColorStop(.36,"#ff9b43");
    body.addColorStop(.78,"#f16f25");
    body.addColorStop(1,"#a9441c");
    ctx.fillStyle=body;
    ctx.strokeStyle="#4a241a";
    ctx.lineWidth=2.4;
    ctx.beginPath();
    ctx.ellipse(2,0,29,17,0,0,Math.PI*2);
    ctx.fill();ctx.stroke();

    ctx.save();
    ctx.clip();
    for(const x of [-12,2,16]){
      ctx.strokeStyle="#182a30";
      ctx.lineWidth=8;
      ctx.beginPath();ctx.moveTo(x,-20);ctx.lineTo(x,20);ctx.stroke();
      ctx.strokeStyle="#fff8e8";
      ctx.lineWidth=5;
      ctx.beginPath();ctx.moveTo(x,-20);ctx.lineTo(x,20);ctx.stroke();
    }
    ctx.restore();

    ctx.fillStyle="#e35e27";
    ctx.strokeStyle="#4a241a";
    ctx.lineWidth=1.5;
    ctx.save();
    ctx.rotate(finSwing);
    ctx.beginPath();
    ctx.moveTo(-2,-12);
    ctx.quadraticCurveTo(6,-27,14,-16);
    ctx.quadraticCurveTo(8,-10,3,-6);
    ctx.closePath();
    ctx.fill();ctx.stroke();
    ctx.restore();

    ctx.beginPath();
    ctx.ellipse(0,9,11,6,.15,0,Math.PI*2);
    ctx.fill();ctx.stroke();
    drawFishEye(20,-4,5.5,.15);
    drawFishMouth(29,4,true);
    drawScaleSparkles([[8,-8,3],[10,6,2.7]],"rgba(255,255,255,.25)");

  }else if(t.body==="angel"){
    ctx.save();
    ctx.translate(-17,0);
    ctx.rotate(tailSwing*.75);
    const tail=ctx.createLinearGradient(-34,0,2,0);
    tail.addColorStop(0,"rgba(111,226,255,.22)");
    tail.addColorStop(1,`hsl(${hue+8},70%,55%)`);
    ctx.fillStyle=tail;
    ctx.strokeStyle=`hsl(${hue-14},54%,32%)`;
    ctx.lineWidth=1.5;
    ctx.beginPath();
    ctx.moveTo(0,0);
    ctx.quadraticCurveTo(-18,-20,-34,-14);
    ctx.quadraticCurveTo(-27,0,-34,16);
    ctx.quadraticCurveTo(-17,19,0,0);
    ctx.closePath();
    ctx.fill();ctx.stroke();
    ctx.restore();

    const body=ctx.createRadialGradient(7,-10,2,0,0,35);
    body.addColorStop(0,`hsl(${hue+18},92%,83%)`);
    body.addColorStop(.42,`hsl(${hue+4},80%,64%)`);
    body.addColorStop(.82,`hsl(${hue-14},67%,46%)`);
    body.addColorStop(1,`hsl(${hue-24},53%,31%)`);
    ctx.fillStyle=body;
    ctx.strokeStyle="#16455a";
    ctx.lineWidth=2;
    ctx.beginPath();
    ctx.moveTo(-19,0);
    ctx.quadraticCurveTo(-8,-20,16,-17);
    ctx.quadraticCurveTo(31,-4,19,14);
    ctx.quadraticCurveTo(-2,27,-19,0);
    ctx.closePath();
    ctx.fill();ctx.stroke();

    ctx.fillStyle=`hsla(${hue+22},88%,75%,.72)`;
    ctx.strokeStyle="#225d70";
    ctx.lineWidth=1.5;
    ctx.beginPath();
    ctx.moveTo(-2,-16);
    ctx.quadraticCurveTo(8,-37,17,-29);
    ctx.lineTo(10,-12);
    ctx.closePath();
    ctx.fill();ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(-4,15);
    ctx.quadraticCurveTo(5,38,17,28);
    ctx.lineTo(8,11);
    ctx.closePath();
    ctx.fill();ctx.stroke();

    ctx.strokeStyle="rgba(15,67,82,.6)";
    ctx.lineWidth=2.2;
    [-7,4,14].forEach(x=>{
      ctx.beginPath();ctx.moveTo(x,-15);ctx.lineTo(x+2,15);ctx.stroke();
    });
    drawFishEye(17,-4,5,.15);
    drawFishMouth(25,3,true);
    drawScaleSparkles([[-7,-7,3],[-2,2,3],[7,-4,3]],"rgba(255,255,255,.28)");

  }else if(t.body==="puffer"){
    ctx.save();
    ctx.translate(-17,1);
    ctx.rotate(tailSwing*.7);
    ctx.fillStyle="#d6a64b";
    ctx.strokeStyle="#765321";
    ctx.lineWidth=1.7;
    ctx.beginPath();
    ctx.moveTo(0,0);
    ctx.quadraticCurveTo(-16,-13,-27,-8);
    ctx.quadraticCurveTo(-22,0,-27,9);
    ctx.quadraticCurveTo(-14,14,0,0);
    ctx.closePath();
    ctx.fill();ctx.stroke();
    ctx.restore();

    for(let i=0;i<14;i++){
      const a=i*Math.PI*2/14;
      ctx.strokeStyle="#9d7530";
      ctx.lineWidth=1.7;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a)*19,Math.sin(a)*18);
      ctx.lineTo(Math.cos(a)*27,Math.sin(a)*25);
      ctx.stroke();
    }

    const body=ctx.createRadialGradient(8,-8,2,0,0,31);
    body.addColorStop(0,"#fff5af");
    body.addColorStop(.38,"#f6d76d");
    body.addColorStop(.78,"#d5a948");
    body.addColorStop(1,"#88682b");
    ctx.fillStyle=body;
    ctx.strokeStyle="#674c21";
    ctx.lineWidth=2.2;
    ctx.beginPath();
    ctx.ellipse(0,0,23,21,0,0,Math.PI*2);
    ctx.fill();ctx.stroke();

    ctx.fillStyle="#9b7a36";
    for(let i=0;i<9;i++){
      const a=i*.73;
      ctx.beginPath();
      ctx.arc(Math.cos(a)*12,Math.sin(a)*10,1.7+(i%2)*.5,0,Math.PI*2);
      ctx.fill();
    }

    ctx.fillStyle="rgba(255,232,119,.85)";
    ctx.beginPath();
    ctx.ellipse(-2,10,11,6,0,0,Math.PI*2);
    ctx.fill();
    drawFishEye(12,-5,5.8,.25);
    drawFishMouth(20,5,true);

  }else if(t.body==="betta"){
    ctx.save();
    ctx.translate(-22,0);
    ctx.rotate(tailSwing*.95);
    const tail=ctx.createLinearGradient(-30,0,4,0);
    tail.addColorStop(0,`hsla(${hue+32},92%,66%,.22)`);
    tail.addColorStop(.5,`hsl(${hue+12},88%,58%)`);
    tail.addColorStop(1,`hsl(${hue-8},78%,42%)`);
    ctx.fillStyle=tail;
    ctx.strokeStyle=`hsl(${hue-22},55%,30%)`;
    ctx.lineWidth=1.7;
    ctx.beginPath();
    ctx.moveTo(0,0);
    ctx.bezierCurveTo(-12,-16,-34,-28,-42,-10);
    ctx.bezierCurveTo(-34,-4,-30,4,-41,16);
    ctx.bezierCurveTo(-30,18,-12,15,0,0);
    ctx.closePath();
    ctx.fill();ctx.stroke();
    ctx.restore();

    const body=ctx.createRadialGradient(11,-7,2,1,1,29);
    body.addColorStop(0,`hsl(${hue+22},100%,82%)`);
    body.addColorStop(.35,`hsl(${hue+10},95%,62%)`);
    body.addColorStop(.8,`hsl(${hue-8},85%,46%)`);
    body.addColorStop(1,`hsl(${hue-20},70%,30%)`);
    ctx.fillStyle=body;
    ctx.strokeStyle=`hsl(${hue-22},52%,28%)`;
    ctx.lineWidth=2;
    ctx.beginPath();
    ctx.ellipse(2,0,26,15,0,0,Math.PI*2);
    ctx.fill();ctx.stroke();

    ctx.save();
    ctx.rotate(finSwing*.8);
    ctx.fillStyle=`hsla(${hue+18},90%,70%,.78)`;
    ctx.strokeStyle=`hsl(${hue-18},55%,32%)`;
    ctx.lineWidth=1.3;
    ctx.beginPath();
    ctx.moveTo(-4,-10);
    ctx.quadraticCurveTo(5,-33,16,-20);
    ctx.quadraticCurveTo(9,-9,2,-4);
    ctx.closePath();
    ctx.fill();ctx.stroke();
    ctx.restore();

    ctx.save();
    ctx.rotate(-finSwing*.7);
    ctx.beginPath();
    ctx.moveTo(-1,9);
    ctx.quadraticCurveTo(12,30,22,19);
    ctx.quadraticCurveTo(10,14,3,8);
    ctx.closePath();
    ctx.fill();ctx.stroke();
    ctx.restore();

    drawScaleSparkles([[-9,-5,2.7],[-1,-8,2.5],[8,-2,2.8],[2,7,2.5]],"rgba(255,255,255,.28)");
    drawFishEye(18,-4,5.2,.18);
    drawFishMouth(27,4,true);

  }else if(t.body==="tang"){
    ctx.save();
    ctx.translate(-17,0);
    ctx.rotate(tailSwing*.85);
    ctx.fillStyle="#f4d74c";
    ctx.strokeStyle="#785f12";
    ctx.lineWidth=1.9;
    ctx.beginPath();
    ctx.moveTo(0,0);
    ctx.quadraticCurveTo(-18,-16,-28,-11);
    ctx.quadraticCurveTo(-22,0,-28,12);
    ctx.quadraticCurveTo(-16,16,0,0);
    ctx.closePath();
    ctx.fill();ctx.stroke();
    ctx.restore();

    const body=ctx.createRadialGradient(9,-8,2,0,0,33);
    body.addColorStop(0,"#82d9ff");
    body.addColorStop(.28,"#49b2f8");
    body.addColorStop(.8,"#2159c5");
    body.addColorStop(1,"#163a83");
    ctx.fillStyle=body;
    ctx.strokeStyle="#0e2d66";
    ctx.lineWidth=2.1;
    ctx.beginPath();
    ctx.ellipse(1,0,24,20,0,0,Math.PI*2);
    ctx.fill();ctx.stroke();

    ctx.strokeStyle="#0a1a44";
    ctx.lineWidth=4.6;
    ctx.beginPath();
    ctx.moveTo(-8,-10);
    ctx.quadraticCurveTo(2,-2,10,8);
    ctx.stroke();

    ctx.fillStyle="rgba(255,255,255,.26)";
    ctx.beginPath();ctx.ellipse(-2,-6,9,5,-.2,0,Math.PI*2);ctx.fill();
    drawFishEye(12,-5,5.2,.2);
    drawFishMouth(19,4,true);

  }else if(t.body==="koi"){
    ctx.save();
    ctx.translate(-22,0);
    ctx.rotate(tailSwing*.65);
    ctx.fillStyle="#f59d47";
    ctx.strokeStyle="#8d4d18";
    ctx.lineWidth=1.8;
    ctx.beginPath();
    ctx.moveTo(0,0);
    ctx.bezierCurveTo(-18,-20,-34,-16,-40,-8);
    ctx.bezierCurveTo(-31,-3,-30,3,-40,10);
    ctx.bezierCurveTo(-26,16,-12,13,0,0);
    ctx.closePath();
    ctx.fill();ctx.stroke();
    ctx.restore();

    const body=ctx.createLinearGradient(-26,-12,29,12);
    body.addColorStop(0,"#fff6eb");
    body.addColorStop(.45,"#ffe6d2");
    body.addColorStop(1,"#ffd0a3");
    ctx.fillStyle=body;
    ctx.strokeStyle="#89512b";
    ctx.lineWidth=2;
    ctx.beginPath();
    ctx.moveTo(-24,0);
    ctx.quadraticCurveTo(-8,-18,16,-15);
    ctx.quadraticCurveTo(31,-8,30,3);
    ctx.quadraticCurveTo(22,17,-1,18);
    ctx.quadraticCurveTo(-18,15,-24,0);
    ctx.closePath();
    ctx.fill();ctx.stroke();

    ctx.fillStyle="#f28c38";
    [[-7,-6,8,5],[6,4,10,6],[10,-7,8,5]].forEach(p=>{
      ctx.beginPath();ctx.ellipse(p[0],p[1],p[2],p[3],.18,0,Math.PI*2);ctx.fill();
    });
    ctx.fillStyle="#1d1d1d";
    ctx.beginPath();ctx.arc(-6,1,2.2,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(12,9,1.7,0,Math.PI*2);ctx.fill();

    ctx.fillStyle="rgba(255,170,70,.4)";
    ctx.beginPath();ctx.ellipse(0,9,11,6,.1,0,Math.PI*2);ctx.fill();
    drawFishEye(18,-4,5.2,.18);
    drawFishMouth(26,4,true);

  }else if(t.body==="lion"){
    ctx.save();
    ctx.translate(-20,0);
    ctx.rotate(tailSwing*.72);
    ctx.fillStyle="#f0b058";
    ctx.strokeStyle="#84461a";
    ctx.lineWidth=1.9;
    ctx.beginPath();
    ctx.moveTo(0,0);
    ctx.quadraticCurveTo(-18,-18,-33,-12);
    ctx.quadraticCurveTo(-27,0,-33,13);
    ctx.quadraticCurveTo(-18,18,0,0);
    ctx.closePath();
    ctx.fill();ctx.stroke();
    ctx.restore();

    for(let i=0;i<8;i++){
      const x=-6+i*4.7;
      const tip=-20-(i%2)*7;
      ctx.strokeStyle="#9d5a2b";
      ctx.lineWidth=1.4;
      ctx.beginPath();ctx.moveTo(x,-8);ctx.lineTo(x+2,tip);ctx.stroke();
    }
    for(let i=0;i<7;i++){
      const x=-5+i*4.8;
      const tip=18+(i%2)*5;
      ctx.beginPath();ctx.moveTo(x,8);ctx.lineTo(x+2,tip);ctx.stroke();
    }

    const body=ctx.createRadialGradient(8,-8,2,0,0,30);
    body.addColorStop(0,"#ffe1af");
    body.addColorStop(.36,"#f6b86a");
    body.addColorStop(.8,"#d57b34");
    body.addColorStop(1,"#8e4f22");
    ctx.fillStyle=body;
    ctx.strokeStyle="#6f3d1b";
    ctx.lineWidth=2;
    ctx.beginPath();
    ctx.ellipse(1,0,25,15,0,0,Math.PI*2);
    ctx.fill();ctx.stroke();

    ctx.save();
    ctx.clip();
    [-11,-2,7,16].forEach(x=>{
      ctx.strokeStyle="rgba(132,61,17,.9)";
      ctx.lineWidth=4;
      ctx.beginPath();ctx.moveTo(x,-18);ctx.lineTo(x+3,18);ctx.stroke();
    });
    ctx.restore();

    drawFishEye(18,-4,5.2,.18);
    drawFishMouth(26,4,true);

  }else if(t.body==="shark"){
    ctx.save();
    ctx.translate(-26,0);
    ctx.rotate(tailSwing*.55);
    const tail=ctx.createLinearGradient(-34,0,0,0);
    tail.addColorStop(0,"#6c99b1");
    tail.addColorStop(1,"#9ec6d7");
    ctx.fillStyle=tail;
    ctx.strokeStyle="#31566a";
    ctx.lineWidth=2;
    ctx.beginPath();
    ctx.moveTo(0,0);
    ctx.lineTo(-30,-18);
    ctx.lineTo(-24,-3);
    ctx.lineTo(-37,0);
    ctx.lineTo(-24,4);
    ctx.lineTo(-30,19);
    ctx.closePath();
    ctx.fill();ctx.stroke();
    ctx.restore();

    const body=ctx.createLinearGradient(-30,-12,30,13);
    body.addColorStop(0,"#4f8099");
    body.addColorStop(.32,"#8fb9ca");
    body.addColorStop(.6,"#b7d7e3");
    body.addColorStop(1,"#5c8ba2");
    ctx.fillStyle=body;
    ctx.strokeStyle="#284d60";
    ctx.lineWidth=2.3;
    ctx.beginPath();
    ctx.moveTo(-29,0);
    ctx.quadraticCurveTo(-7,-18,19,-13);
    ctx.quadraticCurveTo(35,-7,34,3);
    ctx.quadraticCurveTo(26,18,-3,16);
    ctx.quadraticCurveTo(-23,13,-29,0);
    ctx.closePath();
    ctx.fill();ctx.stroke();

    ctx.fillStyle="#5f93aa";
    ctx.strokeStyle="#284d60";
    ctx.lineWidth=1.7;
    ctx.beginPath();
    ctx.moveTo(-2,-13);
    ctx.lineTo(8,-29);
    ctx.lineTo(16,-10);
    ctx.closePath();
    ctx.fill();ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(-2,12);
    ctx.lineTo(15,23);
    ctx.lineTo(8,9);
    ctx.closePath();
    ctx.fill();ctx.stroke();

    ctx.fillStyle="rgba(232,249,251,.72)";
    ctx.beginPath();
    ctx.ellipse(9,7,18,7,-.08,0,Math.PI*2);
    ctx.fill();

    drawFishEye(21,-5,5.2,.2);
    ctx.strokeStyle="#31566a";
    ctx.lineWidth=1.8;
    ctx.beginPath();
    ctx.arc(25,4,7,.05,.95);
    ctx.stroke();
    ctx.fillStyle="#ffffff";
    for(let i=0;i<3;i++){
      ctx.beginPath();
      ctx.moveTo(23+i*4,6);
      ctx.lineTo(25+i*4,10);
      ctx.lineTo(27+i*4,6);
      ctx.fill();
    }
    drawScaleSparkles([[-2,-7,4],[9,-9,3.2],[15,2,3]],"rgba(255,255,255,.27)");
  }

  ctx.shadowColor="transparent";

  const shine=ctx.createLinearGradient(0,-20,0,8);
  shine.addColorStop(0,"rgba(255,255,255,.38)");
  shine.addColorStop(1,"rgba(255,255,255,0)");
  ctx.fillStyle=shine;
  ctx.beginPath();
  ctx.ellipse(4,-8,13,4,-.18,0,Math.PI*2);
  ctx.fill();

  ctx.restore();

  drawFishEventBuff(f);
  drawElectricScar(f);
  const maxHealth=f.maxHealth||t.maxHealth||100;
  const hpRatio=Math.max(0,Math.min(1,f.health/maxHealth));
  if(hpRatio<.92){
    const w=48*f.size;
    ctx.fillStyle="rgba(3,28,47,.78)";
    drawRoundRect(f.x-w/2,f.y-43*f.size,w,5,3);ctx.fill();
    ctx.fillStyle=hpRatio<.35?"#ff5d78":"#63e6a6";
    drawRoundRect(f.x-w/2,f.y-43*f.size,w*hpRatio,5,3);ctx.fill();
  }
  if(f.hunger>72){
    const w=48*f.size;
    ctx.fillStyle="rgba(3,28,47,.78)";
    drawRoundRect(f.x-w/2,f.y-35*f.size,w,5,3);ctx.fill();
    ctx.fillStyle=f.hunger>100?"#ff7390":"#ffd766";
    drawRoundRect(f.x-w/2,f.y-35*f.size,w*Math.max(0,1-f.hunger/130),5,3);ctx.fill();
  }

  const status=getFishStatus(f);
  const important=status.level>=2;
  const periodic=Math.sin(state.elapsed*.72+(f.statusPhase||0))>.80;
  if(important||periodic){
    ctx.save();
    const label=`${status.emoji} ${status.label}`;
    const statusFont=Math.min(9.5,7.5+f.size);
    ctx.font=`700 ${statusFont}px system-ui,sans-serif`;
    const bw=Math.min(82,Math.max(36,ctx.measureText(label).width+12));
    const bx=Math.max(5,Math.min(W-bw-5,f.x-bw/2));
    const by=Math.max(tankTop+5,f.y-54*f.size);
    ctx.fillStyle="rgba(255,255,255,.92)";
    ctx.strokeStyle="rgba(4,51,70,.32)";
    ctx.lineWidth=.9;
    drawRoundRect(bx,by,bw,18,9);ctx.fill();ctx.stroke();
    ctx.beginPath();ctx.moveTo(f.x-3,by+17);ctx.lineTo(f.x+2,by+23);ctx.lineTo(f.x+6,by+17);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.fillStyle="#10394c";
    ctx.textAlign="center";ctx.textBaseline="middle";
    ctx.fillText(label,bx+bw/2,by+9);
    ctx.restore();
  }
}

function drawFishEventBuff(f){
  const buffs=fishPermanentBuffKeys(f);
  if(!buffs.length) return;

  const activeKey=state.activeEvent&&buffs.includes(state.activeEvent.key)
    ? state.activeEvent.key
    : buffs[Math.floor(state.elapsed/1.4)%buffs.length];
  const type=EVENT_TYPES[activeKey]||EVENT_TYPES[buffs[0]];
  const pulse=.5+.5*Math.sin(state.elapsed*4+(f.statusPhase||0));
  const radius=(24+4*pulse)*f.size;

  ctx.save();
  ctx.translate(f.x,f.y);
  ctx.globalAlpha=.25+.20*pulse;
  ctx.lineWidth=1.5+f.size*.25;

  if(activeKey==="rainbow"){
    ["#ff6688","#ffd45d","#5ee7a4","#61c9ff","#b77cff"].forEach((c,i)=>{
      ctx.strokeStyle=c;ctx.beginPath();
      ctx.arc(0,0,radius+i*.9,i*.85,i*.85+1.05);ctx.stroke();
    });
  }else if(activeKey==="storm"){
    ctx.strokeStyle="#8bd8ff";
    ctx.beginPath();ctx.arc(0,0,radius,0,Math.PI*2);ctx.stroke();
    ctx.beginPath();ctx.moveTo(-5,-radius);ctx.lineTo(1,-radius-7);
    ctx.lineTo(-1,-radius-1);ctx.lineTo(6,-radius-8);ctx.stroke();
  }else if(activeKey==="gold"){
    ctx.strokeStyle="#ffe173";ctx.lineWidth=2;
    ctx.beginPath();ctx.arc(0,0,radius,0,Math.PI*2);ctx.stroke();
    for(let i=0;i<4;i++){
      const a=i*Math.PI*.5+state.elapsed*.35;
      ctx.fillStyle="#fff2a5";ctx.beginPath();
      ctx.arc(Math.cos(a)*radius,Math.sin(a)*radius,1.3+pulse,0,Math.PI*2);ctx.fill();
    }
  }else{
    ctx.strokeStyle="#abfff4";
    ctx.beginPath();ctx.arc(0,0,radius,0,Math.PI*2);ctx.stroke();
    ctx.strokeStyle="#d7c7ff";
    ctx.beginPath();ctx.arc(0,0,radius-4,0,Math.PI*2);ctx.stroke();
  }
  ctx.restore();

  const iconSize=8;
  const gap=2;
  const total=buffs.length*iconSize+(buffs.length-1)*gap;
  const startX=f.x-total/2+iconSize/2;
  const y=f.y-23*f.size;

  ctx.save();
  ctx.font="9px system-ui,sans-serif";
  ctx.textAlign="center";ctx.textBaseline="middle";
  buffs.forEach((key,i)=>{
    const x=startX+i*(iconSize+gap);
    ctx.fillStyle="rgba(3,25,43,.82)";
    ctx.strokeStyle="rgba(255,255,255,.38)";
    ctx.lineWidth=.8;
    ctx.beginPath();ctx.arc(x,y,6.7,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillText(EVENT_TYPES[key].icon,x,y+.3);
  });
  ctx.restore();
}

function drawElectricEel(eel){
  if(state.elapsed<eel.launchAt)return;
  const wave=Math.sin(eel.wobble)*5;
  ctx.save();ctx.translate(eel.x,eel.y);ctx.scale(eel.dir*eel.scale,eel.scale);
  ctx.shadowColor="#8af7ff";ctx.shadowBlur=15;ctx.strokeStyle="rgba(155,250,255,.45)";ctx.lineWidth=7;
  ctx.beginPath();ctx.moveTo(-48,0);ctx.bezierCurveTo(-28,-14+wave,-8,14-wave,12,0);ctx.bezierCurveTo(30,-11-wave,45,8+wave,54,0);ctx.stroke();
  const body=ctx.createLinearGradient(-50,-8,55,9);body.addColorStop(0,"#273c4e");body.addColorStop(.22,"#3e7482");body.addColorStop(.52,"#67b7a7");body.addColorStop(.78,"#d7d94f");body.addColorStop(1,"#887f22");
  ctx.strokeStyle=body;ctx.lineWidth=12;ctx.lineCap="round";ctx.beginPath();ctx.moveTo(-49,0);ctx.bezierCurveTo(-29,-13+wave,-7,13-wave,13,0);ctx.bezierCurveTo(30,-10-wave,43,7+wave,51,0);ctx.stroke();
  ctx.shadowBlur=0;ctx.strokeStyle="rgba(235,255,184,.62)";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-43,3);ctx.bezierCurveTo(-25,-7+wave,-6,15-wave,15,3);ctx.bezierCurveTo(31,-6-wave,42,9+wave,49,3);ctx.stroke();
  const head=ctx.createRadialGradient(43,-5,2,45,0,15);head.addColorStop(0,"#f4ef7a");head.addColorStop(.55,"#b8b544");head.addColorStop(1,"#5d612e");
  ctx.fillStyle=head;ctx.strokeStyle="#333d35";ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(48,0,15,10,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(53,-3,3.2,0,Math.PI*2);ctx.fill();ctx.fillStyle="#14252c";ctx.beginPath();ctx.arc(54,-3,1.5,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle="#39412f";ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(57,3,4,.1,.95);ctx.stroke();
  ctx.strokeStyle="#fff48a";ctx.lineWidth=2.2;
  for(let i=0;i<4;i++){const x=-28+i*18;ctx.beginPath();ctx.moveTo(x,-5);ctx.lineTo(x+5,0);ctx.lineTo(x+1,5);ctx.lineTo(x+9,1);ctx.stroke();}
  ctx.strokeStyle="#bafaff";ctx.lineWidth=1.4;
  for(let i=0;i<3;i++){const x=-32+i*34,y=-14+(i%2)*27;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+5,y-4);ctx.lineTo(x+3,y+2);ctx.lineTo(x+9,y-2);ctx.stroke();}
  ctx.restore();
}

function drawShockFx(fx){
  const alpha=Math.max(0,fx.life/fx.maxLife);ctx.save();ctx.lineCap="round";
  for(let layer=0;layer<3;layer++){
    ctx.strokeStyle=layer===0?"#fff":layer===1?"#74edff":"#9d73ff";ctx.lineWidth=layer===0?2.2:layer===1?4.5:7.5;ctx.globalAlpha=alpha*(layer===0?1:layer===1?.65:.25);ctx.beginPath();
    const segments=7;
    for(let i=0;i<=segments;i++){const t=i/segments,x=fx.x1+(fx.x2-fx.x1)*t,y=fx.y1+(fx.y2-fx.y1)*t,j=i===0||i===segments?0:Math.sin(fx.seed+i*8.7+state.elapsed*45)*9;if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y+j);}
    ctx.stroke();
  }
  ctx.restore();
}

function drawElectricScar(f){
  if(!f.electricScar&&state.elapsed>=(f.shockFlashUntil||0))return;
  const flashing=state.elapsed<(f.shockFlashUntil||0),pulse=.5+.5*Math.sin(state.elapsed*(flashing?24:5)+(f.statusPhase||0)),radius=(26+5*pulse)*f.size;
  ctx.save();ctx.translate(f.x,f.y);ctx.strokeStyle=flashing?"#e9ffff":"#ff536c";ctx.lineWidth=flashing?3:1.8;ctx.globalAlpha=flashing?.85:.28+.18*pulse;
  for(let i=0;i<3;i++){const start=i*Math.PI*2/3+state.elapsed*.7;ctx.beginPath();ctx.arc(0,0,radius+i*2,start,start+.82);ctx.stroke();}
  if(flashing){ctx.strokeStyle="#72efff";ctx.lineWidth=2;for(let i=0;i<4;i++){const a=i*Math.PI*.5+state.elapsed*3,x=Math.cos(a)*radius,y=Math.sin(a)*radius;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+Math.cos(a+.5)*7,y+Math.sin(a+.5)*7);ctx.lineTo(x+Math.cos(a-.5)*12,y+Math.sin(a-.5)*12);ctx.stroke();}}
  ctx.restore();
  if(f.electricScar){const x=f.x+27*f.size,y=f.y-23*f.size;ctx.save();ctx.fillStyle="rgba(82,0,20,.88)";ctx.strokeStyle="#ff9aa8";ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(x,y,7.6,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.font="10px system-ui,sans-serif";ctx.textAlign="center";ctx.textBaseline="middle";ctx.fillText("⚡",x,y+.3);ctx.restore();}
}

function drawGuardian(g){
  const gt=g.typeData||GUARDIAN_TYPES[g.typeKey]||GUARDIAN_TYPES.sword;
  ctx.save();
  ctx.translate(g.x,g.y);
  ctx.scale(g.dir,1);
  ctx.rotate(Math.sin(g.wobble)*.045);
  const tailSwing=Math.sin(g.wobble*1.7)*.18;

  if(gt.body==="sword"){
    ctx.save();ctx.translate(-24,0);ctx.rotate(tailSwing);
    const tail=ctx.createLinearGradient(-35,0,0,0);
    tail.addColorStop(0,"#70dcff");tail.addColorStop(1,"#1c82b8");
    ctx.fillStyle=tail;ctx.strokeStyle="#164f75";ctx.lineWidth=2;
    ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(-31,-19);ctx.lineTo(-24,-3);ctx.lineTo(-38,0);ctx.lineTo(-24,4);ctx.lineTo(-31,19);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.restore();

    const body=ctx.createRadialGradient(9,-8,2,0,0,34);
    body.addColorStop(0,"#dcfbff");body.addColorStop(.35,"#70d8f4");body.addColorStop(.72,"#258ebf");body.addColorStop(1,"#155a86");
    ctx.fillStyle=body;ctx.strokeStyle="#103f64";ctx.lineWidth=2.4;
    ctx.beginPath();ctx.moveTo(-27,0);ctx.quadraticCurveTo(-7,-19,20,-14);ctx.quadraticCurveTo(35,-5,31,7);ctx.quadraticCurveTo(22,19,-7,16);ctx.quadraticCurveTo(-24,12,-27,0);ctx.closePath();ctx.fill();ctx.stroke();

    ctx.fillStyle="#f5cc5b";ctx.strokeStyle="#8b671b";ctx.lineWidth=1.6;
    ctx.beginPath();ctx.moveTo(-4,-13);ctx.lineTo(6,-27);ctx.lineTo(14,-11);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.beginPath();ctx.moveTo(-3,12);ctx.lineTo(13,23);ctx.lineTo(7,9);ctx.closePath();ctx.fill();ctx.stroke();
    drawFishEye(20,-4,5.2,.15);drawFishMouth(29,4,false);

  }else if(gt.body==="puffer"){
    ctx.save();ctx.translate(-18,1);ctx.rotate(tailSwing*.7);
    ctx.fillStyle="#dbab48";ctx.strokeStyle="#765321";ctx.lineWidth=1.8;
    ctx.beginPath();ctx.moveTo(0,0);ctx.quadraticCurveTo(-18,-14,-30,-8);ctx.quadraticCurveTo(-24,0,-30,10);ctx.quadraticCurveTo(-16,15,0,0);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();

    for(let i=0;i<13;i++){
      const a=i*Math.PI*2/13;
      ctx.strokeStyle="#826325";ctx.lineWidth=1.5;
      ctx.beginPath();ctx.moveTo(Math.cos(a)*20,Math.sin(a)*18);ctx.lineTo(Math.cos(a)*28,Math.sin(a)*25);ctx.stroke();
    }
    const body=ctx.createRadialGradient(8,-9,2,0,0,32);
    body.addColorStop(0,"#fff4ab");body.addColorStop(.42,"#f5d46a");body.addColorStop(.8,"#c99b3e");body.addColorStop(1,"#765522");
    ctx.fillStyle=body;ctx.strokeStyle="#60451c";ctx.lineWidth=2.3;
    ctx.beginPath();ctx.ellipse(0,0,24,22,0,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle="#247ba0";ctx.strokeStyle="#12445d";ctx.lineWidth=1.4;
    ctx.beginPath();ctx.roundRect(-12,-5,14,10,4);ctx.fill();ctx.stroke();
    ctx.beginPath();ctx.moveTo(0,-1);ctx.lineTo(19,-1);ctx.lineTo(19,4);ctx.lineTo(0,4);ctx.closePath();ctx.fill();ctx.stroke();
    drawFishEye(13,-6,5.7,.15);drawFishMouth(21,5,false);

  }else if(gt.body==="ray"){
    const wing=ctx.createLinearGradient(-34,-20,32,20);
    wing.addColorStop(0,"#6142bd");wing.addColorStop(.42,"#a78cff");wing.addColorStop(.72,"#7ce8ff");wing.addColorStop(1,"#3b62b5");
    ctx.fillStyle=wing;ctx.strokeStyle="#38227f";ctx.lineWidth=2.2;
    ctx.beginPath();
    ctx.moveTo(-35,-2);ctx.quadraticCurveTo(-10,-25,3,-11);ctx.quadraticCurveTo(18,-25,38,-2);
    ctx.quadraticCurveTo(18,12,3,9);ctx.quadraticCurveTo(-14,14,-35,-2);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.strokeStyle="#b8f6ff";ctx.lineWidth=2.5;
    ctx.beginPath();ctx.moveTo(-4,8);ctx.quadraticCurveTo(-12,25,-22,34);ctx.stroke();
    ctx.fillStyle="rgba(255,255,255,.4)";
    ctx.beginPath();ctx.ellipse(3,-7,14,4,-.1,0,Math.PI*2);ctx.fill();
    drawFishEye(12,-4,4.5,.1);
    ctx.strokeStyle="#efe7ff";ctx.lineWidth=1.4;
    ctx.beginPath();ctx.moveTo(-20,1);ctx.lineTo(-7,-8);ctx.lineTo(4,1);ctx.lineTo(18,-9);ctx.stroke();

  }else{
    ctx.save();ctx.translate(-28,0);ctx.rotate(tailSwing*.55);
    const tail=ctx.createLinearGradient(-36,0,0,0);
    tail.addColorStop(0,"#5a86a1");tail.addColorStop(1,"#a9d9e8");
    ctx.fillStyle=tail;ctx.strokeStyle="#263f60";ctx.lineWidth=2.3;
    ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(-31,-21);ctx.lineTo(-25,-5);ctx.lineTo(-40,0);ctx.lineTo(-25,5);ctx.lineTo(-31,21);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();

    const body=ctx.createLinearGradient(-31,-13,35,16);
    body.addColorStop(0,"#244c72");body.addColorStop(.36,"#4f8eb2");body.addColorStop(.62,"#bde7ef");body.addColorStop(1,"#315d83");
    ctx.fillStyle=body;ctx.strokeStyle="#182f50";ctx.lineWidth=2.5;
    ctx.beginPath();ctx.moveTo(-30,0);ctx.quadraticCurveTo(-7,-20,23,-14);ctx.quadraticCurveTo(39,-7,38,4);ctx.quadraticCurveTo(28,20,-5,17);ctx.quadraticCurveTo(-24,13,-30,0);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.fillStyle="#f6cf58";ctx.strokeStyle="#765c17";ctx.lineWidth=1.7;
    ctx.beginPath();ctx.moveTo(-2,-13);ctx.lineTo(8,-31);ctx.lineTo(18,-11);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.beginPath();ctx.moveTo(-1,12);ctx.lineTo(17,24);ctx.lineTo(8,9);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.beginPath();ctx.arc(2,2,9,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle="#225778";ctx.beginPath();ctx.moveTo(2,-4);ctx.lineTo(7,0);ctx.lineTo(5,7);ctx.lineTo(2,9);ctx.lineTo(-1,7);ctx.lineTo(-3,0);ctx.closePath();ctx.fill();
    drawFishEye(23,-5,5.1,.2);drawFishMouth(32,4,false);
  }

  ctx.restore();

  ctx.save();
  ctx.font="700 8.5px system-ui,sans-serif";
  ctx.textAlign="center";ctx.textBaseline="middle";
  const eventIcon=state.activeEvent&&g.eventBuff===state.activeEvent.key?`${state.activeEvent.type.icon} `:"";
  const label=eventIcon+(g.target?"⚔️ ป้องกัน":`${gt.emoji} เฝ้าระวัง`);
  const bw=Math.min(70,Math.max(43,ctx.measureText(label).width+10));
  ctx.fillStyle="rgba(3,35,53,.80)";
  drawRoundRect(g.x-bw/2,g.y-37,bw,16,8);ctx.fill();
  ctx.fillStyle="#fff4a8";ctx.fillText(label,g.x,g.y-29);
  ctx.restore();
}

function drawGuardShot(s){
  const progress=1-s.life/s.maxLife;
  const x=s.x+(s.tx-s.x)*progress;
  const y=s.y+(s.ty-s.y)*progress;
  ctx.save();
  ctx.globalCompositeOperation="screen";
  const power=s.power||1;
  ctx.strokeStyle=s.color||"rgba(161,239,255,.82)";ctx.globalAlpha=.78;ctx.lineWidth=2.4+power;
  ctx.beginPath();ctx.moveTo(s.x,s.y);ctx.lineTo(x,y);ctx.stroke();
  ctx.globalAlpha=1;
  ctx.fillStyle="#f2feff";ctx.beginPath();ctx.arc(x,y,4.5+power*1.4,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle=s.color||"rgba(104,216,255,.72)";ctx.lineWidth=1.2+power*.35;
  ctx.beginPath();ctx.arc(x,y,7+power*2.2,0,Math.PI*2);ctx.stroke();
  ctx.restore();
}
