/* ระบบตั้งค่าเสียง เอฟเฟกต์เสียง เพลง และเสียงอีเวนต์ */
"use strict";

function loadAudioSettings(){
  try{
    const saved=JSON.parse(localStorage.getItem(AUDIO_SETTINGS_KEY)||"null");
    return {
      sfxEnabled:saved?.sfxEnabled!==false,
      musicEnabled:saved?.musicEnabled!==false,
      sfxVolume:Number.isFinite(Number(saved?.sfxVolume))
        ? Math.max(0,Math.min(100,Number(saved.sfxVolume)))
        : 100,
      musicVolume:Number.isFinite(Number(saved?.musicVolume))
        ? Math.max(0,Math.min(100,Number(saved.musicVolume)))
        : 100
    };
  }catch(e){
    return {sfxEnabled:true,musicEnabled:true,sfxVolume:100,musicVolume:100};
  }
}
const audioSettings=loadAudioSettings();
function saveAudioSettings(){
  try{
    localStorage.setItem(AUDIO_SETTINGS_KEY,JSON.stringify(audioSettings));
  }catch(e){}
}

function updateAudioSettingsUI(){
  const sfxBtn=$("sfxToggleBtn");
  const musicBtn=$("musicToggleBtn");
  const sfxSlider=$("sfxVolumeSlider");
  const musicSlider=$("musicVolumeSlider");
  const sfxValue=$("sfxVolumeValue");
  const musicValue=$("musicVolumeValue");
  const status=$("audioStatus");

  if(sfxBtn){
    sfxBtn.textContent=audioSettings.sfxEnabled?"เปิด":"ปิด";
    sfxBtn.classList.toggle("on",audioSettings.sfxEnabled);
    sfxBtn.setAttribute("aria-pressed",String(audioSettings.sfxEnabled));
  }
  if(musicBtn){
    musicBtn.textContent=audioSettings.musicEnabled?"เปิด":"ปิด";
    musicBtn.classList.toggle("on",audioSettings.musicEnabled);
    musicBtn.setAttribute("aria-pressed",String(audioSettings.musicEnabled));
  }
  if(sfxSlider) sfxSlider.value=String(Math.round(audioSettings.sfxVolume));
  if(musicSlider) musicSlider.value=String(Math.round(audioSettings.musicVolume));
  if(sfxValue) sfxValue.textContent=`${Math.round(audioSettings.sfxVolume)}%`;
  if(musicValue) musicValue.textContent=`${Math.round(audioSettings.musicVolume)}%`;

  if(status){
    status.textContent=
      `เสียงประกอบ ${Math.round(audioSettings.sfxVolume)}% (${audioSettings.sfxEnabled?"เปิด":"ปิด"})`
      + ` • ดนตรี ${Math.round(audioSettings.musicVolume)}% (${audioSettings.musicEnabled?"เปิด":"ปิด"})`
      + " • ระดับสูงสุด 500%";
  }
}

function openAudioSettings(){
  settingsResumeOnClose=running&&!paused;
  if(settingsResumeOnClose){
    paused=true;
    syncBackgroundMusic();
  }
  updateAudioSettingsUI();
  $("settingsOverlay").classList.remove("hidden");
  updateEventScheduleUI(true);
  ensureAudio();
  syncBackgroundMusic();
  syncEventAmbientSound();
}

function closeAudioSettings(){
  $("settingsOverlay").classList.add("hidden");
  updateEventScheduleUI(true);
  if(settingsResumeOnClose){
    paused=false;
    last=performance.now();
    lastDraw=last;
  }
  settingsResumeOnClose=false;
  syncBackgroundMusic();
  syncEventAmbientSound();
}

const SFX_FULL_VOLUME_GAIN=8.75;
const MUSIC_FULL_VOLUME_GAIN=14.00;

function volumePercent(value){
  return Math.max(0,Math.min(1,Number(value)/100));
}

function sfxVolumeGain(){
  return SFX_FULL_VOLUME_GAIN*volumePercent(audioSettings.sfxVolume);
}

function musicVolumeGain(){
  return MUSIC_FULL_VOLUME_GAIN*volumePercent(audioSettings.musicVolume);
}

function ensureAudio(){
  if(!audioCtx){
    const AudioClass=window.AudioContext||window.webkitAudioContext;
    if(!AudioClass) return false;
    audioCtx=new AudioClass();

    audioCompressor=audioCtx.createDynamicsCompressor();
    audioCompressor.threshold.value=-6;
    audioCompressor.knee.value=12;
    audioCompressor.ratio.value=12;
    audioCompressor.attack.value=.002;
    audioCompressor.release.value=.18;

    audioSfxGain=audioCtx.createGain();
    audioMusicGain=audioCtx.createGain();
    audioMaster=audioCtx.createGain();

    audioSfxGain.gain.value=audioSettings.sfxEnabled
      ? Math.max(.0001,sfxVolumeGain())
      : .0001;
    audioMusicGain.gain.value=.0001;
    audioMaster.gain.value=1.0;

    audioSfxGain.connect(audioCompressor);
    audioMusicGain.connect(audioCompressor);
    audioCompressor.connect(audioMaster);
    audioMaster.connect(audioCtx.destination);

    const length=Math.max(1,Math.floor(audioCtx.sampleRate*.5));
    audioNoiseBuffer=audioCtx.createBuffer(1,length,audioCtx.sampleRate);
    const data=audioNoiseBuffer.getChannelData(0);
    for(let i=0;i<length;i++) data[i]=(Math.random()*2-1)*(1-i/length);
  }
  if(audioCtx.state==="suspended") audioCtx.resume().catch(()=>{});
  return true;
}

function audioOutput(){
  return audioSfxGain||audioCompressor||audioCtx?.destination;
}

function playTone(freq=440,dur=.08,type="sine",gain=.025,delay=0,endFreq=freq,pan=0){
  if(!audioSettings.sfxEnabled||!ensureAudio()) return;
  const now=audioCtx.currentTime+Math.max(0,delay);
  const stop=now+Math.max(.025,dur);
  const osc=audioCtx.createOscillator();
  const amp=audioCtx.createGain();

  osc.type=type;
  osc.frequency.setValueAtTime(Math.max(20,freq),now);
  if(endFreq&&endFreq!==freq){
    osc.frequency.exponentialRampToValueAtTime(Math.max(20,endFreq),stop);
  }

  amp.gain.setValueAtTime(.0001,now);
  amp.gain.exponentialRampToValueAtTime(Math.max(.0002,gain*1.28),now+Math.min(.018,dur*.25));
  amp.gain.exponentialRampToValueAtTime(.0001,stop);

  osc.connect(amp);
  if(audioCtx.createStereoPanner){
    const panner=audioCtx.createStereoPanner();
    panner.pan.value=Math.max(-1,Math.min(1,pan));
    amp.connect(panner);
    panner.connect(audioOutput());
  }else{
    amp.connect(audioOutput());
  }

  osc.start(now);
  osc.stop(stop+.02);
}

function playNoise(dur=.08,gain=.012,frequency=900,type="bandpass",delay=0,pan=0){
  if(!audioSettings.sfxEnabled||!ensureAudio()||!audioNoiseBuffer) return;
  const now=audioCtx.currentTime+Math.max(0,delay);
  const stop=now+Math.max(.025,dur);
  const source=audioCtx.createBufferSource();
  const filter=audioCtx.createBiquadFilter();
  const amp=audioCtx.createGain();

  source.buffer=audioNoiseBuffer;
  filter.type=type;
  filter.frequency.setValueAtTime(Math.max(80,frequency),now);
  filter.Q.value=type==="bandpass"?1.1:.5;

  amp.gain.setValueAtTime(Math.max(.0002,gain*1.18),now);
  amp.gain.exponentialRampToValueAtTime(.0001,stop);

  source.connect(filter);
  filter.connect(amp);
  if(audioCtx.createStereoPanner){
    const panner=audioCtx.createStereoPanner();
    panner.pan.value=Math.max(-1,Math.min(1,pan));
    amp.connect(panner);
    panner.connect(audioOutput());
  }else{
    amp.connect(audioOutput());
  }

  source.start(now,Math.random()*.12);
  source.stop(stop+.02);
}

function playMusicTone(freq=220,dur=3,gain=.018,delay=0,pan=0){
  if(!audioSettings.musicEnabled||!ensureAudio()||!audioMusicGain) return;

  const now=audioCtx.currentTime+Math.max(0,delay);
  const stop=now+Math.max(.25,dur);
  const osc=audioCtx.createOscillator();
  const shimmer=audioCtx.createOscillator();
  const filter=audioCtx.createBiquadFilter();
  const amp=audioCtx.createGain();

  osc.type="sine";
  shimmer.type="triangle";
  osc.frequency.setValueAtTime(freq,now);
  shimmer.frequency.setValueAtTime(freq*2.002,now);

  filter.type="lowpass";
  filter.frequency.setValueAtTime(980,now);
  filter.Q.value=.32;

  amp.gain.setValueAtTime(.0001,now);
  amp.gain.linearRampToValueAtTime(gain,now+Math.min(1.25,dur*.32));
  amp.gain.setValueAtTime(gain,Math.max(now+.2,stop-1.45));
  amp.gain.exponentialRampToValueAtTime(.0001,stop);

  const shimmerGain=audioCtx.createGain();
  shimmerGain.gain.value=.07;

  osc.connect(filter);
  shimmer.connect(shimmerGain);
  shimmerGain.connect(filter);
  filter.connect(amp);

  if(audioCtx.createStereoPanner){
    const panner=audioCtx.createStereoPanner();
    panner.pan.value=Math.max(-1,Math.min(1,pan));
    amp.connect(panner);
    panner.connect(audioMusicGain);
  }else{
    amp.connect(audioMusicGain);
  }

  osc.start(now);
  shimmer.start(now);
  osc.stop(stop+.05);
  shimmer.stop(stop+.05);
}

function playRelaxingBell(freq=440,dur=1.8,gain=.006,delay=0,pan=0){
  if(!audioSettings.musicEnabled||!ensureAudio()||!audioMusicGain) return;

  const now=audioCtx.currentTime+Math.max(0,delay);
  const stop=now+Math.max(.35,dur);
  const osc=audioCtx.createOscillator();
  const overtone=audioCtx.createOscillator();
  const filter=audioCtx.createBiquadFilter();
  const amp=audioCtx.createGain();
  const overtoneGain=audioCtx.createGain();

  osc.type="sine";
  overtone.type="sine";
  osc.frequency.setValueAtTime(freq,now);
  overtone.frequency.setValueAtTime(freq*2.01,now);
  overtoneGain.gain.value=.16;

  filter.type="lowpass";
  filter.frequency.setValueAtTime(1750,now);
  filter.Q.value=.25;

  amp.gain.setValueAtTime(.0001,now);
  amp.gain.exponentialRampToValueAtTime(gain,now+.035);
  amp.gain.exponentialRampToValueAtTime(.0001,stop);

  osc.connect(filter);
  overtone.connect(overtoneGain);
  overtoneGain.connect(filter);
  filter.connect(amp);

  if(audioCtx.createStereoPanner){
    const panner=audioCtx.createStereoPanner();
    panner.pan.value=Math.max(-1,Math.min(1,pan));
    amp.connect(panner);
    panner.connect(audioMusicGain);
  }else{
    amp.connect(audioMusicGain);
  }

  osc.start(now);
  overtone.start(now);
  osc.stop(stop+.05);
  overtone.stop(stop+.05);
}

function playBackgroundPhrase(){
  if(!audioSettings.musicEnabled||paused||!running||document.hidden) return;

  // คอร์ด Maj7 / add9 ให้บรรยากาศนุ่ม สบาย และไม่เร่งรีบ
  const progressions=[
    {pad:[130.81,164.81,196.00,246.94],melody:[392.00,493.88,523.25]},
    {pad:[110.00,130.81,164.81,196.00],melody:[329.63,392.00,493.88]},
    {pad:[87.31,130.81,164.81,220.00],melody:[349.23,440.00,523.25]},
    {pad:[98.00,146.83,164.81,196.00],melody:[392.00,440.00,493.88]}
  ];
  const phrase=progressions[musicPhrase%progressions.length];
  musicPhrase++;

  playMusicTone(phrase.pad[0],8.0,.040,0,-.34);
  playMusicTone(phrase.pad[1],7.7,.028,.20,-.08);
  playMusicTone(phrase.pad[2],7.4,.022,.42,.18);
  playMusicTone(phrase.pad[3],7.0,.016,.68,.36);

  playRelaxingBell(phrase.melody[0],2.25,.0124,1.10,-.20);
  playRelaxingBell(phrase.melody[1],2.05,.0110,3.15,.16);
  playRelaxingBell(phrase.melody[2],2.35,.0100,5.35,.30);
}

function syncBackgroundMusic(){
  if(!audioCtx||!audioMusicGain) return;

  const settingsVisible=!$("settingsOverlay")?.classList.contains("hidden");
  const shouldPlay=audioSettings.musicEnabled
    &&((running&&!paused)||settingsVisible)
    &&!document.hidden;
  const now=audioCtx.currentTime;
  audioMusicGain.gain.cancelScheduledValues(now);
  audioMusicGain.gain.setValueAtTime(Math.max(.0001,audioMusicGain.gain.value),now);
  const eventMusicDuck=(state.activeEvent||state.eelRaid?.phase==="active")?.55:1;
  audioMusicGain.gain.linearRampToValueAtTime(
    shouldPlay?Math.max(.0001,musicVolumeGain()*eventMusicDuck):.0001,
    now+.22
  );

  if(shouldPlay&&!musicTimer){
    playBackgroundPhrase();
    musicTimer=setInterval(playBackgroundPhrase,7600);
  }else if(!shouldPlay&&musicTimer){
    clearInterval(musicTimer);
    musicTimer=null;
  }
}

function setSfxEnabled(enabled){
  audioSettings.sfxEnabled=!!enabled;
  saveAudioSettings();
  ensureAudio();

  if(audioSfxGain){
    const now=audioCtx.currentTime;
    audioSfxGain.gain.cancelScheduledValues(now);
    audioSfxGain.gain.linearRampToValueAtTime(
      audioSettings.sfxEnabled?Math.max(.0001,sfxVolumeGain()):.0001,
      now+.08
    );
  }

  updateAudioSettingsUI();
  syncEventAmbientSound();
  if(audioSettings.sfxEnabled) setTimeout(()=>sfx("save"),90);
}

function setMusicEnabled(enabled){
  audioSettings.musicEnabled=!!enabled;
  saveAudioSettings();
  ensureAudio();
  updateAudioSettingsUI();
  syncBackgroundMusic();
}

function setSfxVolume(value,preview=false){
  audioSettings.sfxVolume=Math.max(0,Math.min(100,Number(value)||0));
  saveAudioSettings();
  ensureAudio();

  if(audioSfxGain){
    const now=audioCtx.currentTime;
    audioSfxGain.gain.cancelScheduledValues(now);
    audioSfxGain.gain.linearRampToValueAtTime(
      audioSettings.sfxEnabled?Math.max(.0001,sfxVolumeGain()):.0001,
      now+.035
    );
  }

  updateAudioSettingsUI();
  syncEventAmbientSound();
  if(preview&&audioSettings.sfxEnabled&&audioSettings.sfxVolume>0){
    sfx("coin",3);
  }
}

function setMusicVolume(value,preview=false){
  audioSettings.musicVolume=Math.max(0,Math.min(100,Number(value)||0));
  saveAudioSettings();
  ensureAudio();
  updateAudioSettingsUI();
  syncBackgroundMusic();

  if(preview&&audioSettings.musicEnabled&&audioSettings.musicVolume>0){
    playRelaxingBell(523.25,1.25,.007,0,0);
  }
}

function currentEventAmbientKey(){
  if(state.eelRaid?.phase==="active") return "eel";
  return state.activeEvent?.key||null;
}

function eventAmbientDelay(key){
  if(key==="eel") return 1650;
  if(key==="storm") return 2500;
  if(key==="gold") return 2900;
  if(key==="rainbow") return 3150;
  return 3500;
}

function playEventAmbientPhrase(key){
  if(
    !key
    ||!audioSettings.sfxEnabled
    ||audioSettings.sfxVolume<=0
    ||paused
    ||!running
    ||document.hidden
  ) return;

  if(key==="rainbow"){
    // ประกายไล่โน้ตสดใส
    const shift=[0,2,4][Math.floor(Math.random()*3)];
    const notes=[523.25,659.25,783.99,987.77].map(
      note=>note*Math.pow(2,shift/12)
    );
    notes.forEach((note,index)=>{
      playTone(note,.22,"sine",.0065,index*.16,note*1.025,(index-1.5)*.13);
    });
    playNoise(.34,.0018,2500,"highpass",.12);
  }else if(key==="storm"){
    // ลม พายุ และฟ้าร้องทุ้ม
    playNoise(.72,.0068,520,"lowpass",0,(Math.random()-.5)*.35);
    playTone(82+Math.random()*18,.66,"sawtooth",.0075,.04,48,-.18);
    if(Math.random()<.48){
      playNoise(.20,.0105,185,"lowpass",.34,.18);
      playTone(155,.24,"square",.0045,.37,72,.20);
    }
  }else if(key==="gold"){
    // เหรียญและกระดิ่งระยิบระยับ
    const root=[784,880,988][Math.floor(Math.random()*3)];
    playTone(root,.12,"triangle",.008,0,root*1.05,-.18);
    playTone(root*1.25,.15,"sine",.006,.12,root*1.34,.04);
    playTone(root*1.5,.20,"triangle",.005,.26,root*1.62,.20);
    playNoise(.12,.0016,3200,"highpass",.18);
  }else if(key==="blessing"){
    // น้ำและระฆังนุ่ม ๆ
    const root=[392,440,493.88][Math.floor(Math.random()*3)];
    playTone(root,.60,"sine",.0058,0,root*1.015,-.24);
    playTone(root*1.334,.72,"sine",.0048,.22,root*1.36,.08);
    playTone(root*2,.46,"triangle",.0038,.52,root*2.04,.26);
    playNoise(.52,.0017,2100,"highpass",.08);
  }else if(key==="eel"){
    // กระแสไฟเต้นเป็นจังหวะระหว่างปลาไหลบุก
    playTone(118,.48,"sawtooth",.008,0,76,-.20);
    playTone(640+Math.random()*160,.16,"square",.0055,.14,220,.20);
    playNoise(.30,.0075,2100,"highpass",.10,(Math.random()-.5)*.5);
  }
}

function stopEventAmbientSound(){
  if(eventAmbientTimer){
    clearTimeout(eventAmbientTimer);
    eventAmbientTimer=null;
  }
  eventAmbientKey=null;
}

function syncEventAmbientSound(){
  const key=currentEventAmbientKey();
  const shouldPlay=
    !!key
    &&audioSettings.sfxEnabled
    &&audioSettings.sfxVolume>0
    &&running
    &&!paused
    &&!document.hidden;

  if(!shouldPlay){
    stopEventAmbientSound();
    return;
  }

  if(eventAmbientKey===key&&eventAmbientTimer) return;

  stopEventAmbientSound();
  eventAmbientKey=key;

  const tick=()=>{
    if(
      currentEventAmbientKey()!==eventAmbientKey
      ||!audioSettings.sfxEnabled
      ||audioSettings.sfxVolume<=0
      ||paused
      ||!running
      ||document.hidden
    ){
      stopEventAmbientSound();
      return;
    }

    playEventAmbientPhrase(eventAmbientKey);
    eventAmbientTimer=setTimeout(tick,eventAmbientDelay(eventAmbientKey));
  };

  eventAmbientTimer=setTimeout(tick,key==="eel"?650:850);
}

function soundReady(name,gapMs=0){
  const now=performance.now();
  if(gapMs&&now-(soundCooldowns[name]||0)<gapMs) return false;
  soundCooldowns[name]=now;
  return true;
}

function sfx(name,value=0){
  if(!audioSettings.sfxEnabled||!ensureAudio()) return;

  if(name==="feed"){
    if(!soundReady(name,45)) return;
    playTone(760,.075,"sine",.018,0,310,-.15);
    playTone(1180,.045,"triangle",.009,.018,720,.12);
    playNoise(.045,.004,1250,"bandpass",0);
  }else if(name==="eat"){
    if(!soundReady(name,70)) return;
    const pitch=390+Math.min(150,Number(value||1)*45);
    playTone(pitch,.055,"sine",.012,0,pitch*1.34);
    playTone(pitch*1.65,.035,"triangle",.006,.022,pitch*1.2);
  }else if(name==="coin"){
    if(!soundReady(name,28)) return;
    const combo=Math.max(0,Number(value)||0);
    const root=720+Math.min(430,combo*15);
    playTone(root,.065,"triangle",.022,0,root*1.08,-.12);
    playTone(root*1.5,.09,"sine",.013,.035,root*1.7,.15);
    if(combo>4) playTone(root*2,.08,"sine",.007,.07,root*2.08,0);
  }else if(name==="buy"){
    playTone(523,.08,"triangle",.025,0,590,-.15);
    playTone(659,.09,"triangle",.022,.065,720,0);
    playTone(784,.13,"sine",.018,.135,920,.15);
  }else if(name==="sell"){
    playTone(660,.07,"triangle",.024,0,720,-.1);
    playTone(880,.09,"triangle",.022,.065,990,.05);
    playTone(1100,.13,"sine",.015,.14,1320,.16);
    playNoise(.08,.004,1800,"highpass",.08);
  }else if(name==="upgrade"){
    [523,659,784,1046].forEach((note,i)=>{
      playTone(note,.12+i*.012,i===3?"sine":"triangle",.022-i*.002,i*.075,note*1.04,(i-1.5)*.12);
    });
    playNoise(.18,.005,2100,"highpass",.16);
  }else if(name==="heal"){
    [440,554,659,880].forEach((note,i)=>{
      playTone(note,.16,"sine",.018-i*.001,i*.07,note*1.05,(i-1.5)*.1);
    });
    playNoise(.26,.007,2400,"highpass",0);
  }else if(name==="rescue"){
    playNoise(.18,.012,650,"bandpass",0);
    [392,523,659].forEach((note,i)=>playTone(note,.15,"triangle",.021,i*.09,note*1.08,(i-1)*.12));
  }else if(name==="enemy"){
    if(!soundReady(name,500)) return;
    playTone(105,.38,"sawtooth",.035,0,58,-.12);
    playTone(156,.30,"square",.014,.04,82,.12);
    playNoise(.28,.012,270,"lowpass",0);
  }else if(name==="hit"){
    if(!soundReady(name,38)) return;
    playTone(185+Math.random()*35,.05,"square",.014,0,105,(Math.random()-.5)*.5);
    playNoise(.045,.009,720,"bandpass",0);
  }else if(name==="shot"){
    if(!soundReady(name,30)) return;
    const power=Math.max(1,Number(value)||1);
    const start=610+Math.min(330,power*22);
    playTone(start,.045,"square",.0065,0,start*1.65,(Math.random()-.5)*.7);
  }else if(name==="error"){
    if(!soundReady(name,130)) return;
    playTone(185,.11,"square",.018,0,125,0);
    playTone(128,.15,"sawtooth",.009,.045,92,0);
  }else if(name==="event"){
    const key=String(value||"");
    if(key==="storm"){
      playTone(92,.42,"sawtooth",.030,0,52,-.2);
      playNoise(.38,.015,320,"lowpass",0);
      playTone(410,.10,"square",.010,.24,180,.2);
    }else if(key==="gold"){
      [740,990,1240,1480].forEach((note,i)=>playTone(note,.11,"triangle",.019-i*.002,i*.06,note*1.08,(i-1.5)*.12));
    }else if(key==="rainbow"){
      [523,659,784,988,1175].forEach((note,i)=>playTone(note,.14,"sine",.016,i*.055,note*1.04,(i-2)*.1));
    }else{
      [440,587,698,880].forEach((note,i)=>playTone(note,.20,"sine",.017,i*.075,note*1.06,(i-1.5)*.1));
      playNoise(.28,.005,2500,"highpass",0);
    }
  }else if(name==="siren"){
    if(!soundReady(name,620)) return;
    playTone(520,.62,"sawtooth",.020,0,860,-.28);
    playTone(860,.62,"sawtooth",.018,.58,520,.28);
    playTone(260,.58,"square",.008,.02,420,0);
    playNoise(1.18,.007,950,"bandpass",0);
  }else if(name==="eelRush"){
    if(!soundReady(name,900)) return;
    playNoise(.65,.018,520,"bandpass",0);
    playTone(145,.72,"sawtooth",.026,0,72,-.25);
    playTone(820,.35,"square",.012,.16,330,.25);
  }else if(name==="electricShock"){
    if(!soundReady(name,80)) return;
    playNoise(.16,.018,2300,"highpass",0,(Math.random()-.5)*.8);
    playTone(1280,.10,"square",.017,0,270,(Math.random()-.5)*.8);
    playTone(210,.14,"sawtooth",.011,.025,95,0);
  }else if(name==="eventEnd"){
    playTone(660,.10,"sine",.014,0,590,-.1);
    playTone(440,.16,"sine",.012,.09,360,.1);
  }else if(name==="save"){
    playTone(620,.07,"sine",.014,0,680,-.08);
    playTone(820,.10,"sine",.012,.065,900,.08);
  }else{
    playTone(440,.07,"sine",.015);
  }
}

// รองรับคำสั่งเสียงเดิมที่ยังเหลือในเกม
function beep(freq=440,dur=.05,type="sine",gain=.03){
  playTone(freq,dur,type,Math.min(.028,gain),0,freq*.97,0);
}
