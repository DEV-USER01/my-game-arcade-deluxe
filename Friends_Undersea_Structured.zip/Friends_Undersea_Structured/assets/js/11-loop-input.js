/* ลูปวาดเกม การรับสัมผัส และปุ่มควบคุมหลัก */
"use strict";

function draw(){
  drawBackground();drawEelRaidAtmosphere();drawEventAtmosphere();
  for(const f of state.foods) drawFood(f);
  for(const c of state.coinsDrop) drawCoin(c);
  if(state.snail) drawSnail(state.snail);
  if(state.catfishHelper) drawCatfishHelper(state.catfishHelper);
  state.fish.forEach(drawFish);
  state.guardians.forEach(drawGuardian);
  state.guardShots.forEach(drawGuardShot);
  state.enemies.forEach(drawEnemy);
  state.electricEels.forEach(drawElectricEel);
  state.shockFx.forEach(drawShockFx);
}

function loop(t){
  requestAnimationFrame(loop);
  if(!lastDraw){ lastDraw=t; last=t; }
  const elapsed=t-lastDraw;
  if(elapsed<FRAME_MS) return;

  const dt=Math.min(.05,(t-last)/1000||0);
  last=t;
  lastDraw=t-(elapsed%FRAME_MS);

  if(running&&!paused) update(dt);
  draw();
}

function pointerPos(ev){
  const r=canvas.getBoundingClientRect();
  const p=ev.touches?ev.touches[0]:ev;
  return {x:p.clientX-r.left,y:p.clientY-r.top};
}

function act(ev){
  ev.preventDefault();
  if(!running||paused) return;
  const p=pointerPos(ev);
  let c=nearest(state.coinsDrop,p.x,p.y,34);
  if(c){ collectCoin(c); saveProgress(); return; }
  const e=nearest(state.enemies,p.x,p.y,60);
  if(e){ e.hp-=1+(state.pearlLevel>0?.35*state.pearlLevel:0); sfx("hit"); return; }
  const fish=nearest(state.fish,p.x,p.y,42);
  if(fish){
    const status=getFishStatus(fish);
    const buffCount=fishPermanentBuffKeys(fish).length;
    const buffLine=buffCount
      ? `\n${permanentBuffIcons(fish)} บัฟถาวร ${buffCount}/4: ${permanentBuffNames(fish)}
💰 โบนัสราคาขาย +${Math.round((permanentBuffSaleMultiplier(fish)-1)*100)}%`
      : "\nยังไม่มีบัฟถาวร";
    const electricLine=fish.electricScar?"\n⚡ ตราไฟฟ้า: ราคาขายเหลือ 50%":"";
    toast(`${fish.typeData.name} • ${status.emoji} ${status.label}
❤️ ${Math.round(fish.health)}/${fish.maxHealth||fish.typeData.maxHealth||100}   🍤 ${Math.round(Math.min(130,fish.hunger))}%   ${fishGrowthStage(fish)}${buffLine}${electricLine}`);
    return;
  }
  if(p.y>tankTop&&p.y<tankBottom-5) createFood(p.x,p.y);
}

canvas.addEventListener("pointerdown",act,{passive:false});
$("feedHintBtn").onclick=()=>toast("แตะในตู้ปลาเพื่อให้อาหาร");
$("shopBtn").onclick=()=>{ renderShop(); ui.shopOverlay.classList.remove("hidden"); updateEventScheduleUI(true); };
$("healBtn").onclick=()=>healAllFish();
$("closeShopBtn").onclick=()=>{ ui.shopOverlay.classList.add("hidden"); updateEventScheduleUI(true); };
$("saveBtn").onclick=()=>{ saveProgress(); toast("บันทึกความคืบหน้าแล้ว"); sfx("save"); };
$("rescueBtn").onclick=()=> rescueTank(false);

$("settingsBtn").onclick=openAudioSettings;
$("startSettingsBtn").onclick=openAudioSettings;
$("pauseSettingsBtn").onclick=openAudioSettings;
$("closeSettingsBtn").onclick=closeAudioSettings;
$("sfxToggleBtn").onclick=()=>setSfxEnabled(!audioSettings.sfxEnabled);
$("musicToggleBtn").onclick=()=>setMusicEnabled(!audioSettings.musicEnabled);

$("sfxVolumeSlider").addEventListener("input",event=>{
  setSfxVolume(event.target.value,false);
});
$("sfxVolumeSlider").addEventListener("change",event=>{
  setSfxVolume(event.target.value,true);
});

$("musicVolumeSlider").addEventListener("input",event=>{
  setMusicVolume(event.target.value,false);
});
$("musicVolumeSlider").addEventListener("change",event=>{
  setMusicVolume(event.target.value,true);
});

$("testSoundBtn").onclick=()=>{
  if(!audioSettings.sfxEnabled){
    toast("เปิดเอฟเฟกต์เสียงก่อน");
    return;
  }
  sfx("upgrade");
};
$("settingsOverlay").addEventListener("pointerdown",event=>{
  if(event.target===$("settingsOverlay")) closeAudioSettings();
});
