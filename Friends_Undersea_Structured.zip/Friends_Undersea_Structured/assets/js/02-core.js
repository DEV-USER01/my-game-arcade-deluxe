/* ตัวแปรแกนกลาง Canvas สถานะเกม ขนาดตู้ และฉากตกแต่ง */
"use strict";

const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d",{alpha:false,desynchronized:true}) || canvas.getContext("2d");
const $ = id => document.getElementById(id);
const ui = {
  coins:$("coins"), goal:$("goal"), wave:$("wave"), tankStats:$("tankStats"),
  toast:$("toast"), fishShop:$("fishShop"), upgradeShop:$("upgradeShop"),
  fishMarket:$("fishMarket"), marketSummary:$("marketSummary"),
  eventBanner:$("eventBanner"), eventIcon:$("eventIcon"), eventName:$("eventName"),
  eventDesc:$("eventDesc"), eventTime:$("eventTime"), eventBar:$("eventBar"),
  bossWarning:$("bossWarning"),bossWarningIcon:$("bossWarningIcon"),
  bossWarningName:$("bossWarningName"),bossWarningDesc:$("bossWarningDesc"),
  bossWarningTime:$("bossWarningTime"),bossWarningBar:$("bossWarningBar"),
  eventScheduleBar:$("eventScheduleBar"),
  normalEventSchedule:$("normalEventSchedule"),
  normalScheduleIcon:$("normalScheduleIcon"),
  normalScheduleName:$("normalScheduleName"),
  normalScheduleTime:$("normalScheduleTime"),
  bossEventSchedule:$("bossEventSchedule"),
  bossScheduleTime:$("bossScheduleTime"),
  shopOverlay:$("shopOverlay"), startOverlay:$("startOverlay"), pauseOverlay:$("pauseOverlay")
};

const MOBILE_MODE = matchMedia("(pointer:coarse)").matches || innerWidth < 900;
const TARGET_FPS = MOBILE_MODE ? 30 : 45;
const FRAME_MS = 1000 / TARGET_FPS;
let W=0,H=0,DPR=1, tankTop=90, tankBottom=0, last=0, lastDraw=0, running=false, paused=false;
let audioCtx=null,audioMaster=null,audioCompressor=null,audioSfxGain=null,audioMusicGain=null;
let audioNoiseBuffer=null,musicTimer=null,musicPhrase=0;
let eventAmbientTimer=null,eventAmbientKey=null,drawTimer=0;
let settingsResumeOnClose=false;
const soundCooldowns={};
const state = {
  coins:30, foodLevel:1, fish:[], foods:[], coinsDrop:[], enemies:[], guardians:[], guardShots:[],
  electricEels:[],shockFx:[],bubbles:[], corals:[], distantFish:[], dust:[], rocks:[], seaweed:[],
  snail:null, catfishHelper:null, elapsed:0, nextEnemy:50, wave:1, pearlLevel:0, rescues:0, combo:0, rescueCooldown:0,
  activeEvent:null,nextEventAt:20,nextEventKey:null,lastEventKey:null,eventUiSecond:-1,
  eelRaid:null,nextEelRaidAt:110,eelRaidUiSecond:-1,scheduleUiSecond:-1,
  soldCount:0, salesCoins:0,
  selectedType:"goldfish", shopFocus:"goldfish"
};

function tankLevel(){ return state.pearlLevel+1; }
function fishCapacity(){ return 4+state.pearlLevel*2; }
function tankHasSpace(){ return state.fish.length<fishCapacity(); }

function foodUpgradeCost(){
  const costs={1:600,2:1500,3:3500,4:8000};
  return costs[state.foodLevel]||0;
}
function snailCost(){ return 8000; }
function catfishHelperCost(){ return 2000; }
function pearlCost(){
  // อัปตู้แพงขึ้นมาก: เริ่ม 50,000 และเพิ่ม 2.25 เท่าต่อเลเวล
  return Math.round((50000*Math.pow(2.25,state.pearlLevel))/1000)*1000;
}
function healFishCost(){
  return Math.max(25,Math.round(25+state.fish.length*18+state.pearlLevel*35));
}

function rescueCost(){
  return Math.min(
    Math.floor(state.coins),
    1200+state.rescues*500+Math.max(0,state.wave-1)*120
  );
}

function fit(){
  const r=canvas.getBoundingClientRect();
  W=r.width; H=r.height; tankBottom=H-82;

  // เพิ่มความคมชัดจากเวอร์ชันก่อน แต่จำกัดจำนวนพิกเซลเพื่อไม่ให้มือถือกระตุก
  const deviceDpr=window.devicePixelRatio||1;
  const pixelBudget=MOBILE_MODE?1600000:2600000;
  const budgetDpr=Math.sqrt(pixelBudget/Math.max(1,W*H));
  DPR=Math.max(1,Math.min(MOBILE_MODE?1.55:1.8,deviceDpr,budgetDpr));

  canvas.width=Math.floor(W*DPR);
  canvas.height=Math.floor(H*DPR);
  ctx.setTransform(DPR,0,0,DPR,0,0);
  ctx.lineCap="round";
  ctx.lineJoin="round";
  ctx.imageSmoothingEnabled=true;
  ctx.imageSmoothingQuality="high";
  buildDecor();
}
addEventListener("resize",fit,{passive:true});
document.addEventListener("visibilitychange",()=>{
  if(document.hidden){
    last=0;
    lastDraw=0;
  }else{
    last=performance.now();
    lastDraw=last;
  }
  syncBackgroundMusic();
  syncEventAmbientSound();
},{passive:true});

function buildDecor(){
  state.bubbles=[];
  for(let i=0;i<(MOBILE_MODE?Math.max(12,Math.floor(W/32)):Math.max(20,Math.floor(W/20)));i++){
    state.bubbles.push({
      x:Math.random()*W,
      y:tankTop+Math.random()*(tankBottom-tankTop),
      r:1+Math.random()*5.5,
      s:.14+Math.random()*.6,
      a:.12+Math.random()*.32,
      drift:Math.random()*6.28
    });
  }

  state.dust=[];
  for(let i=0;i<(MOBILE_MODE?Math.max(14,Math.floor(W/28)):Math.max(28,Math.floor(W/14)));i++){
    state.dust.push({
      x:Math.random()*W,
      y:tankTop+Math.random()*(tankBottom-tankTop),
      r:.35+Math.random()*1.25,
      a:.05+Math.random()*.16,
      phase:Math.random()*6.28
    });
  }

  state.distantFish=[];
  for(let i=0;i<(MOBILE_MODE?6:10);i++){
    state.distantFish.push({
      x:Math.random()*(W+180)-90,
      y:tankTop+55+Math.random()*Math.max(80,tankBottom-tankTop-170),
      size:.35+Math.random()*.55,
      speed:4+Math.random()*10,
      dir:Math.random()<.5?-1:1,
      depth:.14+Math.random()*.24,
      phase:Math.random()*6.28
    });
  }

  state.rocks=[];
  for(let i=0;i<(MOBILE_MODE?5:7);i++){
    state.rocks.push({
      x:20+i*(W-40)/Math.max(1,(MOBILE_MODE?4:6))+(Math.random()*24-12),
      w:30+Math.random()*52,
      h:18+Math.random()*44,
      shade:Math.random()
    });
  }

  state.seaweed=[];
  for(let i=0;i<(MOBILE_MODE?8:12);i++){
    state.seaweed.push({
      x:10+i*(W-20)/Math.max(1,(MOBILE_MODE?7:11))+(Math.random()*18-9),
      h:32+Math.random()*96,
      phase:Math.random()*6.28,
      hue:145+Math.random()*45
    });
  }

  state.corals=[];
  for(let i=0;i<(MOBILE_MODE?6:9);i++){
    state.corals.push({
      x:20+i*(W-40)/Math.max(1,(MOBILE_MODE?5:8))+(Math.random()*18-9),
      h:42+Math.random()*92,
      kind:i%4,
      hue:[18,288,340,175][i%4]
    });
  }
}
