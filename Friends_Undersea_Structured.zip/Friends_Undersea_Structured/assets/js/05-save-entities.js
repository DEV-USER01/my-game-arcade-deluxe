/* รีเซ็ต เซฟ โหลด และการสร้างปลา ผู้พิทักษ์ อาหาร เหรียญ และศัตรู */
"use strict";

function randomType(){
  const r = Math.random();
  if(r>.985) return "lionfish";
  if(r>.955) return "koi";
  if(r>.915) return "shark";
  if(r>.84) return "blueTang";
  if(r>.73) return "puffer";
  if(r>.57) return "angelfish";
  if(r>.40) return "betta";
  if(r>.22) return "clownfish";
  return "goldfish";
}

function reset(loadSaved=false){
  stopEventAmbientSound();
  state.coins=30;state.foodLevel=1;state.fish=[];state.foods=[];state.coinsDrop=[];state.enemies=[];state.guardians=[];state.guardShots=[];
  state.electricEels=[];state.shockFx=[];
  state.snail=null;state.catfishHelper=null;state.elapsed=0;state.nextEnemy=50;state.wave=1;state.pearlLevel=0;state.rescues=0;state.combo=0;state.rescueCooldown=0;
  state.activeEvent=null;state.lastEventKey=null;state.eventUiSecond=-1;scheduleNextEvent(true);
  state.eelRaid=null;state.eelRaidUiSecond=-1;scheduleNextEelRaid(true);
  state.soldCount=0;state.salesCoins=0;
  state.selectedType="goldfish";
  if(loadSaved && loadProgress()){
    running=true; paused=false; updateUI(); renderSpeciesStrip(); syncBackgroundMusic(); return;
  }
  spawnFish(W*.38,H*.45,"goldfish");
  spawnFish(W*.62,H*.48,"clownfish");
  running=true; paused=false;
  updateUI(); renderSpeciesStrip(); saveProgress(); syncBackgroundMusic();
}

function saveProgress(){
  if(!running) return;
  try{
    const data = {
      coins:Math.floor(state.coins), foodLevel:state.foodLevel, pearlLevel:state.pearlLevel, wave:state.wave,
      rescues:state.rescues, soldCount:state.soldCount, salesCoins:state.salesCoins,
      guardianCount:state.guardians.length, guardianTypes:state.guardians.map(g=>g.typeKey||"sword"),
      selectedType:state.selectedType, snail:!!state.snail, catfishHelper:!!state.catfishHelper,
      catfishRefunds:state.catfishHelper?.refunds||0,
      fish:state.fish.slice(0,60).map(f=>({
        type:f.type, growth:f.growth, health:Math.max(20,Math.round(f.health)),
        hunger:Math.min(98,f.hunger), hueShift:f.hueShift,
        permanentBuffs:fishPermanentBuffKeys(f),
        electricScar:!!f.electricScar
      }))
    };
    localStorage.setItem(SAVE_KEY, JSON.stringify(data));
  }catch(e){}
}

function loadProgress(){
  try{
    const raw = localStorage.getItem(SAVE_KEY);
    if(!raw) return false;
    const data = JSON.parse(raw);
    if(!data || !Array.isArray(data.fish)) return false;
    state.coins = Math.max(0, Number(data.coins)||30);
    state.foodLevel = Math.min(5, Math.max(1, Number(data.foodLevel)||1));
    state.pearlLevel = Math.max(0, Number(data.pearlLevel)||0);
    state.wave = Math.max(1, Number(data.wave)||1);
    state.rescues = Math.max(0, Number(data.rescues)||0);
    state.soldCount = Math.max(0, Number(data.soldCount)||0);
    state.salesCoins = Math.max(0, Number(data.salesCoins)||0);
    state.selectedType = FISH_TYPES[data.selectedType] ? data.selectedType : "goldfish";
    state.snail = data.snail ? {x:W*.2,y:tankBottom-12,vx:24,dir:1} : null;
    state.catfishHelper = data.catfishHelper ? {
      x:W*.72,y:tankBottom-28,vx:0,vy:0,dir:-1,wobble:Math.random()*8,
      refunds:Math.max(0,Number(data.catfishRefunds)||0)
    } : null;
    state.elapsed = 0; state.nextEnemy = 45; state.foods=[]; state.coinsDrop=[]; state.enemies=[]; state.guardians=[]; state.guardShots=[];
    state.electricEels=[];state.shockFx=[];
    state.activeEvent=null;state.lastEventKey=null;state.eventUiSecond=-1;scheduleNextEvent(true);
    state.eelRaid=null;state.eelRaidUiSecond=-1;scheduleNextEelRaid(true);
    state.fish=[];
    if(data.fish.length===0) data.fish.push({type:"goldfish"});
    data.fish.slice(0,60).forEach((saved,i)=>{
      const type = FISH_TYPES[saved.type] ? saved.type : "goldfish";
      spawnFish(50+Math.random()*Math.max(60,W-100), tankTop+60+Math.random()*Math.max(80,tankBottom-tankTop-120), type);
      const f=state.fish[state.fish.length-1];
      f.growth = Math.max(0, Number(saved.growth)||0);
      f.maxHealth = (f.typeData && f.typeData.maxHealth) || 100;
      f.health = Math.max(20, Math.min(f.maxHealth, Number(saved.health)||f.maxHealth));
      f.hunger = Math.min(98, Number(saved.hunger)||35);
      f.size = Math.min(1.85, f.baseSize + f.growth/140);
      f.hueShift = Number(saved.hueShift)||0;
      f.permanentBuffs=Array.isArray(saved.permanentBuffs)
        ? [...new Set(saved.permanentBuffs.filter(key=>EVENT_TYPES[key]))].slice(0,4)
        : [];
      f.electricScar=!!saved.electricScar;
      f.stunnedUntil=0;
      f.shockFlashUntil=0;
    });
    const rawGuardianTypes=Array.isArray(data.guardianTypes)
      ? data.guardianTypes
      : Array(Math.min(MAX_GUARDIANS_PER_TYPE,Math.max(0,Number(data.guardianCount)||0))).fill("sword");
    const typeCounts={};
    const savedGuardianTypes=[];
    rawGuardianTypes.forEach(typeKey=>{
      const safeType=GUARDIAN_TYPES[typeKey]?typeKey:"sword";
      typeCounts[safeType]=(typeCounts[safeType]||0);
      if(typeCounts[safeType]<MAX_GUARDIANS_PER_TYPE && savedGuardianTypes.length<MAX_GUARDIANS){
        typeCounts[safeType]++;
        savedGuardianTypes.push(safeType);
      }
    });
    savedGuardianTypes.forEach((typeKey,i)=>{
      spawnGuardian(W*.32+(i%3)*74, Math.min(tankBottom-120, tankTop+150+Math.floor(i/3)*68), typeKey);
    });
    toast("โหลดตู้ปลาเดิมแล้ว");
    return true;
  }catch(e){ return false; }
}

function spawnFish(x,y,typeKey){
  const type = FISH_TYPES[typeKey] || FISH_TYPES.goldfish;
  const side=Math.random()<.5?-1:1;
  const hueBase = type.hue[0] + Math.random()*(type.hue[1]-type.hue[0]);
  state.fish.push({
    type:type.key, typeData:type,
    x,y,vx:side*(24+Math.random()*18)*type.speed,vy:(Math.random()-.5)*14,dir:side,
    hunger:24+Math.random()*16,growth:0,maxHealth:type.maxHealth||100,health:type.maxHealth||100,coinTimer:6+Math.random()*3,
    hueBase,hueShift:(Math.random()-.5)*10,wobble:Math.random()*10,baseSize:.8+.06*Math.random(),size:.82,
    temperament:.85+Math.random()*.35,statusPhase:Math.random()*9,
    permanentBuffs:state.activeEvent?[state.activeEvent.key]:[],
    electricScar:false,stunnedUntil:0,shockFlashUntil:0,
    eventBuff:state.activeEvent?.key||null,eventBuffUntil:state.activeEvent?.endsAt||0
  });
}

function guardianCountByType(typeKey){
  return state.guardians.filter(g=>g.typeKey===typeKey).length;
}

function spawnGuardian(x=W*.5,y=tankTop+110,typeKey="sword"){
  const type=GUARDIAN_TYPES[typeKey]||GUARDIAN_TYPES.sword;
  if(state.guardians.length>=MAX_GUARDIANS) return false;
  if(guardianCountByType(type.key)>=MAX_GUARDIANS_PER_TYPE) return false;
  const side=Math.random()<.5?-1:1;
  state.guardians.push({
    typeKey:type.key,typeData:type,
    x,y,vx:side*(28+Math.random()*10)*type.speed,vy:(Math.random()-.5)*12,dir:side,
    wobble:Math.random()*8,attackTimer:.18+Math.random()*.36,target:null,
    eventBuff:state.activeEvent?.key||null,eventBuffUntil:state.activeEvent?.endsAt||0
  });
  return true;
}

function fishHealthRatio(f){
  const maxHealth=(f.maxHealth||f.typeData?.maxHealth||100);
  return Math.max(0,Math.min(1,(f.health||0)/Math.max(1,maxHealth)));
}

function getFishStatus(f){
  const threat=nearest(state.enemies,f.x,f.y,145);
  const hpRatio=fishHealthRatio(f);
  if(state.elapsed<(f.stunnedUntil||0)) return {emoji:"⚡",label:"ถูกช็อต",level:3};
  if(hpRatio<.35) return {emoji:"🤕",label:"บาดเจ็บ",level:3};
  if(f.hunger>105) return {emoji:"😵",label:"หิวมาก",level:3};
  if(threat) return {emoji:"😨",label:"กลัวศัตรู",level:3};
  if(hpRatio<.72) return {emoji:"💔",label:"สุขภาพลด",level:2};
  if(f.hunger>72) return {emoji:"🍤",label:"หิว",level:2};
  if(f.electricScar) return {emoji:"⚠️",label:"ตราไฟฟ้า",level:2};
  if(f.size>=1.55) return {emoji:"⭐",label:"โตเต็มวัย",level:1};
  if(hpRatio>.92&&f.hunger<45) return {emoji:"😊",label:"มีความสุข",level:1};
  return {emoji:"💙",label:"ปกติ",level:0};
}

function fishGrowthStage(f){
  return f.size>=1.55?"โตเต็มวัย":f.size>=1.25?"กำลังโต":"วัยเล็ก";
}

function createFood(x,y){
  if(state.coins<=0){ toast("เหรียญหมด — รอปลาออกเหรียญ"); return; }
  if(state.foods.length>=10){ toast("อาหารในตู้เยอะแล้ว"); return; }
  state.coins-=1;
  state.foods.push({x,y,vy:30+state.foodLevel*8,life:14,size:5+state.foodLevel*1.6,refundValue:1,grounded:false});
  sfx("feed"); updateUI(); saveProgress();
}

function dropCoin(x,y,value,style="coin"){
  state.coinsDrop.push({x,y,vy:-22,life:14,value,style,spin:Math.random()*6.2,r:value>=10?13:11});
}

function spawnEnemy(){
  const baseWave = Math.max(1,state.wave);
  const available = ENEMY_TYPES.filter(et => baseWave >= (et.minWave || 1));
  const weightedPool = [];
  available.forEach(et => {
    const weight = Math.max(1, et.weight || 1);
    for(let i=0;i<weight;i++) weightedPool.push(et);
  });
  const et = weightedPool[Math.floor(Math.random()*weightedPool.length)] || ENEMY_TYPES[0];
  const hp = Math.max(2, Math.floor((2+baseWave*.55) * et.hpMul));
  state.enemies.push({
    key:et.key, type:et,
    x:Math.random()<.5?-55:W+55,y:tankTop+80+Math.random()*(tankBottom-tankTop-190),
    vx:Math.random()<.5?48:-48,hp,maxHp:hp,target:null,wobble:Math.random()*8,
    speed:(34+Math.min(50,baseWave*1.2))*et.speedMul,
    damage:(12+Math.min(6,baseWave*.20))*et.damageMul,
    scale:et.scale || 1
  });
  state.wave++;
  state.nextEnemy=state.elapsed+Math.max(28,58-Math.min(30,baseWave*.65));
  toast(`${et.name} บุก! แตะเพื่อโจมตี`);
  sfx("enemy"); updateUI();
}
