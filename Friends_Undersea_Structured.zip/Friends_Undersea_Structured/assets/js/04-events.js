/* ข้อความแจ้งเตือน บัฟถาวร อีเวนต์ปกติ และฝูงปลาไหลไฟฟ้า */
"use strict";

function toast(msg){
  ui.toast.textContent=msg;ui.toast.classList.add("show");
  const duration=String(msg).includes("\n")?1800:1200;
  clearTimeout(toast.t);toast.t=setTimeout(()=>ui.toast.classList.remove("show"),duration);
}

function fishPermanentBuffKeys(f){
  if(!Array.isArray(f.permanentBuffs)) f.permanentBuffs=[];
  f.permanentBuffs=[...new Set(f.permanentBuffs.filter(key=>EVENT_TYPES[key]))].slice(0,4);
  return f.permanentBuffs;
}

function addPermanentFishBuff(f,key){
  if(!EVENT_TYPES[key]) return false;
  const buffs=fishPermanentBuffKeys(f);
  if(buffs.includes(key)) return false;
  buffs.push(key);
  f.permanentBuffs=buffs.slice(0,4);
  return true;
}

function permanentFishEffects(f){
  const fx={
    growthMul:1,healMul:1,hungerMul:1,speedMul:1,
    coinRateMul:1,coinValueMul:1,damageTakenMul:1
  };
  for(const key of fishPermanentBuffKeys(f)){
    if(key==="rainbow"){
      fx.growthMul*=1.18;fx.healMul*=1.25;fx.hungerMul*=.94;
    }else if(key==="storm"){
      fx.speedMul*=1.12;fx.damageTakenMul*=.90;
    }else if(key==="gold"){
      fx.coinRateMul*=1.22;fx.coinValueMul*=1.30;
    }else if(key==="blessing"){
      fx.healMul*=1.18;fx.hungerMul*=.88;fx.damageTakenMul*=.88;
    }
  }
  return fx;
}

function electricScarSaleMultiplier(f){
  return f.electricScar?.5:1;
}

function permanentBuffSaleMultiplier(f){
  let bonus=0;
  for(const key of fishPermanentBuffKeys(f)){
    if(key==="rainbow") bonus+=.35;
    else if(key==="storm") bonus+=.45;
    else if(key==="gold") bonus+=.75;
    else if(key==="blessing") bonus+=.55;
  }
  return 1+bonus;
}

function permanentBuffIcons(f){
  return fishPermanentBuffKeys(f).map(key=>EVENT_TYPES[key].icon).join("");
}

function permanentBuffNames(f){
  return fishPermanentBuffKeys(f).map(key=>EVENT_TYPES[key].fishBuff).join(", ");
}

function formatEventCountdown(seconds){
  const safe=Math.max(0,Math.ceil(Number(seconds)||0));
  const minutes=Math.floor(safe/60);
  const secs=safe%60;
  return `${minutes}:${String(secs).padStart(2,"0")}`;
}

function pickNextEventKey(){
  const keys=Object.keys(EVENT_TYPES).filter(key=>key!==state.lastEventKey);
  return keys[Math.floor(Math.random()*keys.length)]||"rainbow";
}

function updateEventScheduleUI(force=false){
  if(!ui.eventScheduleBar) return;

  const currentSecond=Math.floor(state.elapsed);
  if(!force&&currentSecond===state.scheduleUiSecond) return;
  state.scheduleUiSecond=currentSecond;

  let normalType=null;
  let normalText="";
  let normalDue=false;

  if(state.activeEvent){
    normalType=state.activeEvent.type;
    normalText=`ทำงาน ${formatEventCountdown(state.activeEvent.endsAt-state.elapsed)}`;
  }else{
    if(!state.nextEventKey) state.nextEventKey=pickNextEventKey();
    normalType=EVENT_TYPES[state.nextEventKey]||EVENT_TYPES.rainbow;
    const remaining=state.nextEventAt-state.elapsed;
    if(remaining<=0){
      normalText=state.eelRaid?"รอคิว":"กำลังมา";
      normalDue=true;
    }else{
      normalText=formatEventCountdown(remaining);
    }
  }

  ui.normalScheduleIcon.textContent=normalType.icon;
  ui.normalScheduleName.textContent=normalType.name.replace("อีเวนต์","");
  ui.normalScheduleTime.textContent=normalText;
  ui.normalEventSchedule.classList.toggle("due",normalDue);

  let bossText="";
  let bossDue=false;
  if(state.eelRaid){
    if(state.eelRaid.phase==="warning"){
      bossText=`เตือน ${formatEventCountdown(state.eelRaid.startsAt-state.elapsed)}`;
    }else{
      bossText=`กำลังบุก ${formatEventCountdown(state.eelRaid.endsAt-state.elapsed)}`;
    }
  }else{
    const remaining=state.nextEelRaidAt-state.elapsed;
    if(remaining<=0){
      bossText=(state.activeEvent||state.enemies.length>0)?"รอคิว":"กำลังมา";
      bossDue=true;
    }else{
      bossText=formatEventCountdown(remaining);
    }
  }

  ui.bossScheduleTime.textContent=bossText;
  ui.bossEventSchedule.classList.toggle("due",bossDue);

  const overlayOpen = !ui.shopOverlay.classList.contains("hidden") || !$("settingsOverlay").classList.contains("hidden") || !ui.pauseOverlay.classList.contains("hidden") || !ui.startOverlay.classList.contains("hidden");
  ui.eventScheduleBar.classList.toggle("hidden", !!state.activeEvent || !!state.eelRaid || overlayOpen);
}

function scheduleNextEelRaid(first=false){
  state.nextEelRaidAt=state.elapsed+(first?75+Math.random()*35:210+Math.random()*90);
  state.eelRaidUiSecond=-1;
  state.scheduleUiSecond=-1;
  updateEventScheduleUI(true);
}

function updateEelRaidUI(force=false){
  if(!ui.bossWarning) return;
  const raid=state.eelRaid;
  if(!raid){ui.bossWarning.className="hidden";return;}
  const endTime=raid.phase==="warning"?raid.startsAt:raid.endsAt;
  const total=raid.phase==="warning"?9:8;
  const remaining=Math.max(0,endTime-state.elapsed);
  const whole=Math.ceil(remaining);
  if(!force&&whole===state.eelRaidUiSecond) return;
  state.eelRaidUiSecond=whole;
  ui.bossWarning.className=raid.phase==="active"?"active":"warning";
  ui.bossWarningIcon.textContent=raid.phase==="active"?"⚡":"🚨";
  ui.bossWarningName.textContent=raid.phase==="active"?"ฝูงปลาไหลไฟฟ้ากำลังพุ่งผ่าน!":"ระวัง! ฝูงปลาไหลไฟฟ้ากำลังมา";
  ui.bossWarningDesc.textContent=raid.phase==="active"?"ปลาที่ถูกช็อตมีโอกาส 25% ติดตราไฟฟ้า":"เตรียมรับแรงช็อต • ราคาขายอาจเหลือครึ่งหนึ่ง";
  ui.bossWarningTime.textContent=`${whole} วิ`;
  ui.bossWarningBar.style.width=`${Math.max(0,Math.min(100,remaining/total*100))}%`;
}

function beginEelRaidWarning(){
  state.eelRaid={
    phase:"warning",warningStartedAt:state.elapsed,startsAt:state.elapsed+9,endsAt:0,
    nextSirenAt:state.elapsed,direction:Math.random()<.5?1:-1,
    shockedCount:0,scarredCount:0,checkedFish:new Set()
  };
  state.eelRaidUiSecond=-1;
  state.scheduleUiSecond=-1;
  updateEelRaidUI(true);
  updateEventScheduleUI(true);
  toast("🚨 ระวัง! ฝูงปลาไหลไฟฟ้ากำลังมา");
  stopEventAmbientSound();
  syncBackgroundMusic();
  sfx("siren");
}

function spawnElectricEelSchool(){
  const raid=state.eelRaid;if(!raid)return;
  state.electricEels.length=0;
  const count=Math.min(14,8+Math.floor(Math.max(1,state.wave)/80));
  const direction=raid.direction;
  const targets=state.fish.slice().sort(()=>Math.random()-.5);
  for(let i=0;i<count;i++){
    const target=targets.length?targets[i%targets.length]:null;
    const laneY=target
      ? Math.max(tankTop+62,Math.min(tankBottom-58,target.y+(Math.random()-.5)*42))
      : tankTop+70+(i+.5)*(tankBottom-tankTop-140)/count;
    state.electricEels.push({
      x:direction>0?-115-i*48:W+115+i*48,y:laneY,dir:direction,
      speed:220+Math.random()*65,scale:.82+Math.random()*.22,
      wobble:Math.random()*10,launchAt:state.elapsed+i*.18,
      target,hasShocked:false
    });
  }
}

function startEelRaid(){
  const raid=state.eelRaid;if(!raid)return;
  raid.phase="active";raid.startedAt=state.elapsed;raid.endsAt=state.elapsed+8;
  state.eelRaidUiSecond=-1;
  state.scheduleUiSecond=-1;
  spawnElectricEelSchool();updateEelRaidUI(true);updateEventScheduleUI(true);
  toast("⚡ ฝูงปลาไหลไฟฟ้าพุ่งเข้ามาแล้ว!");
  sfx("eelRush");
  syncBackgroundMusic();
  syncEventAmbientSound();
}

function shockFishFromEel(eel,fish){
  const raid=state.eelRaid;
  if(!raid||!fish||!state.fish.includes(fish))return;
  fish.stunnedUntil=Math.max(fish.stunnedUntil||0,state.elapsed+1.8);
  fish.shockFlashUntil=Math.max(fish.shockFlashUntil||0,state.elapsed+.72);
  state.shockFx.push({x1:eel.x,y1:eel.y,x2:fish.x,y2:fish.y,life:.48,maxLife:.48,seed:Math.random()*99});
  raid.shockedCount++;sfx("electricShock");
  if(!raid.checkedFish.has(fish)){
    raid.checkedFish.add(fish);
    if(!fish.electricScar&&Math.random()<.25){
      fish.electricScar=true;raid.scarredCount++;
      toast(`⚡ ${fish.typeData.name} ติดตราไฟฟ้า!\nราคาขายเหลือ 50%`);
    }
  }
}

function finishEelRaid(){
  const raid=state.eelRaid;if(!raid)return;
  const shocked=raid.shockedCount,scarred=raid.scarredCount;
  state.electricEels.length=0;state.eelRaid=null;state.eelRaidUiSecond=-1;
  state.scheduleUiSecond=-1;
  updateEelRaidUI(true);scheduleNextEelRaid(false);updateEventScheduleUI(true);
  toast(`⚡ ฝูงปลาไหลผ่านไปแล้ว\nช็อต ${shocked} ครั้ง • ติดตราไฟฟ้า ${scarred} ตัว`);
  stopEventAmbientSound();
  syncBackgroundMusic();
  sfx("eventEnd");updateUI();saveProgress();
}

function updateEelRaidSystem(dt){
  for(let i=state.shockFx.length-1;i>=0;i--){
    state.shockFx[i].life-=dt;
    if(state.shockFx[i].life<=0)state.shockFx.splice(i,1);
  }
  const raid=state.eelRaid;
  if(!raid){
    if(state.elapsed>=state.nextEelRaidAt&&!state.activeEvent&&state.enemies.length===0&&state.fish.length>0)beginEelRaidWarning();
    return;
  }
  if(raid.phase==="warning"){
    if(state.elapsed>=raid.nextSirenAt){sfx("siren");raid.nextSirenAt=state.elapsed+1.18;}
    if(state.elapsed>=raid.startsAt)startEelRaid();else updateEelRaidUI(false);
    return;
  }
  for(let i=state.electricEels.length-1;i>=0;i--){
    const eel=state.electricEels[i];
    if(state.elapsed<eel.launchAt)continue;
    eel.wobble+=dt*7.2;
    if(eel.target&&state.fish.includes(eel.target))eel.y+=(eel.target.y-eel.y)*Math.min(1,dt*1.35);
    const previousX=eel.x;eel.x+=eel.dir*eel.speed*dt;
    if(!eel.hasShocked&&eel.target&&state.fish.includes(eel.target)){
      const targetX=eel.target.x;
      const crossed=eel.dir>0?previousX<targetX&&eel.x>=targetX:previousX>targetX&&eel.x<=targetX;
      if(crossed){eel.hasShocked=true;shockFishFromEel(eel,eel.target);}
    }
    if((eel.dir>0&&eel.x>W+130)||(eel.dir<0&&eel.x<-130))state.electricEels.splice(i,1);
  }
  updateEelRaidUI(false);
  if((state.elapsed>=raid.endsAt&&state.electricEels.length===0)||state.elapsed>=raid.endsAt+2)finishEelRaid();
}

function currentEventEffects(){return state.activeEvent?state.activeEvent.type:NO_EVENT_EFFECTS;}
function scheduleNextEvent(first=false){
  state.nextEventAt=state.elapsed+(first?18+Math.random()*10:70+Math.random()*45);
  state.nextEventKey=pickNextEventKey();
  state.eventUiSecond=-1;
  state.scheduleUiSecond=-1;
  updateEventScheduleUI(true);
}
function updateEventUI(force=false){
  if(!ui.eventBanner)return;
  const a=state.activeEvent;
  if(!a){ui.eventBanner.className="hidden";return;}
  const remaining=Math.max(0,a.endsAt-state.elapsed),whole=Math.ceil(remaining);
  if(!force&&whole===state.eventUiSecond)return;
  state.eventUiSecond=whole;ui.eventBanner.className=a.type.className;ui.eventIcon.textContent=a.type.icon;
  ui.eventName.textContent=a.type.name;ui.eventDesc.textContent=a.type.desc;ui.eventTime.textContent=`${whole} วิ`;
  ui.eventBar.style.width=`${Math.max(0,Math.min(100,remaining/a.type.duration*100))}%`;
}
function startRandomEvent(){
  const type=EVENT_TYPES[state.nextEventKey]
    ||EVENT_TYPES[pickNextEventKey()]
    ||EVENT_TYPES.rainbow;
  state.nextEventKey=null;
  state.activeEvent={key:type.key,type,startedAt:state.elapsed,endsAt:state.elapsed+type.duration};
  state.lastEventKey=type.key;
  state.eventUiSecond=-1;
  state.scheduleUiSecond=-1;
  let newlyBuffed=0;
  state.fish.forEach(f=>{
    f.eventBuff=type.key;
    f.eventBuffUntil=state.activeEvent.endsAt;
    if(addPermanentFishBuff(f,type.key)) newlyBuffed++;
  });
  state.guardians.forEach(g=>{g.eventBuff=type.key;g.eventBuffUntil=state.activeEvent.endsAt;});
  toast(`${type.icon} ${type.name} เริ่มแล้ว!
ปลา ${newlyBuffed} ตัวได้รับบัฟถาวร: ${type.fishBuff}`);
  sfx("event",type.key);
  syncBackgroundMusic();
  syncEventAmbientSound();
  updateEventUI(true);
  updateEventScheduleUI(true);
  updateUI();
}
function endActiveEvent(){
  const ended=state.activeEvent;if(!ended)return;
  state.fish.forEach(f=>{f.eventBuff=null;f.eventBuffUntil=0;});
  state.guardians.forEach(g=>{g.eventBuff=null;g.eventBuffUntil=0;});
  state.activeEvent=null;
  scheduleNextEvent(false);
  updateEventUI(true);
  updateEventScheduleUI(true);
  toast(`${ended.type.icon} ${ended.type.name} จบแล้ว`);
  stopEventAmbientSound();
  syncBackgroundMusic();
  sfx("eventEnd");
  updateUI();
}
function updateEventSystem(){
  if(state.activeEvent){
    if(state.elapsed>=state.activeEvent.endsAt)endActiveEvent();
    else updateEventUI(false);
  }else if(!state.eelRaid&&state.elapsed>=state.nextEventAt){
    startRandomEvent();
  }
}
