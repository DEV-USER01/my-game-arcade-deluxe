/* หน้าเริ่มเกม สถิติ หยุดเกม การติดตั้ง PWA และเริ่มระบบ */
"use strict";

function updateStartScreen(){
  const button=$("startBtn");
  const status=$("startSaveStatus");
  const newButton=$("newBtn");
  if(!button||!status||!newButton) return;

  try{
    const raw=localStorage.getItem(SAVE_KEY);
    if(!raw){
      button.textContent="▶ เริ่มเล่น";
      status.textContent="🌱 ยังไม่มีเซฟ — เริ่มตู้ปลาใหม่พร้อมปลาเริ่มต้น 2 ตัว";
      newButton.classList.add("hidden");
      return;
    }

    const saved=JSON.parse(raw);
    const fishCount=Array.isArray(saved?.fish)?saved.fish.length:0;
    const coins=Math.max(0,Math.floor(Number(saved?.coins)||0));
    const guardians=Array.isArray(saved?.guardianTypes)
      ? saved.guardianTypes.length
      : Math.max(0,Number(saved?.guardianCount)||0);

    button.textContent="▶ เล่นต่อ";
    status.textContent=`💾 เซฟล่าสุด: ปลา ${fishCount} ตัว • เหรียญ ${coins.toLocaleString("th-TH")} • ผู้พิทักษ์ ${guardians}`;
    newButton.classList.remove("hidden");
  }catch(error){
    button.textContent="▶ เริ่มเล่น";
    status.textContent="🌱 พร้อมเริ่มตู้ปลาใหม่";
    newButton.classList.remove("hidden");
  }
}

updateStartScreen();

$("startBtn").onclick=()=>{
  ensureAudio();
  ui.startOverlay.classList.add("hidden");
  reset(true);
};
$("newBtn").onclick=()=>{
  localStorage.removeItem(SAVE_KEY);
  ensureAudio();
  ui.startOverlay.classList.add("hidden");
  reset(false);
};
const showFullTankStats=()=>{
  const eventText=state.activeEvent
    ? `
${state.activeEvent.type.icon} อีเวนต์: ${state.activeEvent.type.name}`
    : "";
  const catfishText=state.catfishHelper
    ? `
🐟 ปลาดุกคืนเงินสะสม ${state.catfishHelper.refunds||0} เหรียญ`
    : "";
  toast(
    `ระดับตู้ ${state.pearlLevel} • ถัดไป ${pearlCost().toLocaleString("th-TH")} เหรียญ`
    + `
🌊 คลื่น ${Math.max(1,state.wave-1)} • ไม่สิ้นสุด`
    + `
🐟 ปลา ${state.fish.length}/${fishCapacity()} ตัว`
    + `
🛡️ องครักษ์ ${state.guardians.length}/${MAX_GUARDIANS} ตัว • สูงสุดชนิดละ 3`
    + `
💰 ขายแล้ว ${state.soldCount} ตัว`
    + catfishText
    + `
🛟 กู้ภัย ${state.rescues} ครั้ง`
    + eventText
  );
};
$("statsPanel").onclick=showFullTankStats;
$("statsPanel").onkeydown=event=>{
  if(event.key==="Enter"||event.key===" "){
    event.preventDefault();
    showFullTankStats();
  }
};

$("pauseBtn").onclick=()=>{
  if(!running) return;
  paused=true;
  ui.pauseOverlay.classList.remove("hidden");
  saveProgress();
  syncBackgroundMusic();
  syncEventAmbientSound();
};
$("resumeBtn").onclick=()=>{
  paused=false;
  last=performance.now();
  lastDraw=last;
  ui.pauseOverlay.classList.add("hidden");
  syncBackgroundMusic();
  syncEventAmbientSound();
};
$("restartPauseBtn").onclick=()=>{ localStorage.removeItem(SAVE_KEY); ui.pauseOverlay.classList.add("hidden"); reset(false); };

// ติดตั้งเป็น Progressive Web App (PWA)
let deferredInstallPrompt=null;
const installBtn=$("installBtn");
const installNote=$("installNote");

function isStandalone(){
  return matchMedia("(display-mode: standalone)").matches ||
    window.navigator.standalone === true;
}

function updateInstallUI(){
  if(isStandalone()){
    installBtn.classList.add("hidden");
    installNote.textContent="✅ เปิดอยู่ในโหมดแอปแล้ว";
    return;
  }
  installBtn.classList.remove("hidden");
}

addEventListener("beforeinstallprompt",(event)=>{
  event.preventDefault();
  deferredInstallPrompt=event;
  updateInstallUI();
});

installBtn.addEventListener("click",async()=>{
  if(isStandalone()){
    toast("ติดตั้งเป็นแอปแล้ว");
    return;
  }

  if(deferredInstallPrompt){
    deferredInstallPrompt.prompt();
    const choice=await deferredInstallPrompt.userChoice;
    deferredInstallPrompt=null;
    if(choice.outcome==="accepted"){
      toast("กำลังติดตั้งเพื่อนซี้ใต้ทะเล");
    }else{
      toast("ยกเลิกการติดตั้ง");
    }
    return;
  }

  toast("กดเมนู Chrome ⋮ แล้วเลือก ติดตั้งแอป");
  installNote.textContent="ใน Chrome กด ⋮ แล้วเลือก “ติดตั้งแอป” หรือ “เพิ่มไปยังหน้าจอหลัก”";
});

addEventListener("appinstalled",()=>{
  deferredInstallPrompt=null;
  updateInstallUI();
  toast("ติดตั้งเพื่อนซี้ใต้ทะเลสำเร็จแล้ว");
});

if("serviceWorker" in navigator){
  addEventListener("load",()=>{
    navigator.serviceWorker.register("./sw.js").catch(()=>{
      installNote.textContent="เปิดเกมผ่านลิงก์ HTTPS แล้วลองใหม่";
    });
  });
}

updateInstallUI();

document.addEventListener("visibilitychange",()=>{ if(document.hidden&&running){ saveProgress(); paused=true; ui.pauseOverlay.classList.remove("hidden"); } });
setInterval(()=>{ if(running&&!paused) saveProgress(); },5000);
addEventListener("pagehide", saveProgress);

fit(); updateUI(); updateAudioSettingsUI(); updateEventUI(true);
updateEventScheduleUI(true); renderSpeciesStrip(); requestAnimationFrame(loop);
