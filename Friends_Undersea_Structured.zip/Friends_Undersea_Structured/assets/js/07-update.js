/* ตรรกะอัปเดตเกม การเคลื่อนที่ การต่อสู้ และเศรษฐกิจ */
"use strict";

function update(dt){
  state.elapsed+=dt;
  updateEelRaidSystem(dt);
  updateEventSystem();
  updateEventScheduleUI(false);
  const eventFx=currentEventEffects();
  state.rescueCooldown=Math.max(0,state.rescueCooldown-dt);

  for(const b of state.bubbles){
    b.y-=b.s*60*dt; if(b.y<tankTop){ b.y=tankBottom; b.x=Math.random()*W; }
  }

  for(let i=state.foods.length-1;i>=0;i--){
    const f=state.foods[i];f.y+=f.vy*dt;f.life-=dt;
    if(f.y>tankBottom-10){f.y=tankBottom-10;f.vy=0;f.grounded=true}
    if(f.life<=0)state.foods.splice(i,1);
  }

  for(let i=state.fish.length-1;i>=0;i--){
    const f=state.fish[i], t=f.typeData;
    const permanentFx=permanentFishEffects(f);
    const stunned=state.elapsed<(f.stunnedUntil||0);
    const shockSpeedMul=stunned?.12:1;
    if(stunned){f.vx*=Math.pow(.08,dt);f.vy*=Math.pow(.08,dt);}
    f.hunger+=dt*(1.45+f.size*.25)*t.hungerMul*Math.max(.55,1-state.pearlLevel*.035)*eventFx.hungerMul*permanentFx.hungerMul;
    f.wobble+=dt*(3.5+t.speed*.7);
    const target=nearest(state.foods,f.x,f.y,240);
    if(target&&(f.hunger>22||f.health<(f.maxHealth||t.maxHealth||100)*.92)){
      let dx=target.x-f.x,dy=target.y-f.y,d=Math.hypot(dx,dy)||1;
      f.vx+=(dx/d)*95*t.speed*eventFx.speedMul*permanentFx.speedMul*shockSpeedMul*dt;
      f.vy+=(dy/d)*85*t.speed*eventFx.speedMul*permanentFx.speedMul*shockSpeedMul*dt;
      if(d<18+f.size*8){
        const idx=state.foods.indexOf(target);if(idx>=0)state.foods.splice(idx,1);
        f.hunger=Math.max(0,f.hunger-(38+state.foodLevel*7));
        const foodHeal=(10+state.foodLevel*6)*t.hpMul*eventFx.healMul*permanentFx.healMul;
        const foodMaxHealth=f.maxHealth||t.maxHealth||100;
        f.health=Math.min(foodMaxHealth,f.health+foodHeal);
        f.growth+=(6.7+state.foodLevel*2.2)*t.growthMul*eventFx.growthMul*permanentFx.growthMul;
        f.size=Math.min(1.85,f.baseSize+f.growth/140);
        sfx("eat",f.size);
      }
    } else {
      f.vx+=(Math.random()-.5)*28*dt*t.speed*eventFx.speedMul*permanentFx.speedMul*shockSpeedMul;
      f.vy+=(Math.random()-.5)*18*dt*t.speed*eventFx.speedMul*permanentFx.speedMul*shockSpeedMul;
    }
    const speed=Math.hypot(f.vx,f.vy);
    const max=(42+f.size*22)*t.speed*eventFx.speedMul*permanentFx.speedMul*shockSpeedMul;
    if(speed>max){f.vx=f.vx/speed*max;f.vy=f.vy/speed*max}
    f.x+=f.vx*dt;f.y+=f.vy*dt; if(Math.abs(f.vx)>3)f.dir=Math.sign(f.vx);
    const pad=26+f.size*13;
    if(f.x<pad){f.x=pad;f.vx=Math.abs(f.vx)}
    if(f.x>W-pad){f.x=W-pad;f.vx=-Math.abs(f.vx)}
    if(f.y<tankTop+40){f.y=tankTop+40;f.vy=Math.abs(f.vy)}
    if(f.y>tankBottom-40){f.y=tankBottom-40;f.vy=-Math.abs(f.vy)}
    const maxHealth=f.maxHealth||t.maxHealth||100;
    if(f.hunger>100){f.health-=dt*(5.4+(f.hunger-100)*.06)/t.hpMul}
    else f.health=Math.min(maxHealth,f.health+dt*.5*t.hpMul*eventFx.healMul*permanentFx.healMul);
    f.coinTimer-=dt*eventFx.coinRateMul*permanentFx.coinRateMul;
    if(f.size>1.0&&f.coinTimer<=0){
      const base = t.coinBase;
      const normalVal=f.size>1.55?Math.max(7,Math.round(base*2.4)):f.size>1.28?Math.max(4,Math.round(base*1.6)):base;
      const val=Math.max(1,Math.round(normalVal*eventFx.coinValueMul*permanentFx.coinValueMul));
      dropCoin(f.x,f.y,val,state.activeEvent?.key==="gold"?"gem":"coin");
      f.coinTimer=Math.max(3.8,9-(f.size*2.2+t.coinRate*1.6))+Math.random()*2.7;
    }
    if(f.health<=0){state.fish.splice(i,1);toast(`${t.name} หายไปแล้ว`)}
  }

  for(let i=state.coinsDrop.length-1;i>=0;i--){
    const c=state.coinsDrop[i];c.vy+=70*dt;c.y+=c.vy*dt;c.life-=dt;c.spin+=dt*7;
    if(c.y>tankBottom-15){c.y=tankBottom-15;c.vy*=-.25}
    if(c.life<=0)state.coinsDrop.splice(i,1);
  }

  if(state.snail){
    const s=state.snail;s.x+=s.vx*s.dir*dt;if(s.x<30){s.x=30;s.dir=1}if(s.x>W-30){s.x=W-30;s.dir=-1}
    const c=nearest(state.coinsDrop,s.x,s.y,120);
    if(c){let dx=c.x-s.x,dy=c.y-s.y,d=Math.hypot(dx,dy)||1;c.x-=dx/d*65*dt;c.y-=dy/d*65*dt; if(d<24)collectCoin(c);}
  }

  if(state.catfishHelper){
    const cf=state.catfishHelper;
    cf.wobble+=dt*3.2;

    let target=null;
    let bestDistance=Infinity;
    for(const food of state.foods){
      if(!food.grounded&&food.y<tankBottom-16) continue;
      const d=Math.hypot(food.x-cf.x,food.y-cf.y);
      if(d<bestDistance){
        bestDistance=d;
        target=food;
      }
    }

    if(target){
      const dx=target.x-cf.x;
      const dy=(tankBottom-27)-cf.y;
      const d=Math.hypot(dx,dy)||1;
      cf.vx+=(dx/d)*100*dt;
      cf.vy+=(dy/d)*55*dt;

      if(bestDistance<25){
        const idx=state.foods.indexOf(target);
        if(idx>=0){
          state.foods.splice(idx,1);
          const refund=Math.max(1,Number(target.refundValue)||1);
          state.coins+=refund;
          cf.refunds=(cf.refunds||0)+refund;
          sfx("coin",2);
          updateUI();
          saveProgress();
        }
      }
    }else{
      const anchorX=W*.5+Math.sin(state.elapsed*.34+cf.wobble)*W*.32;
      const anchorY=tankBottom-28+Math.sin(state.elapsed*.72+cf.wobble)*5;
      const dx=anchorX-cf.x,dy=anchorY-cf.y,d=Math.hypot(dx,dy)||1;
      cf.vx+=(dx/d)*33*dt;
      cf.vy+=(dy/d)*24*dt;
    }

    cf.vx*=Math.pow(.28,dt);
    cf.vy*=Math.pow(.24,dt);
    const speed=Math.hypot(cf.vx,cf.vy);
    const maxSpeed=76;
    if(speed>maxSpeed){
      cf.vx=cf.vx/speed*maxSpeed;
      cf.vy=cf.vy/speed*maxSpeed;
    }
    cf.x+=cf.vx*dt;
    cf.y+=cf.vy*dt;
    if(Math.abs(cf.vx)>2) cf.dir=Math.sign(cf.vx);
    if(cf.x<38){cf.x=38;cf.vx=Math.abs(cf.vx)}
    if(cf.x>W-38){cf.x=W-38;cf.vx=-Math.abs(cf.vx)}
    cf.y=Math.max(tankBottom-44,Math.min(tankBottom-20,cf.y));
  }

  const guardianTotal=Math.max(1,state.guardians.length);
  for(let gi=0;gi<state.guardians.length;gi++){
    const g=state.guardians[gi];
    const gt=g.typeData||GUARDIAN_TYPES[g.typeKey]||GUARDIAN_TYPES.sword;
    g.typeData=gt;
    g.wobble+=dt*(4.0+gt.speed*.3);
    g.attackTimer-=dt;
    g.target=nearest(state.enemies,g.x,g.y,Math.max(330,gt.range+90));

    // แรงแยกฝูง: ผลักองครักษ์ที่อยู่ใกล้กันเกินไป
    let separateX=0,separateY=0;
    const personalSpace=62+(gt.body==="royalShark"?18:gt.body==="ray"?10:0);
    for(let gj=0;gj<state.guardians.length;gj++){
      if(gj===gi) continue;
      const other=state.guardians[gj];
      const sx=g.x-other.x,sy=g.y-other.y;
      const sd=Math.hypot(sx,sy)||1;
      if(sd<personalSpace){
        const strength=(personalSpace-sd)/personalSpace;
        separateX+=(sx/sd)*strength;
        separateY+=(sy/sd)*strength;
      }
    }
    g.vx+=separateX*145*dt;
    g.vy+=separateY*125*dt;

    if(g.target){
      // กระจายล้อมศัตรูคนละมุม แทนการพุ่งไปจุดเดียวกัน
      const desired=Math.min(112,62+gt.range*.12);
      const slotAngle=(gi/guardianTotal)*Math.PI*2+state.elapsed*.10;
      const slotX=g.target.x+Math.cos(slotAngle)*desired;
      const slotY=g.target.y+Math.sin(slotAngle)*desired*.62;
      const dx=slotX-g.x,dy=slotY-g.y,d=Math.hypot(dx,dy)||1;
      g.vx+=(dx/d)*92*gt.speed*dt;
      g.vy+=(dy/d)*78*gt.speed*dt;

      const enemyDistance=Math.hypot(g.target.x-g.x,g.target.y-g.y);
      if(enemyDistance<gt.range&&g.attackTimer<=0){
        const damage=(gt.damage+state.pearlLevel*(.22+gt.damage*.025))*eventFx.guardianDamageMul;
        g.target.hp-=damage;
        state.guardShots.push({
          x:g.x+g.dir*24,y:g.y-2,tx:g.target.x,ty:g.target.y,
          life:.22,maxLife:.22,color:gt.color,power:Math.min(2.2,.75+gt.damage/8),typeKey:gt.key
        });
        g.attackTimer=Math.max(.34,gt.cooldown-state.pearlLevel*.012)+Math.random()*.12;
        sfx("shot",gt.damage);
      }
    }else{
      // แต่ละตัวมีช่องลาดตระเวนของตัวเอง กระจายทั่วตู้
      const columns=Math.min(4,guardianTotal);
      const rows=Math.ceil(guardianTotal/columns);
      const col=gi%columns;
      const row=Math.floor(gi/columns);
      const baseX=(col+1)*W/(columns+1);
      const usableHeight=Math.max(120,tankBottom-tankTop-260);
      const baseY=tankTop+170+(row+1)*usableHeight/(rows+1);
      const phase=gi*1.73;
      const anchorX=baseX+Math.sin(state.elapsed*.35+phase)*Math.min(40,W/(columns+1)*.22);
      const anchorY=baseY+Math.cos(state.elapsed*.48+phase)*18;
      const dx=anchorX-g.x,dy=anchorY-g.y,d=Math.hypot(dx,dy)||1;
      g.vx+=(dx/d)*38*gt.speed*dt;
      g.vy+=(dy/d)*34*gt.speed*dt;
    }

    g.vx*=Math.pow(.34,dt);
    g.vy*=Math.pow(.34,dt);
    const gs=Math.hypot(g.vx,g.vy),gmax=90*gt.speed;
    if(gs>gmax){g.vx=g.vx/gs*gmax;g.vy=g.vy/gs*gmax}
    g.x+=g.vx*dt;g.y+=g.vy*dt;
    if(Math.abs(g.vx)>2)g.dir=Math.sign(g.vx);
    if(g.x<34){g.x=34;g.vx=Math.abs(g.vx)}
    if(g.x>W-34){g.x=W-34;g.vx=-Math.abs(g.vx)}
    if(g.y<tankTop+125){g.y=tankTop+125;g.vy=Math.abs(g.vy)}
    if(g.y>tankBottom-45){g.y=tankBottom-45;g.vy=-Math.abs(g.vy)}
  }

  for(let i=state.guardShots.length-1;i>=0;i--){
    const s=state.guardShots[i];
    s.life-=dt;
    if(s.life<=0)state.guardShots.splice(i,1);
  }

  for(let i=state.enemies.length-1;i>=0;i--){
    const e=state.enemies[i]; e.wobble+=dt*(e.key==="jelly"?4.4:e.key==="squid"?4.0:3);
    if(!e.target||!state.fish.includes(e.target))e.target=nearest(state.fish,e.x,e.y);
    if(e.target){
      const dx=e.target.x-e.x,dy=e.target.y-e.y,d=Math.hypot(dx,dy)||1;
      e.x+=dx/d*e.speed*eventFx.enemySpeedMul*dt;
      e.y+=dy/d*e.speed*eventFx.enemySpeedMul*dt;
      if(e.key==="jelly") e.y += Math.sin(e.wobble*1.6)*10*dt;
      if(e.key==="crab") e.y = Math.min(tankBottom-26, Math.max(tankTop+70, e.y));
      e.vx=dx;
      if(d<25+e.target.size*10+((e.scale||1)-1)*18){
        const targetPermanentFx=permanentFishEffects(e.target);
        e.target.health-=e.damage*dt*(1-Math.min(.45,state.pearlLevel*.045))
          *eventFx.damageTakenMul*targetPermanentFx.damageTakenMul;
      }
    }
    if(e.hp<=0){
      dropCoin(e.x,e.y,Math.round((18+Math.floor(state.wave*2.1))*e.type.rewardMul*eventFx.enemyRewardMul),state.activeEvent?.key==="gold"||e.key==="jelly"||e.key==="squid"?"gem":"coin");
      state.enemies.splice(i,1); toast(`กำจัด${e.type.name}แล้ว!`); saveProgress();
    }
  }

  if(state.elapsed>=state.nextEnemy&&state.enemies.length===0&&!state.eelRaid)spawnEnemy();
  if(state.fish.length===0) rescueTank(true);
}
