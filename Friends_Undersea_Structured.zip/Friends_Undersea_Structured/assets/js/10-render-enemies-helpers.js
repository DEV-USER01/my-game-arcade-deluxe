/* วาดศัตรู ปลาดุกผู้ช่วย และหอยผู้ช่วย */
"use strict";

function drawEnemy(e){
  ctx.save();
  const facing = Math.sign(e.vx)||1;
  const pulse = 1+Math.sin(e.wobble*2.1)*0.03;
  const scale = e.scale || 1;
  ctx.translate(e.x,e.y);
  ctx.scale(facing*scale*pulse, (scale/pulse));
  ctx.rotate(Math.sin(e.wobble)*.05);

  if(e.key==="shadow"){
    const body=ctx.createLinearGradient(-34,-10,34,14);
    body.addColorStop(0,"#a73e68");
    body.addColorStop(.45,"#ff7ea6");
    body.addColorStop(1,"#72385f");
    ctx.fillStyle=body;
    ctx.strokeStyle="#4f2342";
    ctx.lineWidth=2.4;
    ctx.beginPath();
    ctx.moveTo(-28,0);
    ctx.quadraticCurveTo(-4,-19,25,-13);
    ctx.quadraticCurveTo(38,-5,36,5);
    ctx.quadraticCurveTo(29,18,-2,17);
    ctx.quadraticCurveTo(-22,14,-28,0);
    ctx.closePath();
    ctx.fill(); ctx.stroke();

    ctx.fillStyle="#ff9bbb";
    ctx.beginPath();
    ctx.moveTo(-23,0); ctx.lineTo(-48,-18); ctx.lineTo(-42,-2); ctx.lineTo(-56,0); ctx.lineTo(-42,2); ctx.lineTo(-48,18); ctx.closePath();
    ctx.fill(); ctx.stroke();

    ctx.fillStyle="rgba(255,255,255,.36)";
    ctx.beginPath(); ctx.ellipse(2,-8,13,5,-.18,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="#fff"; ctx.beginPath(); ctx.arc(17,-4,5.2,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="#20243c"; ctx.beginPath(); ctx.arc(19,-4,2.5,0,Math.PI*2); ctx.fill();
    ctx.strokeStyle="#5a2746"; ctx.lineWidth=2;
    ctx.beginPath(); ctx.arc(25,4,7,.1,1.1); ctx.stroke();
    ctx.fillStyle="#fff";
    for(let i=0;i<3;i++){
      ctx.beginPath();
      ctx.moveTo(23+i*4,7); ctx.lineTo(25+i*4,11); ctx.lineTo(27+i*4,7); ctx.fill();
    }

  }else if(e.key==="jelly"){
    const bell=ctx.createRadialGradient(-4,-17,3,0,-4,32);
    bell.addColorStop(0,"rgba(255,255,255,.78)");
    bell.addColorStop(.25,"rgba(214,206,255,.95)");
    bell.addColorStop(.7,"rgba(145,109,255,.95)");
    bell.addColorStop(1,"rgba(90,59,196,.98)");
    ctx.fillStyle=bell;
    ctx.strokeStyle="#d7caff";
    ctx.lineWidth=2;
    ctx.beginPath();
    ctx.arc(0,-2,24,Math.PI,0);
    ctx.quadraticCurveTo(20,16,7,14);
    ctx.quadraticCurveTo(0,20,-7,14);
    ctx.quadraticCurveTo(-20,16,-24,-2);
    ctx.closePath();
    ctx.fill(); ctx.stroke();
    ctx.strokeStyle="rgba(222,212,255,.95)";
    ctx.lineWidth=3;
    [-12,-5,3,11].forEach((x,i)=>{
      ctx.beginPath();
      ctx.moveTo(x,10);
      ctx.bezierCurveTo(x+5,18+Math.sin(e.wobble+i)*3,x-6,27,x-2,34);
      ctx.stroke();
    });
    ctx.fillStyle="#fff";
    ctx.beginPath(); ctx.arc(-7,-3,3.4,0,Math.PI*2); ctx.arc(7,-3,3.4,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="#352b63";
    ctx.beginPath(); ctx.arc(-6,-3,1.5,0,Math.PI*2); ctx.arc(8,-3,1.5,0,Math.PI*2); ctx.fill();

  }else if(e.key==="crab"){
    const shell=ctx.createLinearGradient(-30,-10,30,18);
    shell.addColorStop(0,"#ff8267");
    shell.addColorStop(.45,"#ffb091");
    shell.addColorStop(1,"#d6574d");
    ctx.fillStyle=shell;
    ctx.strokeStyle="#8b3a33";
    ctx.lineWidth=2.4;
    ctx.beginPath(); ctx.ellipse(0,0,26,18,0,0,Math.PI*2); ctx.fill(); ctx.stroke();
    ctx.fillStyle="#f46b60";
    [[-20,-3,-44,-18,-34,-2],[20,-3,44,-18,34,-2]].forEach(([a,b,c,d,e1,f1])=>{
      ctx.beginPath(); ctx.moveTo(a,b); ctx.lineTo(c,d); ctx.lineTo(e1,f1); ctx.closePath(); ctx.fill(); ctx.stroke();
    });
    ctx.strokeStyle="#9f4c3e";
    ctx.lineWidth=3;
    [-16,-7,7,16].forEach(x=>{
      ctx.beginPath(); ctx.moveTo(x,12); ctx.lineTo(x-9,24); ctx.stroke();
    });
    ctx.fillStyle="#fff";
    ctx.beginPath(); ctx.arc(-8,-4,3.5,0,Math.PI*2); ctx.arc(8,-4,3.5,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="#2a2640";
    ctx.beginPath(); ctx.arc(-7,-4,1.6,0,Math.PI*2); ctx.arc(9,-4,1.6,0,Math.PI*2); ctx.fill();

  }else if(e.key==="squid"){
    const head=ctx.createLinearGradient(0,-30,0,26);
    head.addColorStop(0,"#cda8ff");
    head.addColorStop(.4,"#9d73ff");
    head.addColorStop(1,"#6942cd");
    ctx.fillStyle=head;
    ctx.strokeStyle="#4b319c";
    ctx.lineWidth=2.2;
    ctx.beginPath();
    ctx.moveTo(0,-30);
    ctx.quadraticCurveTo(24,-18,22,8);
    ctx.quadraticCurveTo(12,20,0,24);
    ctx.quadraticCurveTo(-12,20,-22,8);
    ctx.quadraticCurveTo(-24,-18,0,-30);
    ctx.closePath();
    ctx.fill(); ctx.stroke();
    ctx.fillStyle="rgba(255,255,255,.35)";
    ctx.beginPath(); ctx.ellipse(-4,-14,10,5,-.3,0,Math.PI*2); ctx.fill();
    ctx.strokeStyle="#cdb8ff";
    ctx.lineWidth=3;
    [-14,-7,0,7,14].forEach((x,i)=>{
      ctx.beginPath();
      ctx.moveTo(x,18);
      ctx.bezierCurveTo(x+2,28+Math.sin(e.wobble+i)*3,x-8,36,x-4,45);
      ctx.stroke();
    });
    ctx.fillStyle="#fff";
    ctx.beginPath(); ctx.arc(-6,-2,4.2,0,Math.PI*2); ctx.arc(6,-2,4.2,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="#2d245a";
    ctx.beginPath(); ctx.arc(-5,-1,1.9,0,Math.PI*2); ctx.arc(7,-1,1.9,0,Math.PI*2); ctx.fill();

  }else if(e.key==="sharkEnemy"){
    const tail=ctx.createLinearGradient(-38,0,0,0);
    tail.addColorStop(0,"#7aa8bf");
    tail.addColorStop(1,"#b6d9e8");
    ctx.fillStyle=tail;
    ctx.strokeStyle="#355c73";
    ctx.lineWidth=2.3;
    ctx.beginPath();
    ctx.moveTo(-8,0); ctx.lineTo(-35,-20); ctx.lineTo(-29,-5); ctx.lineTo(-42,0); ctx.lineTo(-29,5); ctx.lineTo(-35,20); ctx.closePath();
    ctx.fill(); ctx.stroke();

    const body=ctx.createLinearGradient(-30,-14,32,15);
    body.addColorStop(0,"#4b7b95");
    body.addColorStop(.35,"#87b5c7");
    body.addColorStop(.62,"#bfe0ec");
    body.addColorStop(1,"#5f8ea5");
    ctx.fillStyle=body;
    ctx.beginPath();
    ctx.moveTo(-28,0);
    ctx.quadraticCurveTo(-6,-18,20,-14);
    ctx.quadraticCurveTo(35,-8,37,2);
    ctx.quadraticCurveTo(29,18,-4,16);
    ctx.quadraticCurveTo(-22,12,-28,0);
    ctx.closePath();
    ctx.fill(); ctx.stroke();
    ctx.fillStyle="#5f93aa";
    ctx.beginPath(); ctx.moveTo(-2,-12); ctx.lineTo(7,-29); ctx.lineTo(17,-11); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-1,12); ctx.lineTo(16,23); ctx.lineTo(8,9); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle="rgba(240,252,255,.84)";
    ctx.beginPath(); ctx.ellipse(10,7,19,7,-.08,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="#fff"; ctx.beginPath(); ctx.arc(22,-5,4.6,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="#21384a"; ctx.beginPath(); ctx.arc(24,-5,2.2,0,Math.PI*2); ctx.fill();
    ctx.strokeStyle="#355c73"; ctx.lineWidth=2;
    ctx.beginPath(); ctx.arc(26,4,7,.08,1); ctx.stroke();
    ctx.fillStyle="#fff";
    for(let i=0;i<4;i++){
      ctx.beginPath();
      ctx.moveTo(23+i*4,6); ctx.lineTo(25+i*4,10); ctx.lineTo(27+i*4,6); ctx.fill();
    }
  }
  ctx.restore();
  const barW = 72*(e.scale||1)*0.98;
  ctx.fillStyle="rgba(0,0,0,.5)"; drawRoundRect(e.x-barW/2,e.y-36*(e.scale||1),barW,7,4); ctx.fill();
  ctx.fillStyle=e.type.tint || (e.key==="crab"?"#ff8b7a":e.key==="jelly"?"#9fd1ff":"#ff678c");
  drawRoundRect(e.x-barW/2,e.y-36*(e.scale||1),barW*(e.hp/e.maxHp),7,4); ctx.fill();
}

function drawCatfishHelper(cf){
  const bob=Math.sin(state.elapsed*4+cf.wobble)*1.4;
  const tailWave=Math.sin(state.elapsed*5.2+cf.wobble)*4;

  ctx.save();
  ctx.translate(cf.x,cf.y+bob);
  ctx.scale(cf.dir,1);

  // เงาพื้นตู้
  ctx.save();
  ctx.globalAlpha=.18;
  ctx.fillStyle="#17343d";
  ctx.beginPath();
  ctx.ellipse(-2,14,35,5,0,0,Math.PI*2);
  ctx.fill();
  ctx.restore();

  // หาง
  ctx.fillStyle="#395b62";
  ctx.strokeStyle="#203b42";
  ctx.lineWidth=1.7;
  ctx.beginPath();
  ctx.moveTo(-27,-1);
  ctx.quadraticCurveTo(-42,-12-tailWave*.25,-49,-7-tailWave*.18);
  ctx.quadraticCurveTo(-44,0,-50,10+tailWave*.18);
  ctx.quadraticCurveTo(-40,13+tailWave*.2,-27,6);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // ลำตัวยาวของปลาดุก
  const body=ctx.createLinearGradient(-30,-13,31,13);
  body.addColorStop(0,"#263f45");
  body.addColorStop(.38,"#4f7275");
  body.addColorStop(.72,"#6f9290");
  body.addColorStop(1,"#334f55");
  ctx.fillStyle=body;
  ctx.strokeStyle="#1d3439";
  ctx.lineWidth=2;
  ctx.beginPath();
  ctx.moveTo(-31,0);
  ctx.quadraticCurveTo(-18,-15,8,-14);
  ctx.quadraticCurveTo(30,-13,37,-3);
  ctx.quadraticCurveTo(39,9,23,14);
  ctx.quadraticCurveTo(-4,18,-30,7);
  ctx.quadraticCurveTo(-35,3,-31,0);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // ท้อง
  ctx.fillStyle="rgba(192,218,207,.52)";
  ctx.beginPath();
  ctx.ellipse(10,8,23,6,-.04,0,Math.PI*2);
  ctx.fill();

  // ครีบหลัง
  ctx.fillStyle="#36575d";
  ctx.strokeStyle="#203b42";
  ctx.lineWidth=1.4;
  ctx.beginPath();
  ctx.moveTo(-6,-12);
  ctx.lineTo(3,-25);
  ctx.lineTo(12,-12);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // ครีบข้าง
  ctx.beginPath();
  ctx.moveTo(2,8);
  ctx.lineTo(-5,22);
  ctx.lineTo(16,11);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // หัวกว้าง
  const head=ctx.createRadialGradient(24,-6,2,25,0,19);
  head.addColorStop(0,"#82a5a0");
  head.addColorStop(1,"#405f63");
  ctx.fillStyle=head;
  ctx.strokeStyle="#1d3439";
  ctx.lineWidth=1.8;
  ctx.beginPath();
  ctx.ellipse(27,0,16,13,0,0,Math.PI*2);
  ctx.fill();
  ctx.stroke();

  // ตา
  ctx.fillStyle="#f3f4da";
  ctx.beginPath();
  ctx.arc(31,-5,3.3,0,Math.PI*2);
  ctx.fill();
  ctx.fillStyle="#172a2d";
  ctx.beginPath();
  ctx.arc(32,-5,1.55,0,Math.PI*2);
  ctx.fill();
  ctx.fillStyle="#fff";
  ctx.beginPath();
  ctx.arc(32.5,-5.6,.5,0,Math.PI*2);
  ctx.fill();

  // ปาก
  ctx.strokeStyle="#172e32";
  ctx.lineWidth=1.5;
  ctx.beginPath();
  ctx.arc(35,3,7,.22,1.55);
  ctx.stroke();

  // หนวดปลาดุก 6 เส้น
  ctx.strokeStyle="#b9d2c5";
  ctx.lineWidth=1.25;
  const whiskerWave=Math.sin(state.elapsed*3.4+cf.wobble)*2;
  ctx.beginPath();
  ctx.moveTo(34,0);ctx.quadraticCurveTo(49,-8+whiskerWave,58,-5+whiskerWave);
  ctx.moveTo(34,2);ctx.quadraticCurveTo(51,1+whiskerWave*.4,60,5+whiskerWave*.5);
  ctx.moveTo(33,4);ctx.quadraticCurveTo(47,10+whiskerWave*.4,55,14+whiskerWave*.6);
  ctx.moveTo(25,7);ctx.quadraticCurveTo(37,17,43,21+whiskerWave*.4);
  ctx.moveTo(23,-7);ctx.quadraticCurveTo(34,-16,42,-18-whiskerWave*.3);
  ctx.moveTo(28,-5);ctx.quadraticCurveTo(43,-12,51,-10-whiskerWave*.4);
  ctx.stroke();

  // ไอคอนคืนเงิน
  ctx.fillStyle="rgba(3,30,38,.82)";
  ctx.strokeStyle="rgba(255,239,137,.65)";
  ctx.lineWidth=1;
  ctx.beginPath();
  ctx.arc(-4,-22,9,0,Math.PI*2);
  ctx.fill();
  ctx.stroke();
  ctx.font="11px system-ui,sans-serif";
  ctx.textAlign="center";
  ctx.textBaseline="middle";
  ctx.fillStyle="#ffe36d";
  ctx.fillText("↩", -4,-22.5);

  ctx.restore();
}

function drawSnail(s){
  const bob=Math.sin(state.elapsed*5+s.x*.025)*1.2;
  const feeler=Math.sin(state.elapsed*4.2+s.x*.02)*.08;
  const eyeLook=s.dir>0?1.2:-1.2;

  ctx.save();
  ctx.translate(s.x,s.y+bob);
  ctx.scale(s.dir,1);

  // เงาบนพื้นทราย
  ctx.save();
  ctx.globalAlpha=.20;
  ctx.fillStyle="#143b46";
  ctx.beginPath();
  ctx.ellipse(-1,1,31,5.5,0,0,Math.PI*2);
  ctx.fill();
  ctx.restore();

  // เมือกเรืองแสงจาง ๆ ขณะเคลื่อนที่
  ctx.save();
  ctx.globalAlpha=.23;
  const slime=ctx.createLinearGradient(-34,0,20,0);
  slime.addColorStop(0,"rgba(124,246,224,0)");
  slime.addColorStop(.5,"rgba(124,246,224,.75)");
  slime.addColorStop(1,"rgba(124,246,224,.12)");
  ctx.strokeStyle=slime;
  ctx.lineWidth=3;
  ctx.beginPath();
  ctx.moveTo(-34,-1);
  ctx.quadraticCurveTo(-8,2,20,-1);
  ctx.stroke();
  ctx.restore();

  // เท้าหอยและลำตัว
  const foot=ctx.createLinearGradient(-25,-9,28,2);
  foot.addColorStop(0,"#e9944f");
  foot.addColorStop(.48,"#ffc875");
  foot.addColorStop(1,"#ffe2a5");
  ctx.fillStyle=foot;
  ctx.strokeStyle="#945126";
  ctx.lineWidth=1.8;
  ctx.beginPath();
  ctx.moveTo(-25,-4);
  ctx.quadraticCurveTo(-12,-12,4,-10);
  ctx.quadraticCurveTo(17,-10,27,-6);
  ctx.quadraticCurveTo(34,-2,27,1);
  ctx.quadraticCurveTo(3,5,-22,1);
  ctx.quadraticCurveTo(-29,-1,-25,-4);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // หัว
  ctx.fillStyle="#ffd08a";
  ctx.strokeStyle="#945126";
  ctx.lineWidth=1.7;
  ctx.beginPath();
  ctx.ellipse(22,-9,10.5,9,0,0,Math.PI*2);
  ctx.fill();
  ctx.stroke();

  // หนวดตา
  ctx.save();
  ctx.translate(18,-14);
  ctx.rotate(feeler);
  ctx.strokeStyle="#b66b35";
  ctx.lineWidth=1.7;
  ctx.beginPath();
  ctx.moveTo(0,0);
  ctx.quadraticCurveTo(1,-8,4,-15);
  ctx.moveTo(7,1);
  ctx.quadraticCurveTo(10,-7,12,-14);
  ctx.stroke();

  // ลูกตาบนปลายหนวด
  for(const [x,y] of [[4,-15],[12,-14]]){
    ctx.fillStyle="#fffaf0";
    ctx.strokeStyle="#70401f";
    ctx.lineWidth=1.2;
    ctx.beginPath();
    ctx.arc(x,y,3.4,0,Math.PI*2);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle="#17313b";
    ctx.beginPath();
    ctx.arc(x+eyeLook*.18,y+.3,1.45,0,Math.PI*2);
    ctx.fill();

    ctx.fillStyle="#fff";
    ctx.beginPath();
    ctx.arc(x+eyeLook*.25-.35,y-.35,.45,0,Math.PI*2);
    ctx.fill();
  }
  ctx.restore();

  // ปากยิ้ม
  ctx.strokeStyle="#8c4828";
  ctx.lineWidth=1.4;
  ctx.beginPath();
  ctx.arc(27,-7,4,.25,1.25);
  ctx.stroke();

  // เปลือกหอยทรงชัดเจน
  const shell=ctx.createRadialGradient(-7,-20,3,-8,-15,22);
  shell.addColorStop(0,"#f4c4ff");
  shell.addColorStop(.28,"#c88aea");
  shell.addColorStop(.66,"#8d52c8");
  shell.addColorStop(1,"#56308b");
  ctx.fillStyle=shell;
  ctx.strokeStyle="#46236f";
  ctx.lineWidth=2.3;
  ctx.beginPath();
  ctx.arc(-7,-15,18,0,Math.PI*2);
  ctx.fill();
  ctx.stroke();

  // ขอบล่างของเปลือก
  ctx.fillStyle="rgba(255,223,255,.30)";
  ctx.beginPath();
  ctx.ellipse(-7,-8,13,4,0,0,Math.PI*2);
  ctx.fill();

  // ลายก้นหอย
  ctx.strokeStyle="#f1c4ff";
  ctx.lineWidth=2.2;
  ctx.beginPath();
  ctx.arc(-7,-15,11,.15,Math.PI*1.92);
  ctx.arc(-7,-15,6,.2,Math.PI*1.75);
  ctx.stroke();

  ctx.strokeStyle="rgba(65,29,105,.55)";
  ctx.lineWidth=1.1;
  ctx.beginPath();
  ctx.arc(-7,-15,14,.25,Math.PI*1.55);
  ctx.stroke();

  // ประกายที่เปลือก
  ctx.fillStyle="rgba(255,255,255,.70)";
  ctx.beginPath();
  ctx.ellipse(-13,-22,5,2.4,-.45,0,Math.PI*2);
  ctx.fill();

  // ฟองเล็ก ๆ ด้านหลัง
  ctx.globalAlpha=.42;
  ctx.strokeStyle="#d9fbff";
  ctx.lineWidth=1;
  for(let i=0;i<2;i++){
    const bx=-29-i*7;
    const by=-11-i*7+Math.sin(state.elapsed*2+i)*2;
    ctx.beginPath();
    ctx.arc(bx,by,2.4+i*.7,0,Math.PI*2);
    ctx.stroke();
  }

  ctx.restore();
}
