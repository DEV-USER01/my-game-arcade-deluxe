/* วาดพื้นหลัง อีเวนต์ อาหาร เหรียญ และเครื่องมือวาดปลา */
"use strict";

function drawRoundRect(x,y,w,h,r){
  ctx.beginPath(); ctx.roundRect(x,y,w,h,r);
}

function drawBackground(){
  const sea=ctx.createLinearGradient(0,0,0,H);
  sea.addColorStop(0,"#0d8fc1");
  sea.addColorStop(.18,"#087da9");
  sea.addColorStop(.52,"#075e84");
  sea.addColorStop(1,"#07384f");
  ctx.fillStyle=sea;
  ctx.fillRect(0,0,W,H);

  const glow=ctx.createRadialGradient(W*.48,tankTop+5,10,W*.48,tankTop+5,W*.72);
  glow.addColorStop(0,"rgba(205,252,255,.50)");
  glow.addColorStop(.35,"rgba(118,227,247,.17)");
  glow.addColorStop(1,"rgba(0,31,54,0)");
  ctx.fillStyle=glow;
  ctx.fillRect(0,tankTop,W,tankBottom-tankTop);

  ctx.save();
  ctx.globalCompositeOperation="screen";
  for(let i=0;i<(MOBILE_MODE?4:6);i++){
    const sway=Math.sin(state.elapsed*.22+i*.9)*35;
    const rayCount=MOBILE_MODE?4:6;
    const x=W*(i/Math.max(1,rayCount-1))+sway-90;
    const ray=ctx.createLinearGradient(x,tankTop,x+120,tankBottom);
    ray.addColorStop(0,"rgba(215,254,255,.23)");
    ray.addColorStop(1,"rgba(120,230,240,0)");
    ctx.fillStyle=ray;
    ctx.beginPath();
    ctx.moveTo(x,tankTop);
    ctx.lineTo(x+55,tankTop);
    ctx.lineTo(x+185,tankBottom);
    ctx.lineTo(x+48,tankBottom);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  ctx.save();
  ctx.globalAlpha=.23;
  ctx.strokeStyle="#d6ffff";
  ctx.lineWidth=2;
  for(let y=tankTop+22;y<tankTop+(MOBILE_MODE?62:84);y+=(MOBILE_MODE?32:24)){
    ctx.beginPath();
    for(let x=-30;x<=W+30;x+=18){
      const yy=y+Math.sin(x*.045+state.elapsed*.8+y*.03)*4;
      if(x===-30)ctx.moveTo(x,yy); else ctx.lineTo(x,yy);
    }
    ctx.stroke();
  }
  ctx.restore();

  ctx.save();
  ctx.globalAlpha=.22;
  ctx.fillStyle="#063d58";
  ctx.beginPath();
  ctx.moveTo(0,tankBottom-125);
  for(let x=0;x<=W;x+=28){
    const y=tankBottom-118-Math.sin(x*.018)*25-Math.sin(x*.051+1.7)*13;
    ctx.lineTo(x,y);
  }
  ctx.lineTo(W,tankBottom);
  ctx.lineTo(0,tankBottom);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  for(const d of state.distantFish){
    const span=W+150;
    let px=(d.x+state.elapsed*d.speed*d.dir)%span;
    if(px<0)px+=span;
    px-=75;
    const bob=Math.sin(state.elapsed*.7+d.phase)*5;
    ctx.save();
    ctx.translate(px,d.y+bob);
    ctx.scale(d.dir*d.size,d.size);
    ctx.globalAlpha=d.depth;
    ctx.fillStyle="#062f45";
    ctx.beginPath();
    ctx.ellipse(0,0,18,7,0,0,Math.PI*2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-15,0);
    ctx.lineTo(-28,-8);
    ctx.lineTo(-25,8);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  for(const p of state.dust){
    const drift=Math.sin(state.elapsed*.28+p.phase)*5;
    ctx.globalAlpha=p.a;
    ctx.fillStyle="#d4fbff";
    ctx.beginPath();
    ctx.arc(p.x+drift,p.y,p.r,0,Math.PI*2);
    ctx.fill();
  }
  ctx.globalAlpha=1;

  for(const b of state.bubbles){
    const bx=b.x+Math.sin(state.elapsed*.8+b.drift)*4;
    const bubble=ctx.createRadialGradient(bx-b.r*.3,b.y-b.r*.35,.2,bx,b.y,b.r);
    bubble.addColorStop(0,"rgba(255,255,255,.65)");
    bubble.addColorStop(.25,"rgba(210,251,255,.18)");
    bubble.addColorStop(1,"rgba(160,235,249,.03)");
    ctx.globalAlpha=b.a;
    ctx.fillStyle=bubble;
    ctx.beginPath();
    ctx.arc(bx,b.y,b.r,0,Math.PI*2);
    ctx.fill();
    ctx.strokeStyle="rgba(225,253,255,.45)";
    ctx.lineWidth=.8;
    ctx.stroke();
  }
  ctx.globalAlpha=1;

  const sand=ctx.createLinearGradient(0,tankBottom-42,0,H);
  sand.addColorStop(0,"#d7b978");
  sand.addColorStop(.35,"#bc955b");
  sand.addColorStop(1,"#806344");
  ctx.fillStyle=sand;
  ctx.beginPath();
  ctx.moveTo(0,tankBottom-20);
  for(let x=0;x<=W;x+=18){
    ctx.lineTo(x,tankBottom-22+Math.sin(x*.055)*6+Math.cos(x*.13)*2);
  }
  ctx.lineTo(W,H);
  ctx.lineTo(0,H);
  ctx.closePath();
  ctx.fill();

  ctx.save();
  ctx.globalAlpha=.18;
  ctx.strokeStyle="#fff1b7";
  ctx.lineWidth=1.1;
  for(let y=tankBottom+4;y<H;y+=(MOBILE_MODE?24:17)){
    ctx.beginPath();
    for(let x=0;x<=W;x+=20){
      const yy=y+Math.sin(x*.08+y*.04)*2.5;
      if(x===0)ctx.moveTo(x,yy);else ctx.lineTo(x,yy);
    }
    ctx.stroke();
  }
  ctx.restore();

  for(const r of state.rocks){
    ctx.save();
    ctx.translate(r.x,tankBottom-8);
    const rg=ctx.createRadialGradient(-r.w*.18,-r.h*.65,2,0,-r.h*.25,r.w*.75);
    rg.addColorStop(0,r.shade>.5?"#7d96a0":"#64777c");
    rg.addColorStop(.55,r.shade>.5?"#425d65":"#3d5057");
    rg.addColorStop(1,"#263b42");
    ctx.fillStyle=rg;
    ctx.beginPath();
    ctx.ellipse(0,-r.h*.22,r.w*.55,r.h*.55,-.12,Math.PI,Math.PI*2);
    ctx.lineTo(r.w*.58,3);
    ctx.lineTo(-r.w*.58,3);
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha=.25;
    ctx.fillStyle="#cfe9e5";
    ctx.beginPath();
    ctx.ellipse(-r.w*.15,-r.h*.52,r.w*.2,r.h*.1,-.25,0,Math.PI*2);
    ctx.fill();
    ctx.restore();
  }

  for(const s of state.seaweed){
    const sway=Math.sin(state.elapsed*.75+s.phase)*9;
    ctx.save();
    ctx.translate(s.x,tankBottom+5);
    ctx.lineCap="round";
    for(let strand=0;strand<3;strand++){
      ctx.strokeStyle=`hsla(${s.hue+strand*8},52%,${30+strand*5}%,.88)`;
      ctx.lineWidth=4.5-strand*.8;
      ctx.beginPath();
      ctx.moveTo(strand*4-4,0);
      ctx.bezierCurveTo(
        -10+sway*.25,-s.h*.32,
        11+sway*.72,-s.h*.68,
        sway,-s.h
      );
      ctx.stroke();
    }
    ctx.restore();
  }

  state.corals.forEach((c,idx)=>{
    ctx.save();
    ctx.translate(c.x,tankBottom+8);
    ctx.shadowColor="rgba(0,0,0,.22)";
    ctx.shadowBlur=MOBILE_MODE?0:3;
    ctx.shadowOffsetY=3;

    if(c.kind===0){
      ctx.strokeStyle=`hsl(${c.hue},72%,56%)`;
      ctx.lineWidth=8;
      ctx.lineCap="round";
      ctx.beginPath();
      ctx.moveTo(0,0);
      ctx.bezierCurveTo(-10,-c.h*.35,7,-c.h*.66,0,-c.h);
      ctx.stroke();
      ctx.lineWidth=6;
      ctx.beginPath();
      ctx.moveTo(-2,-c.h*.32);
      ctx.quadraticCurveTo(-25,-c.h*.55,-20,-c.h*.76);
      ctx.moveTo(3,-c.h*.48);
      ctx.quadraticCurveTo(24,-c.h*.65,18,-c.h*.86);
      ctx.stroke();
    }else if(c.kind===1){
      for(let i=0;i<5;i++){
        ctx.fillStyle=`hsl(${c.hue+i*4},65%,${55+i*3}%)`;
        ctx.beginPath();
        ctx.ellipse(i*9-18,-c.h*.22-i*11,11,18,-.1+i*.05,0,Math.PI*2);
        ctx.fill();
      }
    }else if(c.kind===2){
      ctx.fillStyle=`hsl(${c.hue},78%,63%)`;
      for(let i=0;i<5;i++){
        const hh=c.h*(.38+i*.1);
        ctx.beginPath();
        ctx.roundRect(i*8-17,-hh,8,hh,5);
        ctx.fill();
      }
    }else{
      ctx.strokeStyle=`hsl(${c.hue},54%,43%)`;
      ctx.lineWidth=5;
      ctx.lineCap="round";
      for(let i=0;i<4;i++){
        ctx.beginPath();
        ctx.moveTo(i*8-12,0);
        ctx.quadraticCurveTo(i*6-20,-c.h*.5,i*9-10,-c.h*(.65+i*.07));
        ctx.stroke();
      }
    }
    ctx.restore();
  });

  const depthFog=ctx.createLinearGradient(0,tankTop,0,tankBottom);
  depthFog.addColorStop(0,"rgba(0,0,0,0)");
  depthFog.addColorStop(1,"rgba(0,35,52,.15)");
  ctx.fillStyle=depthFog;
  ctx.fillRect(0,tankTop,W,tankBottom-tankTop);
}

function drawEelRaidAtmosphere(){
  const raid=state.eelRaid;if(!raid)return;
  const pulse=.5+.5*Math.sin(state.elapsed*(raid.phase==="warning"?9:15));
  const top=tankTop,height=Math.max(0,tankBottom-tankTop);
  ctx.save();
  ctx.fillStyle=raid.phase==="warning"?`rgba(255,0,25,${.055+.085*pulse})`:`rgba(255,0,35,${.085+.07*pulse})`;
  ctx.fillRect(0,top,W,height);
  const edge=ctx.createLinearGradient(0,0,W,0);
  edge.addColorStop(0,`rgba(255,20,40,${.34*pulse})`);edge.addColorStop(.16,"rgba(255,0,0,0)");edge.addColorStop(.84,"rgba(255,0,0,0)");edge.addColorStop(1,`rgba(255,20,40,${.34*pulse})`);
  ctx.fillStyle=edge;ctx.fillRect(0,top,W,height);
  ctx.strokeStyle=`rgba(255,105,120,${.18+.18*pulse})`;ctx.lineWidth=2;
  if(raid.phase==="warning"){
    const scanY=top+((state.elapsed*165)%Math.max(1,height));ctx.beginPath();ctx.moveTo(0,scanY);ctx.lineTo(W,scanY);ctx.stroke();
  }else{
    const dir=raid.direction||1;
    for(let i=0;i<16;i++){
      const x=dir>0?((i*71+state.elapsed*360)%(W+160))-80:W-(((i*71+state.elapsed*360)%(W+160))-80);
      const y=top+35+(i*83)%Math.max(80,height-70);ctx.beginPath();ctx.moveTo(x-dir*44,y);ctx.lineTo(x,y);ctx.stroke();
    }
  }
  ctx.restore();
}

function drawEventAtmosphere(){
  const active=state.activeEvent;if(!active)return;const key=active.key,top=tankTop,height=Math.max(0,tankBottom-tankTop);ctx.save();
  if(key==="rainbow"){
    const gr=ctx.createLinearGradient(0,top,W,tankBottom);gr.addColorStop(0,"rgba(255,80,120,.10)");gr.addColorStop(.22,"rgba(255,190,70,.09)");gr.addColorStop(.45,"rgba(80,240,170,.09)");gr.addColorStop(.68,"rgba(70,180,255,.10)");gr.addColorStop(1,"rgba(180,90,255,.10)");ctx.fillStyle=gr;ctx.fillRect(0,top,W,height);
    ["#ff6688","#ffcc55","#68eeaa","#62caff","#b47cff"].forEach((c,i)=>{ctx.strokeStyle=c;ctx.globalAlpha=.18;ctx.lineWidth=3;ctx.beginPath();ctx.arc(W*.5,tankTop+40,W*.34-i*7,Math.PI*.12,Math.PI*.88);ctx.stroke();});
  }else if(key==="storm"){
    ctx.fillStyle="rgba(13,22,55,.20)";ctx.fillRect(0,top,W,height);ctx.strokeStyle="rgba(160,210,255,.30)";ctx.lineWidth=1.2;
    for(let i=0;i<24;i++){const x=(i*47+state.elapsed*180)%Math.max(1,W+80)-40,y=top+((i*83+state.elapsed*240)%Math.max(1,height));ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-9,y+22);ctx.stroke();}
    if((Math.sin(state.elapsed*3.7)+Math.sin(state.elapsed*7.1))>1.78){ctx.fillStyle="rgba(220,242,255,.18)";ctx.fillRect(0,top,W,height);}
  }else if(key==="gold"){
    ctx.fillStyle="rgba(255,196,55,.085)";ctx.fillRect(0,top,W,height);for(let i=0;i<20;i++){const x=(i*71+Math.sin(state.elapsed*.7+i)*28)%Math.max(1,W),y=top+((i*97-state.elapsed*18+height*5)%Math.max(1,height)),p=.5+.5*Math.sin(state.elapsed*3+i);ctx.globalAlpha=.18+.35*p;ctx.fillStyle="#ffe786";ctx.beginPath();ctx.arc(x,y,1.5+2*p,0,Math.PI*2);ctx.fill();}
  }else{
    ctx.fillStyle="rgba(93,230,224,.075)";ctx.fillRect(0,top,W,height);for(let i=0;i<14;i++){const x=(i*59+Math.sin(state.elapsed*.5+i)*22)%Math.max(1,W),y=top+((i*89-state.elapsed*12+height*6)%Math.max(1,height));ctx.globalAlpha=.18;ctx.strokeStyle="#c9ffff";ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(x,y,5+(i%3)*2,0,Math.PI*2);ctx.stroke();}
  }ctx.restore();
}

function drawFood(f){
  const spin=Math.sin(state.elapsed*3.2+f.x*.035)*.22;
  const s=Math.max(4.5,f.size);

  ctx.save();
  ctx.translate(f.x,f.y);
  ctx.rotate(spin);

  // เงาเม็ดอาหาร
  ctx.save();
  ctx.globalAlpha=.18;
  ctx.fillStyle="#4f2818";
  ctx.beginPath();
  ctx.ellipse(1,3,s*1.18,s*.42,0,0,Math.PI*2);
  ctx.fill();
  ctx.restore();

  // เม็ดอาหารทรงแคปซูล
  const body=ctx.createLinearGradient(-s,-s*.4,s,s*.5);
  body.addColorStop(0,"#ffdf92");
  body.addColorStop(.32,"#ffad55");
  body.addColorStop(.72,"#ef7135");
  body.addColorStop(1,"#a84023");
  ctx.fillStyle=body;
  ctx.strokeStyle="#82371f";
  ctx.lineWidth=1.35;
  ctx.beginPath();
  ctx.ellipse(0,0,s*1.05,s*.68,-.18,0,Math.PI*2);
  ctx.fill();
  ctx.stroke();

  // ร่องและเกล็ดบนเม็ดอาหาร
  ctx.strokeStyle="rgba(120,48,22,.55)";
  ctx.lineWidth=.9;
  ctx.beginPath();
  ctx.moveTo(-s*.45,-s*.35);
  ctx.lineTo(-s*.18,s*.34);
  ctx.moveTo(s*.04,-s*.42);
  ctx.lineTo(s*.28,s*.28);
  ctx.stroke();

  // ไฮไลต์
  ctx.fillStyle="rgba(255,255,255,.55)";
  ctx.beginPath();
  ctx.ellipse(-s*.28,-s*.25,s*.34,s*.16,-.3,0,Math.PI*2);
  ctx.fill();

  // เศษอาหารจิ๋ว
  ctx.fillStyle="#ffd884";
  ctx.globalAlpha=.7;
  ctx.beginPath();
  ctx.arc(-s*1.22,-s*.32,1.1,0,Math.PI*2);
  ctx.arc(s*1.14,s*.18,.9,0,Math.PI*2);
  ctx.fill();

  ctx.restore();
}

function drawCoin(c){
  const flip=.38+.62*Math.abs(Math.cos(c.spin));
  const shine=.5+.5*Math.sin(c.spin*1.8);

  ctx.save();
  ctx.translate(c.x,c.y);
  ctx.scale(flip,1);

  if(c.style==="gem"){
    // อัญมณีทรงคริสตัลหลายเหลี่ยม
    const gem=ctx.createLinearGradient(-c.r,-c.r,c.r,c.r);
    gem.addColorStop(0,"#eaffff");
    gem.addColorStop(.25,"#78efff");
    gem.addColorStop(.62,"#3bb9f0");
    gem.addColorStop(1,"#176fa7");
    ctx.fillStyle=gem;
    ctx.strokeStyle="#dfffff";
    ctx.lineWidth=1.8;

    ctx.beginPath();
    ctx.moveTo(0,-c.r);
    ctx.lineTo(c.r*.72,-c.r*.35);
    ctx.lineTo(c.r*.88,c.r*.24);
    ctx.lineTo(0,c.r);
    ctx.lineTo(-c.r*.88,c.r*.24);
    ctx.lineTo(-c.r*.72,-c.r*.35);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // หน้าคริสตัล
    ctx.strokeStyle="rgba(255,255,255,.55)";
    ctx.lineWidth=1;
    ctx.beginPath();
    ctx.moveTo(0,-c.r);
    ctx.lineTo(0,c.r);
    ctx.moveTo(-c.r*.72,-c.r*.35);
    ctx.lineTo(c.r*.88,c.r*.24);
    ctx.moveTo(c.r*.72,-c.r*.35);
    ctx.lineTo(-c.r*.88,c.r*.24);
    ctx.stroke();

    ctx.fillStyle="rgba(255,255,255,.75)";
    ctx.globalAlpha=.35+.45*shine;
    ctx.beginPath();
    ctx.moveTo(-c.r*.38,-c.r*.45);
    ctx.lineTo(-c.r*.05,-c.r*.72);
    ctx.lineTo(c.r*.08,-c.r*.18);
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha=1;
  }else{
    // เหรียญทองสองชั้น
    const rim=ctx.createRadialGradient(-c.r*.25,-c.r*.35,1,0,0,c.r*1.1);
    rim.addColorStop(0,"#fff3a3");
    rim.addColorStop(.28,"#ffd84f");
    rim.addColorStop(.72,"#e49b19");
    rim.addColorStop(1,"#9a5b08");
    ctx.fillStyle=rim;
    ctx.strokeStyle="#7a4608";
    ctx.lineWidth=1.8;
    ctx.beginPath();
    ctx.arc(0,0,c.r,0,Math.PI*2);
    ctx.fill();
    ctx.stroke();

    // วงขอบด้านใน
    ctx.strokeStyle="rgba(255,245,170,.82)";
    ctx.lineWidth=1.4;
    ctx.beginPath();
    ctx.arc(0,0,c.r*.72,0,Math.PI*2);
    ctx.stroke();

    // ตราปลาบนเหรียญ
    ctx.fillStyle="#a8620a";
    ctx.beginPath();
    ctx.ellipse(-c.r*.08,-1,c.r*.28,c.r*.17,0,0,Math.PI*2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-c.r*.34,-1);
    ctx.lineTo(-c.r*.58,-c.r*.22);
    ctx.lineTo(-c.r*.58,c.r*.20);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle="#ffe98a";
    ctx.beginPath();
    ctx.arc(c.r*.05,-c.r*.05,1,0,Math.PI*2);
    ctx.fill();

    // แสงสะท้อน
    ctx.fillStyle="rgba(255,255,255,.78)";
    ctx.globalAlpha=.25+.45*shine;
    ctx.beginPath();
    ctx.ellipse(-c.r*.33,-c.r*.42,c.r*.28,c.r*.10,-.55,0,Math.PI*2);
    ctx.fill();
    ctx.globalAlpha=1;
  }

  // ป้ายค่ามูลค่าให้อ่านง่าย
  const label=String(c.value);
  const fontSize=label.length>=4?8:label.length>=3?9:10;
  ctx.font=`900 ${fontSize}px system-ui,sans-serif`;
  ctx.textAlign="center";
  ctx.textBaseline="middle";
  ctx.lineWidth=2.4;
  ctx.strokeStyle=c.style==="gem"?"rgba(11,69,92,.90)":"rgba(102,57,5,.88)";
  ctx.strokeText(label,0,c.r*.36);
  ctx.fillStyle="#fffdf2";
  ctx.fillText(label,0,c.r*.36);

  ctx.restore();
}

function drawFishEye(x,y,r,look=0){
  ctx.save();
  ctx.fillStyle="#ffffff";
  ctx.beginPath();
  ctx.ellipse(x,y,r,r*1.08,0,0,Math.PI*2);
  ctx.fill();
  ctx.strokeStyle="rgba(5,31,43,.38)";
  ctx.lineWidth=1;
  ctx.stroke();
  ctx.fillStyle="#0c3446";
  ctx.beginPath();
  ctx.arc(x+r*.24+look,y,r*.48,0,Math.PI*2);
  ctx.fill();
  ctx.fillStyle="#ffffff";
  ctx.beginPath();
  ctx.arc(x+r*.42+look,y-r*.27,r*.15,0,Math.PI*2);
  ctx.fill();
  ctx.restore();
}

function drawFishMouth(x,y,smile=true){
  ctx.save();
  ctx.strokeStyle="rgba(4,35,46,.72)";
  ctx.lineWidth=1.6;
  ctx.lineCap="round";
  ctx.beginPath();
  if(smile)ctx.arc(x,y,5,0.08,1.15);
  else ctx.moveTo(x,y),ctx.lineTo(x+5,y);
  ctx.stroke();
  ctx.restore();
}

function drawScaleSparkles(points,color="rgba(255,255,255,.30)"){
  ctx.save();
  ctx.fillStyle=color;
  const step=MOBILE_MODE?2:1;
  for(let i=0;i<points.length;i+=step){
    const [x,y,r]=points[i];
    ctx.beginPath();
    ctx.ellipse(x,y,r,r*.52,-.25,0,Math.PI*2);
    ctx.fill();
  }
  ctx.restore();
}
