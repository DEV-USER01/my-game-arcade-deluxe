# แผนผังสถาปัตยกรรมโปรเจกต์

## HTML

- `index.html` — โครงหน้า UI และลำดับโหลด CSS/JavaScript เท่านั้น ไม่มี CSS หรือโค้ดเกมก้อนใหญ่อยู่ภายในแล้ว

## CSS

- `assets/css/base.css` — ตัวแปรสี โครงหน้าหลัก HUD ปุ่ม แถบอีเวนต์ และหน้าต่างพื้นฐาน
- `assets/css/start-screen.css` — หน้าเริ่มเกมและ responsive ของหน้าเริ่มเกม
- `assets/css/overlays.css` — ร้านค้า ตั้งค่าเสียง toast และ responsive ส่วนอื่น

## JavaScript

ไฟล์ทั้งหมดเป็น classic scripts ที่ใช้ตัวแปรสถานะร่วมกัน จึงต้องโหลดตามลำดับเลข

1. `01-config.js` — ข้อมูลปลา ศัตรู ผู้พิทักษ์ อีเวนต์ และ SVG sprite
2. `02-core.js` — Canvas, DOM references, state, ความจุตู้ และฉากตกแต่ง
3. `03-audio.js` — การตั้งค่าเสียง เพลง เสียงเอฟเฟกต์ และเสียงบรรยากาศ
4. `04-events.js` — บัฟถาวร อีเวนต์ปกติ และฝูงปลาไหลไฟฟ้า
5. `05-save-entities.js` — reset/save/load และ factory สำหรับ entity
6. `06-shop.js` — ซื้อ ขาย อัปเกรด รักษา กู้ตู้ ร้านค้า และ HUD
7. `07-update.js` — game simulation การเคลื่อนที่ ต่อสู้ หิว โต และเหรียญ
8. `08-render-world.js` — พื้นหลัง เอฟเฟกต์ อาหาร เหรียญ และเครื่องมือวาด
9. `09-render-actors.js` — ปลา บัฟ ปลาไหล ผู้พิทักษ์ และกระสุน
10. `10-render-enemies-helpers.js` — ศัตรู ปลาดุกผู้ช่วย และหอยผู้ช่วย
11. `11-loop-input.js` — draw loop, animation loop, pointer input และปุ่มหลัก
12. `12-ui-pwa.js` — หน้าเริ่มเกม สถิติ pause PWA และ bootstrap

## PWA

- `manifest.webmanifest` — ชื่อ ไอคอน การแสดงผล และขอบเขตแอป
- `sw.js` — Service Worker ที่เว็บใช้งานจริง
- `sw.txt` — สำเนาเนื้อหาเดียวกับ `sw.js` สำหรับขั้นตอนอัปโหลดผ่าน Android

## ไฟล์อ้างอิง

- `backup/index.original.html` — สำรองไฟล์รวมเดิมก่อนแยกโครงสร้าง
- `docs/Friends_Undersea_Project_Handoff_TH.txt` — เอกสารส่งต่องานเดิม
